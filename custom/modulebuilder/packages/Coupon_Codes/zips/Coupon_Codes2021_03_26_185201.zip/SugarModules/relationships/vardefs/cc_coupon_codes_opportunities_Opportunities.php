<?php
// created: 2021-03-26 18:52:01
$dictionary["Opportunity"]["fields"]["cc_coupon_codes_opportunities"] = array (
  'name' => 'cc_coupon_codes_opportunities',
  'type' => 'link',
  'relationship' => 'cc_coupon_codes_opportunities',
  'source' => 'non-db',
  'module' => 'CC_Coupon_Codes',
  'bean_name' => false,
  'vname' => 'LBL_CC_COUPON_CODES_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
  'id_name' => 'cc_coupon_codes_opportunitiesopportunities_ida',
  'link-type' => 'many',
  'side' => 'left',
);
