<?php
// created: 2021-03-26 18:52:01
$dictionary["Contact"]["fields"]["cc_coupon_codes_contacts"] = array (
  'name' => 'cc_coupon_codes_contacts',
  'type' => 'link',
  'relationship' => 'cc_coupon_codes_contacts',
  'source' => 'non-db',
  'module' => 'CC_Coupon_Codes',
  'bean_name' => false,
  'vname' => 'LBL_CC_COUPON_CODES_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'cc_coupon_codes_contactscontacts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
