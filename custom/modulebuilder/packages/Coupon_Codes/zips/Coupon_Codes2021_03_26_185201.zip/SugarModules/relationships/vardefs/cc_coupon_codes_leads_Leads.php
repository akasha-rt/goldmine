<?php
// created: 2021-03-26 18:52:01
$dictionary["Lead"]["fields"]["cc_coupon_codes_leads"] = array (
  'name' => 'cc_coupon_codes_leads',
  'type' => 'link',
  'relationship' => 'cc_coupon_codes_leads',
  'source' => 'non-db',
  'module' => 'CC_Coupon_Codes',
  'bean_name' => false,
  'vname' => 'LBL_CC_COUPON_CODES_LEADS_FROM_LEADS_TITLE',
  'id_name' => 'cc_coupon_codes_leadsleads_ida',
  'link-type' => 'many',
  'side' => 'left',
);
