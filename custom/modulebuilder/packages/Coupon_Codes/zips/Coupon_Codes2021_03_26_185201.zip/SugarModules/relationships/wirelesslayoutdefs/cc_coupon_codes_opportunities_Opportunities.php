<?php
 // created: 2021-03-26 18:52:01
$layout_defs["Opportunities"]["subpanel_setup"]['cc_coupon_codes_opportunities'] = array (
  'order' => 100,
  'module' => 'CC_Coupon_Codes',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CC_COUPON_CODES_OPPORTUNITIES_FROM_CC_COUPON_CODES_TITLE',
  'get_subpanel_data' => 'cc_coupon_codes_opportunities',
);
