<?php
// created: 2021-03-26 18:52:01
$viewdefs['Leads']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CC_COUPON_CODES_LEADS_FROM_CC_COUPON_CODES_TITLE',
  'context' => 
  array (
    'link' => 'cc_coupon_codes_leads',
  ),
);