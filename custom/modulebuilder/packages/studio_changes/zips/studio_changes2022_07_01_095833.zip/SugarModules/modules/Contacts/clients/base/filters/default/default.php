<?php
// created: 2022-01-21 17:32:45
$viewdefs['Contacts']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'contact_type_c' => 
    array (
      'type' => 'enum',
      'default' => true,
      'studio' => 'visible',
      'width' => '10%',
      'name' => 'contact_type_c',
      'vname' => 'LBL_CONTACT_TYPE',
    ),
    'account_name' => 
    array (
      'dbFields' => 
      array (
      ),
    ),
    'first_name' => 
    array (
    ),
    'last_name' => 
    array (
    ),
    'team_name' => 
    array (
    ),
    'primary_address_postalcode' => 
    array (
    ),
    'primary_address_state' => 
    array (
    ),
    'primary_address_country' => 
    array (
    ),
    'price_increase_c' => 
    array (
    ),
    'pmt_c' => 
    array (
    ),
    'pht_c' => 
    array (
    ),
    'gage_blocks_c' => 
    array (
    ),
    'special_gage_c' => 
    array (
    ),
    'saws_c' => 
    array (
    ),
    'band_saws_c' => 
    array (
    ),
    'band_saw_machines_c' => 
    array (
    ),
    'meat_cutter_c' => 
    array (
    ),
    'pta_and_hand_saw_blades_c' => 
    array (
    ),
    'raw_material_c' => 
    array (
    ),
    'welding_center_c' => 
    array (
    ),
    'jst_c' => 
    array (
    ),
    'hand_tools_c' => 
    array (
    ),
    'm1_oil_c' => 
    array (
    ),
    'pgs_c' => 
    array (
    ),
    'flat_stock_c' => 
    array (
    ),
    'drill_rod_c' => 
    array (
    ),
    'metrology_equipment_c' => 
    array (
    ),
    'vision_systems_c' => 
    array (
    ),
    'optical_systems_c' => 
    array (
    ),
    'services_c' => 
    array (
    ),
    'laser_measurement_c' => 
    array (
    ),
    'testing_equipment_c' => 
    array (
    ),
    'force_measurement_c' => 
    array (
    ),
    'material_testing_c' => 
    array (
    ),
    'hand_held_force_gages_c' => 
    array (
    ),
    'granite_c' => 
    array (
    ),
    'custom_granite_solutions_c' => 
    array (
    ),
    'surface_plates_c' => 
    array (
    ),
    'employment_status_c' => 
    array (
    ),
    'assigned_user_name' => 
    array (
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
  ),
);