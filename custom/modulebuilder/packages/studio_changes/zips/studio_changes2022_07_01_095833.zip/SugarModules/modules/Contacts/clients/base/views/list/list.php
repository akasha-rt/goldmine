<?php
// created: 2022-06-11 03:13:18
$viewdefs['Contacts']['base']['view']['list'] = array (
  'panels' => 
  array (
    0 => 
    array (
      'label' => 'LBL_PANEL_DEFAULT',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'account_name',
          'enabled' => true,
          'default' => true,
          'link' => true,
          'label' => 'LBL_LIST_ACCOUNT_NAME',
          'id' => 'ACCOUNT_ID',
          'contextMenu' => 
          array (
            'objectType' => 'sugarAccount',
            'metaData' => 
            array (
              'return_module' => 'Contacts',
              'return_action' => 'ListView',
              'module' => 'Accounts',
              'parent_id' => '{$ACCOUNT_ID}',
              'parent_name' => '{$ACCOUNT_NAME}',
              'account_id' => '{$ACCOUNT_ID}',
              'account_name' => '{$ACCOUNT_NAME}',
            ),
          ),
          'sortable' => true,
          'ACLTag' => 'ACCOUNT',
          'related_fields' => 
          array (
            0 => 'account_id',
          ),
        ),
        1 => 
        array (
          'name' => 'name',
          'type' => 'fullname',
          'fields' => 
          array (
            0 => 'salutation',
            1 => 'first_name',
            2 => 'last_name',
          ),
          'link' => true,
          'label' => 'LBL_LIST_NAME',
          'enabled' => true,
          'default' => true,
        ),
        2 => 
        array (
          'name' => 'title',
          'enabled' => true,
          'default' => true,
          'label' => 'LBL_LIST_TITLE',
        ),
        3 => 
        array (
          'name' => 'primary_address_city',
          'default' => true,
          'enabled' => true,
          'label' => 'LBL_PRIMARY_ADDRESS_CITY',
        ),
        4 => 
        array (
          'name' => 'primary_address_state',
          'default' => true,
          'enabled' => true,
          'label' => 'LBL_PRIMARY_ADDRESS_STATE',
        ),
        5 => 
        array (
          'name' => 'email1',
          'default' => true,
          'enabled' => true,
          'studio' => 
          array (
            'editview' => true,
            'editField' => true,
            'searchview' => false,
            'popupsearch' => false,
          ),
          'label' => 'LBL_LIST_EMAIL_ADDRESS',
          'sortable' => false,
          'link' => true,
          'customCode' => '{$EMAIL1_LINK}{$EMAIL1}</a>',
        ),
        6 => 
        array (
          'name' => 'phone_work',
          'enabled' => true,
          'default' => true,
          'label' => 'LBL_OFFICE_PHONE',
        ),
        7 => 
        array (
          'name' => 'phone_mobile',
          'default' => true,
          'enabled' => true,
          'label' => 'LBL_MOBILE_PHONE',
        ),
        8 => 
        array (
          'name' => 'contact_type_c',
          'default' => true,
          'enabled' => true,
          'studio' => 'visible',
          'label' => 'LBL_CONTACT_TYPE',
        ),
        9 => 
        array (
          'name' => 'date_entered',
          'enabled' => true,
          'default' => true,
          'readonly' => true,
          'studio' => 
          array (
            'portaleditview' => false,
          ),
          'label' => 'LBL_DATE_ENTERED',
        ),
        10 => 
        array (
          'name' => 'date_modified',
          'enabled' => true,
          'default' => true,
        ),
        11 => 
        array (
          'name' => 'phone_other',
          'enabled' => true,
          'default' => true,
          'selected' => false,
        ),
        12 => 
        array (
          'name' => 'assistant_phone',
          'enabled' => true,
          'default' => true,
          'selected' => false,
        ),
        13 => 
        array (
          'name' => 'campaign_name',
          'default' => false,
          'enabled' => true,
          'link' => true,
          'label' => 'LBL_CAMPAIGN',
          'id' => 'CAMPAIGN_ID',
        ),
        14 => 
        array (
          'name' => 'created_by_name',
          'default' => false,
          'enabled' => true,
          'link' => true,
          'label' => 'LBL_CREATED',
          'id' => 'CREATED_BY',
        ),
        15 => 
        array (
          'name' => 'decision_maker_c',
          'default' => false,
          'enabled' => true,
          'label' => 'LBL_DECISION_MAKER',
        ),
        16 => 
        array (
          'name' => 'department',
          'default' => false,
          'enabled' => true,
          'label' => 'LBL_DEPARTMENT',
        ),
        17 => 
        array (
          'name' => 'lead_source',
          'default' => false,
          'enabled' => true,
          'label' => 'LBL_LEAD_SOURCE',
        ),
        18 => 
        array (
          'name' => 'primary_address_postalcode',
          'default' => false,
          'enabled' => true,
          'label' => 'LBL_PRIMARY_ADDRESS_POSTALCODE',
        ),
        19 => 
        array (
          'name' => 'employment_status_c',
          'label' => 'LBL_EMPLOYMENT_STATUS',
          'enabled' => true,
          'default' => false,
        ),
        20 => 
        array (
          'name' => 'assigned_user_name',
          'label' => 'LBL_LIST_ASSIGNED_USER',
          'id' => 'ASSIGNED_USER_ID',
          'enabled' => true,
          'default' => false,
          'link' => true,
        ),
        21 => 
        array (
          'name' => 'price_increase_c',
          'label' => 'LBL_PRICE_INCREASE',
          'enabled' => true,
          'readonly' => false,
          'default' => false,
        ),
      ),
    ),
  ),
);