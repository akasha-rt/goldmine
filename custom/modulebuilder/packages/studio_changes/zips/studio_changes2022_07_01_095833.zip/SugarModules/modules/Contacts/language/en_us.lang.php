<?php 
 // created: 2022-07-01 09:58:21
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITY_ROLE'] = 'Opportunity Role';
$mod_strings['LBL_OPPORTUNITY_ROLE_ID'] = 'Opportunity Role ID:';
$mod_strings['LBL_CONTACT_TYPE'] = 'Contact Type';
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Contact Information';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Marketing Information';
$mod_strings['LBL_PANEL_ASSIGNMENT'] = 'Assignment Information';
$mod_strings['LBL_DECISION_MAKER'] = 'Decision Maker';
$mod_strings['LBL_EMAIL_ADDRESS'] = 'Email Address:';
$mod_strings['LBL_FIRST_NAME'] = 'First Name:';
$mod_strings['LBL_LAST_NAME'] = 'Last Name:';
$mod_strings['LBL_OFFICE_PHONE'] = 'Office Phone:';
$mod_strings['LBL_BYTEWISE_SOURCE'] = 'Bytewise Source';
$mod_strings['LBL_PRODUCT_INTEREST'] = 'Product Interest';
$mod_strings['LBL_GOLDMINE_ID'] = 'Goldmine ID';
$mod_strings['LBL_SUGAR_ID'] = 'Sugar ID';

?>
