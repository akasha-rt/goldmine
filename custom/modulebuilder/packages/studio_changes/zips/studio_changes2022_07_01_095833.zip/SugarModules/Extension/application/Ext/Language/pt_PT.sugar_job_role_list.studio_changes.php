<?php 
$app_list_strings['job_role_list'] = array (
  'Customer Service' => 'Customer Service',
  'Operations Manager' => 'Operations Manager',
  'Owner' => 'Owner',
  'President' => 'President',
  'Purchasing' => 'Purchasing',
  'Sales Manager' => 'Sales Manager',
  'Sales Person' => 'Sales Person',
  'User' => 'User',
  '' => '',
  'Not Applicable' => 'Not Applicable',
);