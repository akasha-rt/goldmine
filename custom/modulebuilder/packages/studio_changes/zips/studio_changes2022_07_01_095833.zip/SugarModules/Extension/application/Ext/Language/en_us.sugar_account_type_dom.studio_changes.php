<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Customer' => 'End User',
  'Starrett Distributor' => 'Starrett Distributor',
  'Distributor' => 'Distributor',
  'Strategic' => 'Strategic Account',
  'Target' => 'Target Account',
  'School' => 'Instructor',
  'Student' => 'Student',
  'Supplier' => 'Supplier',
  'Competitor' => 'Competitor',
  'Employee' => 'Employee',
  'Starrett Employee' => 'Starrett Employee',
  'Starrett Agent' => 'Starrett Agent',
);