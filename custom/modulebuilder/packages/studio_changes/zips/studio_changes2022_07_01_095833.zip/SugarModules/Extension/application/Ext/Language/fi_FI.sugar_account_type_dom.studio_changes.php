<?php 
$app_list_strings['account_type_dom'] = array (
  '' => '',
  'Competitor' => 'Kilpailija',
  'Customer' => 'Asiakas',
  'Supplier' => 'Supplier',
  'Target' => 'Target Acct',
  'School' => 'Schools',
  'Strategic' => 'Strategic Account',
  'Student' => 'Student',
  'Starrett Distributor' => 'Starrett Distributor',
  'Distributor' => 'Distributor',
  'Employee' => 'Employee',
  'Starrett Employee' => 'Starrett Employee',
  'Starrett Agent' => 'Starrett Agent',
);