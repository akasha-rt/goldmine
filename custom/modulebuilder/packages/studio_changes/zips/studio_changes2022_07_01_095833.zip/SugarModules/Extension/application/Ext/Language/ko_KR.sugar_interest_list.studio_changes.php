<?php 
$app_list_strings['interest_list'] = array (
  '' => '',
  'Competitor' => 'Competitor',
  'OLP' => 'OLP',
  'PRO360' => 'PRO360',
  'S360' => 'S360',
  'Embossing' => 'Embossing',
  'NA' => 'N/A',
);