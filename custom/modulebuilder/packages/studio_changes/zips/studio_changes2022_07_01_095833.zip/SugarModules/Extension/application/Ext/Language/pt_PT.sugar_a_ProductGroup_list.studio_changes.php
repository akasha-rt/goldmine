<?php 
$app_list_strings['a_ProductGroup_list'] = array (
  'No' => 'No',
  'Yes' => 'Yes',
  'Optout' => 'Opt-out',
  'Unknown' => 'Unknown',
);