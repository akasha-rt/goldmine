<?php 
$app_list_strings['bytewise_rep_list'] = array (
  '' => '',
  'Brazil Team' => 'Brazil Team',
  'Flo Geyer' => 'Flo Geyer',
  'Gregg Strong' => 'Gregg Strong',
  'India Team' => 'India Team',
  'Jim Williams' => 'Jim Williams',
  'Kevin Yang' => 'Kevin Yang',
  'NA Rep 2' => 'NA Rep 2',
  'NA' => 'N/A',
);