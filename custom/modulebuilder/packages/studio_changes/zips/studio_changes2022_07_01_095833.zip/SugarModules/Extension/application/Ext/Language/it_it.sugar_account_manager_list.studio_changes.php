<?php 
$app_list_strings['account_manager_list'] = array (
  '' => '',
  'Jim Williams' => 'Jim Williams',
  'Gregg Strong' => 'Gregg Strong',
  'NA' => 'N/A',
);