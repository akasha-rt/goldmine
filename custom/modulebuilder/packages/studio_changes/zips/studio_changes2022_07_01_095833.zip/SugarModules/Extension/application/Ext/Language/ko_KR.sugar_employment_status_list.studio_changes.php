<?php 
$app_list_strings['employment_status_list'] = array (
  'Actively Employed' => 'Actively Employed',
  'No Longer Employed' => 'No Longer Employed',
  'Leave of Absence' => 'Leave of Absence',
);