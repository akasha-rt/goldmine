<?php 
$app_list_strings['three_d_access_request_list'] = array (
  'Null' => 'Null',
  'Pending' => 'Pending',
  'Approved' => 'Approved',
  'Denied' => 'Denied',
);