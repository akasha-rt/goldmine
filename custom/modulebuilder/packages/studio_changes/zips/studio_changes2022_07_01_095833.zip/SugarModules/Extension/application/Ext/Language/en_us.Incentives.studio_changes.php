<?php 
$app_list_strings['yes_no_c_list'] = array (
  'Yes' => 'Yes',
  'No' => 'No',
  '' => '',
);