<?php
 // created: 2019-09-13 16:23:44
$dictionary['Contact']['fields']['testing_equipment_c']['labelValue']='Testing Equipment (Group)';
$dictionary['Contact']['fields']['testing_equipment_c']['dependency']='';
$dictionary['Contact']['fields']['testing_equipment_c']['visibility_grid']='';

 ?>