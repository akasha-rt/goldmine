<?php
 // created: 2022-05-29 07:27:06
$dictionary['Contact']['fields']['reason_for_contact_c']['labelValue']='Reason for Contact';
$dictionary['Contact']['fields']['reason_for_contact_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['reason_for_contact_c']['enforced']='';
$dictionary['Contact']['fields']['reason_for_contact_c']['dependency']='';
$dictionary['Contact']['fields']['reason_for_contact_c']['required_formula']='';
$dictionary['Contact']['fields']['reason_for_contact_c']['readonly_formula']='';

 ?>