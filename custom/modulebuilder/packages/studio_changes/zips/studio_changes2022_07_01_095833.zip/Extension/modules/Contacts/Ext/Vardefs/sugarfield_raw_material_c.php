<?php
 // created: 2018-12-31 16:32:00
$dictionary['Contact']['fields']['raw_material_c']['duplicate_merge_dom_value']=0;
$dictionary['Contact']['fields']['raw_material_c']['dependency']='equal($saws_c,"Yes")';

 ?>