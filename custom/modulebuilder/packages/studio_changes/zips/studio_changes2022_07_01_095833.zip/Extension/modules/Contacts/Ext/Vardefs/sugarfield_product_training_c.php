<?php
 // created: 2021-02-15 20:23:54
$dictionary['Contact']['fields']['product_training_c']['labelValue']='Product Training';
$dictionary['Contact']['fields']['product_training_c']['enforced']='';
$dictionary['Contact']['fields']['product_training_c']['dependency']='';

 ?>