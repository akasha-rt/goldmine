<?php
 // created: 2021-03-21 22:20:00
$dictionary['Contact']['fields']['industry_c']['labelValue']='Industry';
$dictionary['Contact']['fields']['industry_c']['dependency']='';
$dictionary['Contact']['fields']['industry_c']['required_formula']='';
$dictionary['Contact']['fields']['industry_c']['readonly_formula']='';
$dictionary['Contact']['fields']['industry_c']['visibility_grid']='';

 ?>