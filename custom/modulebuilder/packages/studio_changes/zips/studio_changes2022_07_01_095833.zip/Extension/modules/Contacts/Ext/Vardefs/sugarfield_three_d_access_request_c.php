<?php
 // created: 2022-05-29 08:31:21
$dictionary['Contact']['fields']['three_d_access_request_c']['labelValue']='3D Access Request';
$dictionary['Contact']['fields']['three_d_access_request_c']['dependency']='';
$dictionary['Contact']['fields']['three_d_access_request_c']['required_formula']='';
$dictionary['Contact']['fields']['three_d_access_request_c']['readonly_formula']='';
$dictionary['Contact']['fields']['three_d_access_request_c']['visibility_grid']='';

 ?>