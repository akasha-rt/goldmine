<?php
 // created: 2021-02-15 20:24:30
$dictionary['Contact']['fields']['holiday_schedule_c']['labelValue']='Holiday Schedule';
$dictionary['Contact']['fields']['holiday_schedule_c']['enforced']='';
$dictionary['Contact']['fields']['holiday_schedule_c']['dependency']='';

 ?>