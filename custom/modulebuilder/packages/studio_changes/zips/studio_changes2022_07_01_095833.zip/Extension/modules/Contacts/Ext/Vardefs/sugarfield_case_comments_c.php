<?php
 // created: 2022-06-17 15:58:19
$dictionary['Contact']['fields']['case_comments_c']['labelValue']='Case Comments';
$dictionary['Contact']['fields']['case_comments_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['case_comments_c']['enforced']='';
$dictionary['Contact']['fields']['case_comments_c']['dependency']='';
$dictionary['Contact']['fields']['case_comments_c']['required_formula']='';
$dictionary['Contact']['fields']['case_comments_c']['readonly_formula']='';

 ?>