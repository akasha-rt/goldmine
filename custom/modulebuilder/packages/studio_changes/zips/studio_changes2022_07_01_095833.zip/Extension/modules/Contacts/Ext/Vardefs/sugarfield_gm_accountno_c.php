<?php
 // created: 2021-03-21 21:42:53
$dictionary['Contact']['fields']['gm_accountno_c']['labelValue']='GM Accountno';
$dictionary['Contact']['fields']['gm_accountno_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['gm_accountno_c']['enforced']='';
$dictionary['Contact']['fields']['gm_accountno_c']['dependency']='';
$dictionary['Contact']['fields']['gm_accountno_c']['required_formula']='';
$dictionary['Contact']['fields']['gm_accountno_c']['readonly_formula']='';

 ?>