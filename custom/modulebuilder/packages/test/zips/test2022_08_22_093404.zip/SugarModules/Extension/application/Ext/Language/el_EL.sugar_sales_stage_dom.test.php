<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Προσόν',
  'Proposal/Price Quote' => 'Πρόταση/Οικονομική Προσφορά',
  'Negotiation/Review' => 'Σε Διαπραγμάτευση/Αναθεώρηση',
  'Closed Won' => 'Έκλεισε Κερδισμένο',
  'Closed Lost' => 'Έκλεισε Χαμένη',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);