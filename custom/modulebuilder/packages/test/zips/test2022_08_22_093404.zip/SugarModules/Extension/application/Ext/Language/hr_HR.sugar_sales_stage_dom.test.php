<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalifikacija',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'Prijedlog / ponuda cijene',
  'Negotiation/Review' => 'Pregovori/pregled',
  'PO' => 'Waiting for Purchase Order',
  'Project on Delay' => 'Still Active On Hold',
  'Closed Won' => 'Zatvor. kao uspjelo',
  'Closed Lost' => 'Zatvor. kao neuspjelo',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Legacy' => 'Legacy',
);