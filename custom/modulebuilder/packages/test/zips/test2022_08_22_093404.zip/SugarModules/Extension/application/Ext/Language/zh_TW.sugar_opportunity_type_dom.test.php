<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => '現成事業',
  'New Business' => '新事業',
  'Conversion' => 'Conversion',
);