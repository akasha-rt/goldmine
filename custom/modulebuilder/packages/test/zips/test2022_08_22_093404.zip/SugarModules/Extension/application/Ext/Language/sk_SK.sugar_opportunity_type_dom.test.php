<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Existujúce podnikanie',
  'New Business' => 'Nové podnikanie',
  'Conversion' => 'Conversion',
);