<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => '기존 비즈니스',
  'New Business' => '새로운 비즈니스',
  'Conversion' => 'Conversion',
);