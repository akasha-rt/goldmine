<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Bestandsgeschäft',
  'New Business' => 'Neugeschäft',
  'Conversion' => 'Conversion',
);