<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalifikācija',
  'Proposal/Price Quote' => 'Ierosinājums/Cenas piedāvājums',
  'Negotiation/Review' => 'Pārrunas/Caurskate',
  'Closed Won' => 'Slēgts',
  'Closed Lost' => 'Aizvērts bez panākumiem',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);