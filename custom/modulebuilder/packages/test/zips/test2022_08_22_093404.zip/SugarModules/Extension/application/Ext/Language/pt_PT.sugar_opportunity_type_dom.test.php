<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Negócio existente',
  'New Business' => 'Novo negócio',
  'Conversion' => 'Conversion',
);