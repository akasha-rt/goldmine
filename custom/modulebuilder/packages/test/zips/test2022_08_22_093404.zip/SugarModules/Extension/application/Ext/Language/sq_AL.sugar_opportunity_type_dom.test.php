<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Biznes ekzistues',
  'New Business' => 'Biznes i ri',
  'Conversion' => 'Conversion',
);