<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Eksisterende virksomhet',
  'New Business' => 'Ny virksomhet',
  'Conversion' => 'Conversion',
);