<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'מגבלות',
  'Proposal/Price Quote' => 'הצעת מחיר',
  'Negotiation/Review' => 'משא ומתן',
  'Closed Won' => 'נסגר בהצלחה',
  'Closed Lost' => 'נסגר ואבד',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);