<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Istniejąca firma',
  'New Business' => 'Nowa firma',
  'Conversion' => 'Conversion',
);