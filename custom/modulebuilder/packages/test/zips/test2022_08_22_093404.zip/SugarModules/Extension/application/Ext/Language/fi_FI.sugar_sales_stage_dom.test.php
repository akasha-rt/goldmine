<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Valinta',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'Tarjous',
  'Negotiation/Review' => 'Neuvottelu/arvio',
  'PO' => 'Waiting for Purchase Order',
  'Closed Won' => 'Suljettu / voitettu',
  'Closed Lost' => 'Suljettu / hävitty',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);