<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalifisering',
  'Proposal/Price Quote' => 'Tilbud/prisoverslag',
  'Negotiation/Review' => 'Forhandling/gjennomgang',
  'Closed Won' => 'Lukket og vunnet',
  'Closed Lost' => 'Lukket og tapt',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);