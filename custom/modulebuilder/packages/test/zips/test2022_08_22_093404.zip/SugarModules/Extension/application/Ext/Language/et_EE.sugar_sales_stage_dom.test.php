<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalifikatsioon',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'Pakkumine/Hinnapakkumine',
  'Negotiation/Review' => 'Läbirääkimised/Ülevaade',
  'PO' => 'Waiting for Purchase Order',
  'Closed Won' => 'Closed Won',
  'Closed Lost' => 'Suletud kaotused',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);