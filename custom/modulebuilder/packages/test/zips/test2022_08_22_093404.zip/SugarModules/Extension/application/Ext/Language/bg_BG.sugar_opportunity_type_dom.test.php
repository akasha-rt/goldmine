<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Съществуваща фирма',
  'New Business' => 'Нова фирма',
  'Conversion' => 'Conversion',
);