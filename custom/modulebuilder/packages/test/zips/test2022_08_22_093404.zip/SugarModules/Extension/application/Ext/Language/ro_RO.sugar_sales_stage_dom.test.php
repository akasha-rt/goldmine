<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Calificare',
  'Proposal/Price Quote' => 'Propunere/ Cota de pret',
  'Negotiation/Review' => 'Negociere / Revizuire',
  'Closed Won' => 'Inchis Castigat',
  'Closed Lost' => 'Inchis pierdut',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);