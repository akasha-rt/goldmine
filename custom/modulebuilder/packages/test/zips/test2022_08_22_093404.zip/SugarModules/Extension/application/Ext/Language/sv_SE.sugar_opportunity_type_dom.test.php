<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Befintlig verksamhet',
  'New Business' => 'Ny verksamhet',
  'Conversion' => 'Conversion',
);