<?php 
$app_list_strings['case_type_dom'] = array (
  'Diagnosis' => 'Diagnosis',
  'Installation' => 'Installation',
  'Maintenance' => 'Maintenance',
  'Order Entry' => 'Order Entry',
  'Quote' => 'Quote',
  'Sales Support' => 'Sales Support',
  'Service' => 'Service',
  'Special Order' => 'Special Order',
  'Tech Support' => 'Tech Support',
  'Training' => 'Training',
  '' => '',
  'ecom_issue' => 'B2C e-commerce Issue',
);