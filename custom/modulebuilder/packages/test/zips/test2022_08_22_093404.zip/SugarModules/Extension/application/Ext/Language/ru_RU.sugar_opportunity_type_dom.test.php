<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Существующая компания',
  'New Business' => 'Новая компания',
  'Conversion' => 'Conversion',
);