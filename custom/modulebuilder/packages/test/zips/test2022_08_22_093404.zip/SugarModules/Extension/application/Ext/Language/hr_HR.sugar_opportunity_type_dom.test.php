<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Postojeće poduzeće',
  'New Business' => 'Novo poduzeće',
  'Conversion' => 'Conversion',
);