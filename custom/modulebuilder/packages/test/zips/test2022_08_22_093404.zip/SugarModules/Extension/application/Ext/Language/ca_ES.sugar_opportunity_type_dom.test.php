<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Negoci existent',
  'New Business' => 'Nous negocis',
  'Conversion' => 'Conversion',
);