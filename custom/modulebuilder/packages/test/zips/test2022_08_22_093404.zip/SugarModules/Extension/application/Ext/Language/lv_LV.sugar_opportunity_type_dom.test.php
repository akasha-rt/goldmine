<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Esošs uzņēmums',
  'New Business' => 'Jauns uzņēmums',
  'Conversion' => 'Conversion',
);