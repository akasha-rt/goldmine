<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'New Business' => 'New Business',
  'Conversion' => 'Conversion',
  'Existing Business' => 'Existing Business',
);