<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Negocio existente',
  'New Business' => 'Nuevo negocio',
  'Conversion' => 'Conversion',
);