<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalificering',
  'Proposal/Price Quote' => 'Förslag/Offert',
  'Negotiation/Review' => 'Förhandling',
  'Closed Won' => 'Stängd Vunnen',
  'Closed Lost' => 'Stängd förlorad',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);