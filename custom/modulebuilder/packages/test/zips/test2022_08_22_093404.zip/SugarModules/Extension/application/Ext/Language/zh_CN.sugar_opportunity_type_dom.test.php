<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => '现有业务',
  'New Business' => '新业务',
  'Conversion' => 'Conversion',
);