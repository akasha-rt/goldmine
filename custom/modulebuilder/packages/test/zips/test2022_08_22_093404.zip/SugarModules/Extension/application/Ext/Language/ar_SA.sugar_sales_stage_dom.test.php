<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'التأهل',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'عرض السعر/الاقتراح',
  'Negotiation/Review' => 'التفاوض/المراجعة',
  'PO' => 'Waiting for Purchase Order',
  'Project on Delay' => 'Still Active On Hold',
  'Closed Won' => 'إغلاق لسبب الفوز',
  'Closed Lost' => 'إغلاق لسبب الخساره',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Legacy' => 'Legacy',
);