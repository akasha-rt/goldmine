<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Υφιστάμενη επιχείρηση',
  'New Business' => 'Νέα επιχείρηση',
  'Conversion' => 'Conversion',
);