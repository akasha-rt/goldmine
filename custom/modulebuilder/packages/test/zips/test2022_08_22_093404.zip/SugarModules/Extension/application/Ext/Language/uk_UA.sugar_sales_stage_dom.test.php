<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Кваліфікація',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'Пропозиція/Цінова пропозиція',
  'Negotiation/Review' => 'Обговорення умов/Розгляд',
  'PO' => 'Waiting for Purchase Order',
  'Project on Delay' => 'Still Active On Hold',
  'Closed Won' => 'Успішно закритий',
  'Closed Lost' => 'Втрачений',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Legacy' => 'Legacy',
);