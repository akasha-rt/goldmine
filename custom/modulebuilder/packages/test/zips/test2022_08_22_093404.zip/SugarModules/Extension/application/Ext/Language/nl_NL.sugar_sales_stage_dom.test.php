<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kwalificatie',
  'Proposal/Price Quote' => 'Voorstel/Offerte',
  'Negotiation/Review' => 'Onderhandeling/Beoordeling',
  'Closed Won' => 'Afgesloten - Gewonnen',
  'Closed Lost' => 'Afgesloten - Verloren',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);