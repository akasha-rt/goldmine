<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Meglévő üzlet',
  'New Business' => 'Új üzlet',
  'Conversion' => 'Conversion',
);