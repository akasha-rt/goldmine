<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kalifikasyon',
  'Proposal/Price Quote' => 'Teklif/Fiyat Verme',
  'Negotiation/Review' => 'Anlaşma/İnceleme',
  'Closed Won' => 'Kapalı',
  'Closed Lost' => 'Başarısızlıkla Kapandı',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);