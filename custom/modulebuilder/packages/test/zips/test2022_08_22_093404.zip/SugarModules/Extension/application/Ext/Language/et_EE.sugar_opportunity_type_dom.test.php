<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Olemasolev ettevõte',
  'New Business' => 'Uus ettevõte',
  'Conversion' => 'Conversion',
);