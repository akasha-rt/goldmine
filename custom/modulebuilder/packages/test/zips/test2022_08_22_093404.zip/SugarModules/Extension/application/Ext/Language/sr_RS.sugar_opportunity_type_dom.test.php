<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Postojeći biznis',
  'New Business' => 'Novi biznis',
  'Conversion' => 'Conversion',
);