<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => '既存ビジネス',
  'New Business' => '新規ビジネス',
  'Conversion' => 'Conversion',
);