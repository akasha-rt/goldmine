<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalifikácia',
  'Proposal/Price Quote' => 'Návrh / Cenová ponuka',
  'Negotiation/Review' => 'Vyjednávanie / recenzie',
  'Closed Won' => 'Zatvorený',
  'Closed Lost' => 'Uzatvorená prehra',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);