<?php 
$app_list_strings['opportunity_type_dom'] = array (
  '' => '',
  'Existing Business' => 'Eksisterende forretning',
  'New Business' => 'Ny forretning',
  'Conversion' => 'Conversion',
);