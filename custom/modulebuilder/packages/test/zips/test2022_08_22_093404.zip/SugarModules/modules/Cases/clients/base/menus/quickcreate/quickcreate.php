<?php
// created: 2016-10-16 03:25:50
$viewdefs['Cases']['base']['menu']['quickcreate'] = array (
  'layout' => 'create',
  'label' => 'LNK_NEW_CASE',
  'visible' => false,
  'icon' => 'fa-plus',
  'order' => 12,
);