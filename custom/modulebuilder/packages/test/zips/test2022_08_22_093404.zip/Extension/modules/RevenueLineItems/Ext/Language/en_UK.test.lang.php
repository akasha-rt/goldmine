<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Create Revenue Line Item';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Itemsssssssss';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Revenue Line Item';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Create Revenue Line Item';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'View Revenue Line Itemsssssssss';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Import Revenue Line Itemsssssssss';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Revenue Line Item List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Revenue Line Item Search';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Itemsssssssss: Home';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Itemsssssssss';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Itemsssssssss';
$mod_strings['LBL_CONVERT_INVALID_RLI'] = 'One or more of the Revenue Line Itemsssssssss that you selected can not be converted into a Quote:';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = 'One or more of the Revenue Line Itemsssssssss needs a Product from the Product Catalog before a Quote can be generated.';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = 'One or more of the selected Revenue Line Itemsssssssss are already quoted.';
$mod_strings['LBL_REVENUE_LINE_ITEMS_FOCUS_DRAWER_DASHBOARD'] = 'Revenue Line Itemssssssssss Focus Drawer';
$mod_strings['LBL_REVENUE_LINE_ITEMS_RECORD_DASHBOARD'] = 'Revenue Line Itemssssssssss Record Dashboard';
$mod_strings['LBL_REVENUE_LINE_ITEMS_LIST_DASHBOARD'] = 'Revenue Line Itemssssssssss List Dashboard';
