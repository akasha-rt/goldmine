<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Създаване на приходна позиция';
$mod_strings['LBL_MODULE_NAME'] = 'Приходни позиции';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Приходна позиция';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Създай приходна позиция';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Списък с приходни позиции';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Импортиране на приходни позиции';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Списък на приходни позиции';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Търсене в приходни позиции';
