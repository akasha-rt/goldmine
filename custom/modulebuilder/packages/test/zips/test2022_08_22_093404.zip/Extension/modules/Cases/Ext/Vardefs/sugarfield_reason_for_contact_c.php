<?php
 // created: 2022-03-18 05:36:09
$dictionary['Case']['fields']['reason_for_contact_c']['labelValue']='Reason for Contact';
$dictionary['Case']['fields']['reason_for_contact_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Case']['fields']['reason_for_contact_c']['enforced']='';
$dictionary['Case']['fields']['reason_for_contact_c']['dependency']='';
$dictionary['Case']['fields']['reason_for_contact_c']['required_formula']='';
$dictionary['Case']['fields']['reason_for_contact_c']['readonly_formula']='';

 ?>