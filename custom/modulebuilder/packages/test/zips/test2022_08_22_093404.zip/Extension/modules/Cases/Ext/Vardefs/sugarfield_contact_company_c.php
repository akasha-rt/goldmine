<?php
 // created: 2022-05-29 07:30:49
$dictionary['Case']['fields']['contact_company_c']['labelValue']='Contact Company';
$dictionary['Case']['fields']['contact_company_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Case']['fields']['contact_company_c']['enforced']='';
$dictionary['Case']['fields']['contact_company_c']['dependency']='';
$dictionary['Case']['fields']['contact_company_c']['required_formula']='';
$dictionary['Case']['fields']['contact_company_c']['readonly_formula']='';

 ?>