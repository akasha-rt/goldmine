<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Gelir Kalemi Oluştur';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Gelir Kalemi';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Gelir Kalemi Oluştur';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Revenue Line Itemsni Görüntüle';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Revenue Line Itemsni İçeri Aktar';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Gelir Kalemleri Listesi';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Gelir Kalemlerini Ara';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items: Ana Sayfa';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_CONVERT_INVALID_RLI'] = 'Seçtiğiniz Revenue Line Items bir veya daha fazla Teklif dönüştürülebilir olamaz:';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = 'Teklif oluşturabilmek için önce Revenue Line Itemsnden bir veya daha fazlası için Ürün Kataloğundan ürün eklemeniz gerekiyor.';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = 'Seçilen Revenue Line Items bir veya daha fazla zaten işlem görmektedir.';
