<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Crear una Ganancia de Artículo';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Ganancia de Artículo';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Cear una Ganancia de Artículo';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Ver Revenue Line Itemss';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importar Revenue Line Items';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista de una Ganancia de Artículo';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Búsqueda de una Ganancia de Artículo';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items: Inicio';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
