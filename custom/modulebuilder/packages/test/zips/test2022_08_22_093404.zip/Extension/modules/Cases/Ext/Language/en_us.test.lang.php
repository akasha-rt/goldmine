<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_PRODUCT_GROUP'] = 'Product Group_old';
$mod_strings['LBL_CATALOG_NUMBER'] = 'Catalog Number_old';
$mod_strings['LBL_REASON_FOR_CONTACT'] = 'Reason for Contact';
$mod_strings['LBL_CONTACT_COMPANY_C'] = 'Contact Company';
$mod_strings['LBL_PRIMARY_CONTACT_NAME'] = 'Contact Person';
$mod_strings['LBL_NUMBER'] = 'Case Number:';
