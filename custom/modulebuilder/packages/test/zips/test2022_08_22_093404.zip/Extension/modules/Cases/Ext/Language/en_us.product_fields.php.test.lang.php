<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_PRODUCT_GROUP_REL'] = 'Product Group';
$mod_strings['LBL_CATALOG_NUMBER_REL'] = 'Catalog Number';
