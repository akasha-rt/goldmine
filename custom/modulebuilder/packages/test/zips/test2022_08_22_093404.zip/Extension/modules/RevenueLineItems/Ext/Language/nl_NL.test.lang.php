<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Nieuwe opportunityregel';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Itemss';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Opportunityregel';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Nieuwe opportunityregel';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Bekijk opportunityregels';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importeer opportunityregels';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Opportunityregellijst';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Opportunityregel zoeken';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Itemss: start';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Itemss';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Itemss';
