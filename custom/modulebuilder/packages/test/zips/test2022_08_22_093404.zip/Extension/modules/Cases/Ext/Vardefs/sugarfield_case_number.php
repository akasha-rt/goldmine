<?php
 // created: 2022-08-05 17:52:02
$dictionary['Case']['fields']['case_number']['len']='11';
$dictionary['Case']['fields']['case_number']['audited']=false;
$dictionary['Case']['fields']['case_number']['massupdate']=true;
$dictionary['Case']['fields']['case_number']['hidemassupdate']=false;
$dictionary['Case']['fields']['case_number']['comments']='Visual unique identifier';
$dictionary['Case']['fields']['case_number']['merge_filter']='disabled';
$dictionary['Case']['fields']['case_number']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.29',
  'searchable' => true,
);
$dictionary['Case']['fields']['case_number']['calculated']=false;
$dictionary['Case']['fields']['case_number']['enable_range_search']=false;
$dictionary['Case']['fields']['case_number']['autoinc_next']='2650';
$dictionary['Case']['fields']['case_number']['min']=false;
$dictionary['Case']['fields']['case_number']['max']=false;
$dictionary['Case']['fields']['case_number']['disable_num_format']='1';

 ?>