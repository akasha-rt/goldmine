<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Napravite stavku prihoda';
$mod_strings['LBL_MODULE_NAME'] = 'Stavke prihoda';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Stavka prihoda';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Kreiraj proizvod';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Pogledaj stavke prihoda';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Uvezi stavke prihoda';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista proizvoda';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Pretraga proizvoda';
