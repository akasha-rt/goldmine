<?php
 // created: 2022-08-11 20:55:29
$dictionary['Case']['fields']['account_id']['name']='account_id';
$dictionary['Case']['fields']['account_id']['type']='relate';
$dictionary['Case']['fields']['account_id']['dbType']='id';
$dictionary['Case']['fields']['account_id']['rname']='id';
$dictionary['Case']['fields']['account_id']['module']='Accounts';
$dictionary['Case']['fields']['account_id']['id_name']='account_id';
$dictionary['Case']['fields']['account_id']['reportable']=false;
$dictionary['Case']['fields']['account_id']['vname']='LBL_ACCOUNT_ID';
$dictionary['Case']['fields']['account_id']['audited']=false;
$dictionary['Case']['fields']['account_id']['massupdate']=false;
$dictionary['Case']['fields']['account_id']['comment']='The account to which the case is associated';
$dictionary['Case']['fields']['account_id']['importable']='true';

 ?>