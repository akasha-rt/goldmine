<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Créer Ligne de revenu';
$mod_strings['LBL_MODULE_NAME'] = 'Lignes de revenu';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Ligne de revenu';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Créer Ligne de revenu';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Voir les lignes de revenu';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importer des Lignes de revenu';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lignes de revenu';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Rechercher Lignes de revenu';
