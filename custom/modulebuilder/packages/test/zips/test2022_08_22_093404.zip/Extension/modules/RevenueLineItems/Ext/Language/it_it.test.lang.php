<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Crea Elemento dell&#039;Opportunità';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Elemento dell´Opportunità';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Crea Elemento dell&#039;Opportunità';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Visualizzare Elementi dell&#039;Opportunità';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importa Elementi dell&#039;Opportunità';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Elenco Elementi dell&#039;Opportunità';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Cerca Elemento dell&#039;Opportunità';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items: Home';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = 'Uno o più tra gli Revenue Line Items necessitano di un Prodotto dal Catalogo Prodotti prima di poter generare un´Offerta.';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = 'Uno o più tra gli Revenue Line Items sono già quotati.';
