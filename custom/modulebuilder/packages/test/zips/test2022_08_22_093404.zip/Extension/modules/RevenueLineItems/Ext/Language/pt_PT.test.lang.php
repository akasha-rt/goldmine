<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Criar Item de Linha de Receita';
$mod_strings['LBL_MODULE_NAME'] = 'Itens de Linha de Receita';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Item de Linha de Receita';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Criar Produto';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Visualizar Itens de Linha de Receita';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importar Itens de Linha de Receita';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista de Produtos';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Pesquisar Produtos';
