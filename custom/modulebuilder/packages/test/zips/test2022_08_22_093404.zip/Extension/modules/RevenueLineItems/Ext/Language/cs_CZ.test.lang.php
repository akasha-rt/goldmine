<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Vytvořit řádek tržby';
$mod_strings['LBL_MODULE_NAME'] = 'Řádky tržeb';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Řádek tržby';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Vytvořit řádek tržby';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Zobrazit řádky tržby';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importovat řádky tržeb';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Seznam řádků tržeb';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Vyhledat řádek tržby';
