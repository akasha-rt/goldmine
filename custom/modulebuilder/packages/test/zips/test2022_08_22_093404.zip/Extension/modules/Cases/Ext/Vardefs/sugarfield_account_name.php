<?php
 // created: 2022-08-11 20:55:29
$dictionary['Case']['fields']['account_name']['len']=255;
$dictionary['Case']['fields']['account_name']['required']=false;
$dictionary['Case']['fields']['account_name']['audited']=true;
$dictionary['Case']['fields']['account_name']['massupdate']=true;
$dictionary['Case']['fields']['account_name']['hidemassupdate']=false;
$dictionary['Case']['fields']['account_name']['comments']='The name of the account represented by the account_id field';
$dictionary['Case']['fields']['account_name']['importable']='true';
$dictionary['Case']['fields']['account_name']['duplicate_merge']='enabled';
$dictionary['Case']['fields']['account_name']['duplicate_merge_dom_value']='1';
$dictionary['Case']['fields']['account_name']['merge_filter']='disabled';
$dictionary['Case']['fields']['account_name']['reportable']=false;
$dictionary['Case']['fields']['account_name']['calculated']=false;
$dictionary['Case']['fields']['account_name']['related_fields']=array (
  0 => 'account_id',
);

 ?>