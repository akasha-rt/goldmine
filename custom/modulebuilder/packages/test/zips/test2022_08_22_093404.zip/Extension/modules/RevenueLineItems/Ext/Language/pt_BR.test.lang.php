<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Criar Receita item de linha';
$mod_strings['LBL_MODULE_NAME'] = 'Receita Itens de Linha';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Receita Item de Linha';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Criar Produto';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Visualizar receita itens de linha';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importar Receita Itens de Linha';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista de Produtos';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Pesquisar Produtos';
