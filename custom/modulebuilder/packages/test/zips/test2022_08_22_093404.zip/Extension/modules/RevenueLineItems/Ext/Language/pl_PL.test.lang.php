<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Utwórz pozycję szansy';
$mod_strings['LBL_MODULE_NAME'] = 'Pozycje szansy';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Pozycja szansy';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Utwórz pozycję szansy';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Pokaż pozycje szansy';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importuj pozycje szansy';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Pozycje szansy';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Wyszukiwanie pozycji szansy';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = 'Co najmniej jedna Revenue Line Items wymaga Produktu z Katalogu Produktów zanim Oferta będzie mogła zostać wygenerowana.';
