<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Izveidot ieņēmumu posteni';
$mod_strings['LBL_MODULE_NAME'] = 'Ieņēmumu posteņi';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Ieņēmumu postenis';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Izveidot ieņēmumu posteni';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Ieņēmumu posteņi';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importēt ieņēmumu posteņus';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Ieņēmumu posteņu saraksts';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Ieņēmumu posteņa meklēšana';
