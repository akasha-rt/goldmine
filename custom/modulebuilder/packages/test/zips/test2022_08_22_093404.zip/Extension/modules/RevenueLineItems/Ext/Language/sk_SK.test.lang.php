<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Vytvoriť položku krivky výnosu';
$mod_strings['LBL_MODULE_NAME'] = 'Položky krivky výnosu';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Položka krivky výnosu';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Vytvoriť položku krivky výnosu';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Zobraziť položky krivky výnosu';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Import položiek krivky výnosu';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Zoznam položku krivky výnosu';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Vyhľadať položku krivky výnosu';
