<?php
// created: 2022-08-05 17:52:02
$extensionOrderMap = array (
  'custom/Extension/modules/Cases/Ext/Language/en_us.product_fields.php' => 
  array (
    'md5' => '2d2e75350f63470e2579197d1d80dfcd',
    'mtime' => 1658725798,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Language/en_us.lang.php' => 
  array (
    'md5' => 'f8714d3c0add50abbd6c0a53980e73aa',
    'mtime' => 1659721922,
    'is_override' => false,
  ),
);