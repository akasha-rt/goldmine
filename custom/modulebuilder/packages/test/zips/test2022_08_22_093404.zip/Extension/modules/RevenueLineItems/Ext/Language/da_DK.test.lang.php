<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Opret Revenue Linjepost';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Revenue detaljposter';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Opret Revenue Linjepost';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Vis indtægtsposter';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importere indtægtspost';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Revenue detaljpost liste';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Søg i revenue';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items: Startside';
