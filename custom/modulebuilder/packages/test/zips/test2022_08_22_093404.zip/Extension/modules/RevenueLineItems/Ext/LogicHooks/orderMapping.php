<?php
// created: 2022-06-11 03:11:22
$extensionOrderMap = array (
  'modules/RevenueLineItems/Ext/LogicHooks/QueuePurchaseGeneration.php' => 
  array (
    'md5' => 'cd8f97adc1164b50cc6a5cec43e31433',
    'mtime' => 1616519170,
    'is_override' => false,
  ),
  'modules/RevenueLineItems/Ext/LogicHooks/ResaveRLIForAccounts.php' => 
  array (
    'md5' => '761180d35a74ea790cef184e264e280a',
    'mtime' => 1616519170,
    'is_override' => false,
  ),
  'modules/RevenueLineItems/Ext/LogicHooks/SetCommitStageForClosedWon.php' => 
  array (
    'md5' => 'ef365c492ec140faec1ca1a9cfb330c2',
    'mtime' => 1616519170,
    'is_override' => false,
  ),
  'modules/RevenueLineItems/Ext/LogicHooks/SetForecastCommitStage.php' => 
  array (
    'md5' => '837ce12da44da72c9fe3582c73276760',
    'mtime' => 1616519170,
    'is_override' => false,
  ),
  'modules/RevenueLineItems/Ext/LogicHooks/SyncBestWorstWithLikely.php' => 
  array (
    'md5' => '9d6451efa9a406d12690e1bbcdadb090',
    'mtime' => 1616519170,
    'is_override' => false,
  ),
  'custom/Extension/modules/RevenueLineItems/Ext/LogicHooks/denorm_field_hook.php' => 
  array (
    'md5' => 'fec67ccbfe263c6c56732c1ff550748a',
    'mtime' => 1638337693,
    'is_override' => false,
  ),
  'modules/RevenueLineItems/Ext/LogicHooks/GenerateRenewalOpportunity.php' => 
  array (
    'md5' => '9541c9d9b6635e3385cc8fed8f2209c7',
    'mtime' => 1649221076,
    'is_override' => false,
  ),
);