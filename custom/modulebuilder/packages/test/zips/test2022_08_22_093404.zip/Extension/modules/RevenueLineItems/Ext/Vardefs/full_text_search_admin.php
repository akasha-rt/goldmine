<?php
 // created: 2022-05-25 15:54:16
$dictionary['RevenueLineItem']['full_text_search']=true;
