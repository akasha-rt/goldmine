<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Завести доход по продукту';
$mod_strings['LBL_MODULE_NAME'] = 'Доход по продуктам';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Доход по продукту';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Завести доход по продукту';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Просмотреть доход по продуктам:';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Импортировать доход по продуктам';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Список дохода по продукту';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Поиск дохода по продукту';
