<?php
// created: 2022-08-11 20:55:32
$extensionOrderMap = array (
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_type.php' => 
  array (
    'md5' => 'b47f4cecc8c2c4ef4ca9f7eaf6cce17e',
    'mtime' => 1626360846,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/denorm_account_name.php' => 
  array (
    'md5' => 'bc49db11e51d09cbff42458d9e34f91e',
    'mtime' => 1638340092,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_reason_for_contact_c.php' => 
  array (
    'md5' => '06c738d99dbc3ed5ed7697f4d73e9130',
    'mtime' => 1647581769,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/full_text_search_admin.php' => 
  array (
    'md5' => 'a081f1dccfc3c5830dfa511c9d647208',
    'mtime' => 1653494056,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_contact_company_c.php' => 
  array (
    'md5' => 'efe26cc717b9c5b4ca248e5b146bacf2',
    'mtime' => 1653809449,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_product_group_c.php' => 
  array (
    'md5' => 'dae9cd142b8239e5f333acb818293bae',
    'mtime' => 1658436768,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_catalog_number_c.php' => 
  array (
    'md5' => '20e9dbd14e72eecf91cb19dd6ba32d5a',
    'mtime' => 1658436814,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/product_fields.php' => 
  array (
    'md5' => 'ee5b637eca4719a4945e20afa60e9b51',
    'mtime' => 1658725798,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_primary_contact_id.php' => 
  array (
    'md5' => '95772d2cbdf93d141f20cbcbb41179a0',
    'mtime' => 1659721884,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_primary_contact_name.php' => 
  array (
    'md5' => '396bda713e6b780bdec9fabd42e35201',
    'mtime' => 1659721884,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_case_number.php' => 
  array (
    'md5' => '98da3701519c61f96b694ff8d38e3fa7',
    'mtime' => 1659721922,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_description.php' => 
  array (
    'md5' => '552ec47b4fef4eb90922aff25be1ed7c',
    'mtime' => 1660055519,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_account_id.php' => 
  array (
    'md5' => 'e860449dc3aede8fe304149c36c6e15c',
    'mtime' => 1660251329,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/Vardefs/sugarfield_account_name.php' => 
  array (
    'md5' => '06df4dae99c755c97181a39b8e3c0995',
    'mtime' => 1660251330,
    'is_override' => false,
  ),
);