<?php
// created: 2022-05-25 15:54:39
$extensionOrderMap = array (
  'custom/Extension/modules/RevenueLineItems/Ext/Vardefs/rli_vardef.ext.php' => 
  array (
    'md5' => '9610a8864a6c6c53b87fd7200106b1f8',
    'mtime' => 1604144252,
    'is_override' => false,
  ),
  'custom/Extension/modules/RevenueLineItems/Ext/Vardefs/sugarfield_probability.php' => 
  array (
    'md5' => '5808e6971a73769495ccab8fcd6250b0',
    'mtime' => 1621615114,
    'is_override' => false,
  ),
  'custom/Extension/modules/RevenueLineItems/Ext/Vardefs/denorm_account_name.php' => 
  array (
    'md5' => '09ed0c843ed9cf92700a550957fcbafe',
    'mtime' => 1638337689,
    'is_override' => false,
  ),
  'custom/Extension/modules/RevenueLineItems/Ext/Vardefs/full_text_search_admin.php' => 
  array (
    'md5' => '2df4541acd1c599200622d20f54bcab1',
    'mtime' => 1653494056,
    'is_override' => false,
  ),
);