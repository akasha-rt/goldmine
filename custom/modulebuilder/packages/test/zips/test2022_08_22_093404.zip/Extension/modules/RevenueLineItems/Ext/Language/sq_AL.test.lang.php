<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Krijo rrjesht të të ardhurave:';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Rrjeshti i të të ardhurave:';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Krijo rresht të të ardhurave';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Shiko rreshtin e të ardhurave';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importimi i rreshtave të të ardhurave';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista e rrjeshtit të të ardhurave:';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Kërko rrjesht të të ardhurave:';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
