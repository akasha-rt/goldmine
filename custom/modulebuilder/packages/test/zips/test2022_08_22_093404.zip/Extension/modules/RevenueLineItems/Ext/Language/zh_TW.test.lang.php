<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_MODULE_TITLE'] = '收入項目：首頁';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = '收入項目';
$mod_strings['LBL_CONVERT_INVALID_RLI'] = '所選一個或多個「收入項目」無法轉換成「報價」：';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = '一個或多個「收入項目」需從「產品目錄」中獲取「產品」，才能產生「報價」。';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = '一個或多個所選「收入項目」已報價。';
