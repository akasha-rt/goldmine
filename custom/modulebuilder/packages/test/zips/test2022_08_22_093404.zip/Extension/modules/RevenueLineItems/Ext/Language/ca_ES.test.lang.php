<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Crear Línia d&#039;impostos articles';
$mod_strings['LBL_MODULE_NAME'] = 'Línia d&#039;impostos articles';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Línia d&#039;impostos articles';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Nova línia d&#039;impostos articles';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'View Revenue Line Items';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Import de les línies d&#039;ingressos';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Llista de línies d&#039;impostos articles';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Cercar Línia d&#039;impostos articles';
