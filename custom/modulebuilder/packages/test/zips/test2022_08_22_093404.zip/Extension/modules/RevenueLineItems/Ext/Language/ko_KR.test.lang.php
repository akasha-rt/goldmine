<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = '신규 수익상품 만들기';
$mod_strings['LBL_MODULE_NAME'] = '매출라인 품목목록';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = '매출라인 품목';
$mod_strings['LBL_NEW_FORM_TITLE'] = '신규 상품 만들기';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = '수익상품 보기';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = '매출라인 품목목록목록목록목록목록목록 가져오기';
$mod_strings['LBL_LIST_FORM_TITLE'] = '상품 목록';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = '상품 검색';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = '매출라인 품목목록목록목록목록목록목록';
