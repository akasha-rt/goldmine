<?php
// created: 2021-12-01 06:28:17
$extensionOrderMap = array (
  'modules/Cases/Ext/LogicHooks/RelationshipHook.php' => 
  array (
    'md5' => 'c8d84c5562d6934c11dbedb0335f1dad',
    'mtime' => 1625078063,
    'is_override' => false,
  ),
  'custom/Extension/modules/Cases/Ext/LogicHooks/denorm_field_hook.php' => 
  array (
    'md5' => 'fec67ccbfe263c6c56732c1ff550748a',
    'mtime' => 1638340097,
    'is_override' => false,
  ),
);