<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_MODULE_NAME'] = 'Tuoterivitttttt';
$mod_strings['LBL_MODULE_TITLE'] = 'Tuoterivitttttt: Etusivu';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Tuoterivitttttt';
$mod_strings['LBL_REVENUE_LINE_ITEMS_FOCUS_DRAWER_DASHBOARD'] = 'Tuoterivittttt-tietolaatikko';
