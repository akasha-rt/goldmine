<?php
 // created: 2022-08-05 17:51:24
$dictionary['Case']['fields']['primary_contact_id']['name']='primary_contact_id';
$dictionary['Case']['fields']['primary_contact_id']['type']='id';
$dictionary['Case']['fields']['primary_contact_id']['group']='primary_contact_name';
$dictionary['Case']['fields']['primary_contact_id']['reportable']=true;
$dictionary['Case']['fields']['primary_contact_id']['vname']='LBL_PRIMARY_CONTACT_ID';
$dictionary['Case']['fields']['primary_contact_id']['audited']=false;
$dictionary['Case']['fields']['primary_contact_id']['importable']='true';

 ?>