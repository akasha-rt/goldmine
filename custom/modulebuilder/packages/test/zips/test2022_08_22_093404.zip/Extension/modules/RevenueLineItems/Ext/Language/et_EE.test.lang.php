<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Create Revenue Line Item';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Revenue Line Item';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Create Revenue Line Item';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'View Revenue Line Items';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Import Revenue Line Items';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Revenue Line Item List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Revenue Line Item Search';
