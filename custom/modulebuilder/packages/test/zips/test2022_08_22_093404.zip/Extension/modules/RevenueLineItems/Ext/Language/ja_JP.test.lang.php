<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = '商談品目を作成';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = '商談品目';
$mod_strings['LBL_NEW_FORM_TITLE'] = '商品作成';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Revenue Line Itemsを見る';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Revenue Line Itemsをインポートする';
$mod_strings['LBL_LIST_FORM_TITLE'] = '商品一覧';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = '商品検索';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_CONVERT_INVALID_RLI'] = '選択されたRevenue Line Itemsから見積を作成することができません:';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = 'ひとつかそれ以上のRevenue Line Itemsは、見積を作成する前に商品カタログから商品を必要とします。';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = 'ひとつかそれ以上の選択されたRevenue Line Itemsは既に見積されています。';
