<?php
 // created: 2022-07-21 20:53:34
$dictionary['Case']['fields']['catalog_number_c']['labelValue']='Catalog Number_old';
$dictionary['Case']['fields']['catalog_number_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Case']['fields']['catalog_number_c']['enforced']='';
$dictionary['Case']['fields']['catalog_number_c']['dependency']='';
$dictionary['Case']['fields']['catalog_number_c']['required_formula']='';
$dictionary['Case']['fields']['catalog_number_c']['readonly_formula']='';

 ?>