<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Crear una Línea de Ingreso';
$mod_strings['LBL_MODULE_NAME'] = 'Líneas de Ingreso';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Línea de Ingreso';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Crear una Línea de Ingreso';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Ver Líneas de Ingreso';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importar Líneas de Ingresos';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Listado de Líneas de Ingresos';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Búsqueda de Línea de Ingreso';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items: Home';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
