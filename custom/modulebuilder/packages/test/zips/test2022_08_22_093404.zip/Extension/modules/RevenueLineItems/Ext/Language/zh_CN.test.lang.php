<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = '创建收入线项目';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = '收入线项目';
$mod_strings['LBL_NEW_FORM_TITLE'] = '创建收入线项目';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = '查看Revenue Line Items';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = '导入Revenue Line Items';
$mod_strings['LBL_LIST_FORM_TITLE'] = '收入线项目列表';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = '查找收入线项目';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items：首页';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_CONVERT_INVALID_RLI'] = '您选择的Revenue Line Items中的一个或多个不能转换成一个报价：';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = '一个或多个选中的Revenue Line Items已经报价。';
