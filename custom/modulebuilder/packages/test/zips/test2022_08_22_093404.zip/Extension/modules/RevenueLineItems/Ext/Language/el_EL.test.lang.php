<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Δημιουργία Γραμμής Στοιχείων Εσόδων';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Γραμμή Στοιχείων Εσόδων';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Δημιουργία Γραμμής Στοιχείων Εσόδων';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Προβολή Γραμμής Στοιχείων Εσόδου';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Εισαγωγή Στοιχείων Γραμμή Εσόδων';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Γραμμή Στοιχείων Εσόδων, Λίστα';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Γραμμή Στοιχείων Εσόδων, Αναζήτηση';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Items: Αρχή';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
