<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Neuer Umsatzposten';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Items';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Umsatzposten';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Neues Produkt';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Revenue Line Items Liste';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Revenue Line Items importieren';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Produktliste';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Produkte Suche';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Items';
$mod_strings['LBL_CONVERT_INVALID_RLI'] = 'Einer oder mehrere Revenue Line Items die Sie ausgewählt haben können nicht in ein Angebot konvertiert werden:';
$mod_strings['LBL_CONVERT_INVALID_RLI_PRODUCT_PLURAL'] = 'Ein oder mehrere Revenue Line Items benötigen ein Produkt aus dem Produktkatalog bevor ein Angebot erstellt werden kann.';
$mod_strings['LBL_CONVERT_INVALID_RLI_ALREADYQUOTED_PLURAL'] = 'Ein oder mehrere der ausgewählten Revenue Line Items wurden bereits in ein Angebot übernommen.';
