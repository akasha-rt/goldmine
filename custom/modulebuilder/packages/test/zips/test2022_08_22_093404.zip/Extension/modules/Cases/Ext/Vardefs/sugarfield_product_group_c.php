<?php
 // created: 2022-07-21 20:52:48
$dictionary['Case']['fields']['product_group_c']['labelValue']='Product Group_old';
$dictionary['Case']['fields']['product_group_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Case']['fields']['product_group_c']['enforced']='';
$dictionary['Case']['fields']['product_group_c']['dependency']='';
$dictionary['Case']['fields']['product_group_c']['required_formula']='';
$dictionary['Case']['fields']['product_group_c']['readonly_formula']='';

 ?>