<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LNK_NEW_REVENUELINEITEM'] = 'Opprett omsetningspost';
$mod_strings['LBL_MODULE_NAME'] = 'Revenue Line Itemser';
$mod_strings['LBL_MODULE_NAME_SINGULAR'] = 'Omsetningspost';
$mod_strings['LBL_NEW_FORM_TITLE'] = 'Opprett omsetningspost';
$mod_strings['LNK_REVENUELINEITEM_LIST'] = 'Vis omsetningsposter';
$mod_strings['LNK_IMPORT_REVENUELINEITEMS'] = 'Importer omsetningsposter';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Liste over omsetningsposter';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Søk i omsetningsposter';
$mod_strings['LBL_MODULE_TITLE'] = 'Revenue Line Itemser: Hjem';
$mod_strings['LBL_DEFAULT_SUBPANEL_TITLE'] = 'Revenue Line Itemser';
$mod_strings['LBL_RLI_SUBPANEL_TITLE'] = 'Revenue Line Itemser';
