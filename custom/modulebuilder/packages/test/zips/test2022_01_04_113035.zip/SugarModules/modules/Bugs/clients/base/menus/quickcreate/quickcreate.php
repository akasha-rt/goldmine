<?php
// created: 2016-10-16 03:25:50
$viewdefs['Bugs']['base']['menu']['quickcreate'] = array (
  'layout' => 'create',
  'label' => 'LNK_NEW_BUG',
  'visible' => false,
  'icon' => 'fa-plus',
  'order' => 13,
);