<?php
 // created: 2019-05-08 15:38:16
$dictionary['Bug']['full_text_search']=false;
