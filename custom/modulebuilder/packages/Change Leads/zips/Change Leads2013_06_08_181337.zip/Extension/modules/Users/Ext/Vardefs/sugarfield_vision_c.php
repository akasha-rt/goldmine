<?php
 // created: 2013-05-22 06:02:24
$dictionary['User']['fields']['vision_c']['enforced']='';
$dictionary['User']['fields']['vision_c']['dependency']='';

 ?>