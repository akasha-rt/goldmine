<?php
 // created: 2013-05-20 10:07:38
$dictionary['User']['fields']['force_measurement_c']['enforced']='';
$dictionary['User']['fields']['force_measurement_c']['dependency']='';

 ?>