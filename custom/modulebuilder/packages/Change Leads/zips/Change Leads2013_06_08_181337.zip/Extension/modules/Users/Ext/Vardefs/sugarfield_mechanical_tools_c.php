<?php
 // created: 2013-05-22 06:17:40
$dictionary['User']['fields']['mechanical_tools_c']['enforced']='';
$dictionary['User']['fields']['mechanical_tools_c']['dependency']='';

 ?>