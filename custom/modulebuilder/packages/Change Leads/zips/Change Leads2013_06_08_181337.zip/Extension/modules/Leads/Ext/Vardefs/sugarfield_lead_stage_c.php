<?php
 // created: 2013-06-07 08:44:18
$dictionary['Lead']['fields']['lead_stage_c']['dependency']='';
$dictionary['Lead']['fields']['lead_stage_c']['visibility_grid']=array (
  'trigger' => 'status',
  'values' => 
  array (
    '' => 
    array (
    ),
    'New' => 
    array (
    ),
    'Assigned' => 
    array (
    ),
    'In Process' => 
    array (
      0 => 'email',
      1 => 'phone_message',
      2 => 'conversation',
      3 => 'appointment',
      4 => 'online_demo',
      5 => 'demo',
      6 => 'other',
    ),
    'Converted' => 
    array (
      0 => 'not_ready',
      1 => 'not_interest_now',
    ),
    'Recycled' => 
    array (
    ),
    'Dead' => 
    array (
      0 => 'not_interest',
      1 => 'purchased',
      2 => 'distributor',
      3 => 'referred',
      4 => 'other',
    ),
    'waiting' => 
    array (
      0 => 'noreply',
      1 => 'not_interest_now',
      2 => 'other',
    ),
  ),
);

 ?>