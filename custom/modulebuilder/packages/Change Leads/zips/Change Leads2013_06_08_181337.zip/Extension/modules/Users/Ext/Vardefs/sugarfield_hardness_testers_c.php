<?php
 // created: 2013-05-22 06:10:57
$dictionary['User']['fields']['hardness_testers_c']['enforced']='';
$dictionary['User']['fields']['hardness_testers_c']['dependency']='';

 ?>