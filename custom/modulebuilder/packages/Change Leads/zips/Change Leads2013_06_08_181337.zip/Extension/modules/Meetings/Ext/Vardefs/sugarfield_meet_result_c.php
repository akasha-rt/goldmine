<?php
 // created: 2013-06-08 08:44:01
$dictionary['Meeting']['fields']['meet_result_c']['dependency']='';
$dictionary['Meeting']['fields']['meet_result_c']['visibility_grid']=array (
  'trigger' => 'status',
  'values' => 
  array (
    'admin' => 
    array (
      0 => 'sale',
      1 => 'quote',
      2 => 'none',
    ),
    'demo' => 
    array (
      0 => 'sale',
      1 => 'quote',
      2 => 'none',
    ),
    'intro' => 
    array (
      0 => 'sale',
      1 => 'quote',
      2 => 'none',
    ),
    'tour' => 
    array (
      0 => 'sale',
      1 => 'quote',
      2 => 'none',
    ),
    'Other' => 
    array (
      0 => 'sale',
      1 => 'none',
      2 => 'quote',
    ),
    'Planned' => 
    array (
    ),
    'Held' => 
    array (
      0 => 'Sale',
      1 => 'Quote',
      2 => 'Demo',
      3 => 'None',
    ),
    'Not Held' => 
    array (
      0 => 'Reschedule',
      1 => 'bad_cancel',
      2 => 'ok_cancel',
    ),
  ),
);

 ?>