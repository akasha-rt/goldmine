<?php
 // created: 2013-05-22 06:13:34
$dictionary['User']['fields']['granite_c']['enforced']='';
$dictionary['User']['fields']['granite_c']['dependency']='';

 ?>