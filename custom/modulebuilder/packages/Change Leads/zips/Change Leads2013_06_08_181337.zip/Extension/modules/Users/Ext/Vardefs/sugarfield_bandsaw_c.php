<?php
 // created: 2013-05-20 09:55:55
$dictionary['User']['fields']['bandsaw_c']['enforced']='';
$dictionary['User']['fields']['bandsaw_c']['dependency']='';

 ?>