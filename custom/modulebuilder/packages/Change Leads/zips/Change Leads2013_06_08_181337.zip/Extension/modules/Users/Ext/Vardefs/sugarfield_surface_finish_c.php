<?php
 // created: 2013-05-22 06:10:18
$dictionary['User']['fields']['surface_finish_c']['enforced']='';
$dictionary['User']['fields']['surface_finish_c']['dependency']='';

 ?>