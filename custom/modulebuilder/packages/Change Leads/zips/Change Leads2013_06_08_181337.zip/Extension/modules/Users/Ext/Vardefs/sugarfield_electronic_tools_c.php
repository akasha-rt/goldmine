<?php
 // created: 2013-05-22 06:18:07
$dictionary['User']['fields']['electronic_tools_c']['enforced']='';
$dictionary['User']['fields']['electronic_tools_c']['dependency']='';

 ?>