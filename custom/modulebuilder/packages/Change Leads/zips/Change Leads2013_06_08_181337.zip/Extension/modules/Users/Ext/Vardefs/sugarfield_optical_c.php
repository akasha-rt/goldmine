<?php
 // created: 2013-05-22 06:01:39
$dictionary['User']['fields']['optical_c']['enforced']='';
$dictionary['User']['fields']['optical_c']['dependency']='';

 ?>