<?php
 // created: 2013-05-22 06:21:53
$dictionary['User']['fields']['roundness_c']['enforced']='';
$dictionary['User']['fields']['roundness_c']['dependency']='';

 ?>