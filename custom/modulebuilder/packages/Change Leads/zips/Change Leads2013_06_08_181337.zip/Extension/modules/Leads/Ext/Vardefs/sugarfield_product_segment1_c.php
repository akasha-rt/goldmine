<?php
 // created: 2013-06-08 06:46:07
$dictionary['Lead']['fields']['product_segment1_c']['dependency']='';
$dictionary['Lead']['fields']['product_segment1_c']['visibility_grid']='';

 ?>