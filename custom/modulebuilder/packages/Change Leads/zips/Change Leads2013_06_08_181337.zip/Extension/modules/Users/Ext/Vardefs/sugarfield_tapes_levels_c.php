<?php
 // created: 2013-05-22 06:21:19
$dictionary['User']['fields']['tapes_levels_c']['enforced']='';
$dictionary['User']['fields']['tapes_levels_c']['dependency']='';

 ?>