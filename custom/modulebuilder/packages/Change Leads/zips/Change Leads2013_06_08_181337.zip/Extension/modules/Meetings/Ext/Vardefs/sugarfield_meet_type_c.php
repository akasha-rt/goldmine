<?php
 // created: 2013-06-08 08:22:57
$dictionary['Meeting']['fields']['meet_type_c']['dependency']='';
$dictionary['Meeting']['fields']['meet_type_c']['visibility_grid']='';

 ?>