<?php
 // created: 2013-06-08 08:32:44
$dictionary['Meeting']['fields']['meet_product_c']['full_text_search']=array (
  'boost' => '0',
);
$dictionary['Meeting']['fields']['meet_product_c']['enforced']='';
$dictionary['Meeting']['fields']['meet_product_c']['dependency']='';

 ?>