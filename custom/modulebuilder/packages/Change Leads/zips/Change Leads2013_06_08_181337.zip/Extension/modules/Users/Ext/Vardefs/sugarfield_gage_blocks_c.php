<?php
 // created: 2013-05-22 06:12:24
$dictionary['User']['fields']['gage_blocks_c']['enforced']='';
$dictionary['User']['fields']['gage_blocks_c']['dependency']='';

 ?>