<?php
 // created: 2013-05-20 10:49:18
$dictionary['Lead']['fields']['lead_quality_c']['dependency']='';
$dictionary['Lead']['fields']['lead_quality_c']['visibility_grid']='';

 ?>