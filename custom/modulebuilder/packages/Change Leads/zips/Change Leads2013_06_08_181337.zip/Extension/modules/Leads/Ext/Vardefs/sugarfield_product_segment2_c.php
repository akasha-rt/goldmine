<?php
 // created: 2013-06-08 07:10:58
$dictionary['Lead']['fields']['product_segment2_c']['dependency']='';
$dictionary['Lead']['fields']['product_segment2_c']['visibility_grid']=array (
  'trigger' => 'product_segment1_c',
  'values' => 
  array (
    '' => 
    array (
    ),
    'jst' => 
    array (
      0 => 'hand_tool',
      1 => 'm1',
    ),
    'met_equip' => 
    array (
      0 => 'optical_equip',
      1 => 'vision_equip',
      2 => 'laser_measure',
    ),
    'pgs' => 
    array (
      0 => 'drill_rod',
      1 => 'flat_stock',
    ),
    'pmt' => 
    array (
      0 => 'data_col',
      1 => 'gage_block',
      2 => 'gsf',
      3 => 'prec_tool',
    ),
    'saws' => 
    array (
      0 => 'bs_mach',
      1 => 'bs',
      2 => 'pta_handsaw',
    ),
    'test_equip' => 
    array (
      0 => 'force',
      1 => 'grips_fix',
      2 => 'mat_test',
      3 => 'round_measure',
    ),
    'tool' => 
    array (
    ),
  ),
);

 ?>