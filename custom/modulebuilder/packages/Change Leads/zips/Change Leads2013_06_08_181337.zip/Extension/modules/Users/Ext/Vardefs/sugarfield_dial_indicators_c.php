<?php
 // created: 2013-05-22 06:11:49
$dictionary['User']['fields']['dial_indicators_c']['enforced']='';
$dictionary['User']['fields']['dial_indicators_c']['dependency']='';

 ?>