<?php
//Workflow Alert Meta Data Arrays 
$alert_meta_array = array ( 

'Leads0_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Manager', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

'Leads1_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'trig_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Leads2_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'trig_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Leads3_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'trig_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Leads5_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Manager', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

'Leads6_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Manager', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

'Leads7_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'trig_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Leads8_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'trig_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Leads10_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'trig_user_custom', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'full_name', 
		 'where_filter' => '0', 
		 'rel_module1' => '', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => 'email1', 
		 'user_display_type' => '', 
	 ), 

), 

'Leads11_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

'Leads12_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

'Leads13_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Self', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

'Leads14_alert0' => 

array ( 

	 'user_0' => array ( 

		 'user_type' => 'rel_user', 
		 'address_type' => 'to', 
		 'array_type' => 'future', 
		 'relate_type' => 'Manager', 
		 'field_value' => 'assigned_user_id', 
		 'where_filter' => '0', 
		 'rel_module1' => 'reportees', 
		 'rel_module2' => '', 
		 'rel_module1_type' => 'all', 
		 'rel_module2_type' => 'all', 
		 'rel_email_value' => '', 
		 'user_display_type' => 'user4', 
	 ), 

), 

); 

 

?>