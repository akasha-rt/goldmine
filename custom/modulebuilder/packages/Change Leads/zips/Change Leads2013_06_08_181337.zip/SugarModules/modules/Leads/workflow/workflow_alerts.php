<?php

include_once("include/workflow/alert_utils.php");
    class Leads_alerts {
    function process_wflow_Leads0_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "720a3af3-d297-6cd9-a0c0-51a8b7981797"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads0_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads1_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "24d257fa-640d-02d2-8d56-51a76a860602"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads1_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads2_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "24d257fa-640d-02d2-8d56-51a76a860602"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads2_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads3_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "24d257fa-640d-02d2-8d56-51a76a860602"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads3_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads5_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "720a3af3-d297-6cd9-a0c0-51a8b7981797"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads5_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads6_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "720a3af3-d297-6cd9-a0c0-51a8b7981797"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads6_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads7_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "a66d1b8b-6560-c7ab-cc7d-51a8b26bacd2"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads7_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads8_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "a66d1b8b-6560-c7ab-cc7d-51a8b26bacd2"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads8_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads10_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "ee49ba38-2112-8a7a-cb33-51a8b4148d65"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads10_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads11_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "ee49ba38-2112-8a7a-cb33-51a8b4148d65"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads11_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads12_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "a04732fe-b2b4-64cc-f369-51a8b5f52144"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads12_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads13_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "d13c2aae-63cf-5916-e10e-51a8b51b865a"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads13_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }

function process_wflow_Leads14_alert0(&$focus){
            include("custom/modules/Leads/workflow/alerts_array.php");

	 $alertshell_array = array(); 

	 $alertshell_array['alert_msg'] = "720a3af3-d297-6cd9-a0c0-51a8b7981797"; 

	 $alertshell_array['source_type'] = "Custom Template"; 

	 $alertshell_array['alert_type'] = "Email"; 

	 process_workflow_alerts($focus, $alert_meta_array['Leads14_alert0'], $alertshell_array, false); 
 	 unset($alertshell_array); 
	 }



    //end class
    }

?>