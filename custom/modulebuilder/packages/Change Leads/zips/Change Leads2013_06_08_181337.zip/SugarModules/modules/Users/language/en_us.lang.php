<?php 
 // created: 2013-06-08 18:13:35
$mod_strings['LBL_PRODUCT_LINE'] = 'Product Line';
$mod_strings['LBL_BANDSAW'] = 'Bandsaw';
$mod_strings['LBL_FORCE_MEASUREMENT'] = 'Force Measurement';
$mod_strings['LBL_OPTICAL'] = 'Optical';
$mod_strings['LBL_VISION'] = 'Vision';
$mod_strings['LBL_SURFACE_FINISH'] = 'Surface Finish';
$mod_strings['LBL_HARDNESS_TESTERS'] = 'Hardness Testers';
$mod_strings['LBL_TAPES_LEVELS'] = 'Tapes and Levels';
$mod_strings['LBL_DIAL_INDICATORS'] = 'Dial Indicators';
$mod_strings['LBL_GAGE_BLOCKS'] = 'Gage Blocks';
$mod_strings['LBL_GRANITE'] = 'Granite';
$mod_strings['LBL_MECHANICAL_TOOLS'] = 'Mechanical Tools';
$mod_strings['LBL_ELECTRONIC_TOOLS'] = 'Electronic Tools';
$mod_strings['LBL_ROUNDNESS'] = 'Roundness';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Account Data';

?>
