<?php
//Workflow Action Meta Data Arrays 
$action_meta_array = array ( 

'Leads7_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'lead_quality_c' => 'lead_type_b', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

'Leads8_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'lead_quality_c' => 'lead_type_c', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

'Leads9_action0' => 

array ( 

		 'action_type' => 'update', 
		 'action_module' => '', 
		 'rel_module' => '', 
		 'rel_module_type' => 'all', 
	 'basic' => array ( 

		 'lead_quality_c' => 'lead_type_d', 
	 ), 

	 'basic_ext' => array ( 

	 ), 

	 'advanced' => array ( 

	 ), 

), 

); 

 

?>