<?php

include_once("include/workflow/alert_utils.php");
include_once("include/workflow/action_utils.php");
include_once("include/workflow/time_utils.php");
include_once("include/workflow/trigger_utils.php");
//BEGIN WFLOW PLUGINS
include_once("include/workflow/custom_utils.php");
//END WFLOW PLUGINS
	class Leads_workflow {
	function process_wflow_triggers(& $focus){
		include("custom/modules/Leads/workflow/triggers_array.php");
		include("custom/modules/Leads/workflow/alerts_array.php");
		include("custom/modules/Leads/workflow/actions_array.php");
		include("custom/modules/Leads/workflow/plugins_array.php");
		if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="c96e0b2c-bd1e-320a-3bbd-51a768478979")){ 
 
 if( (  ( isset($focus->status) && ( empty($focus->fetched_row) || array_key_exists('status', $focus->fetched_row) ) && $focus->fetched_row['status'] != $focus->status)  || ( $focus->fetched_row['status'] == null && !isset($focus->status) ) )  ||  (  isset($focus->status) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->status 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->workflow_line_c) && $focus->workflow_line_c ==  'tool')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_a')	 ){ 
	 

	 //Secondary Trigger number #3
	 if( (isset($focus->status) && $focus->status ==  'New')	 ){ 
	 

	 $time_array['time_int'] = '172800'; 

	 $time_array['parameters'] = $focus->status; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'c96e0b2c-bd1e-320a-3bbd-51a768478979'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['e9a6d14a_ad4e_a5d6_6ae2_51b2085cd234'])){
		$triggeredWorkflows['e9a6d14a_ad4e_a5d6_6ae2_51b2085cd234'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads0_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 // End Secondary Trigger number #3
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="7a94239b-9091-e485-1d38-51a8bc000aac")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_a')	 ){ 
	 

	 $trigger_time_count = '1'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '7a94239b-9091-e485-1d38-51a8bc000aac'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['ea32e2a8_8dd4_3b8b_0a13_51b208426a27'])){
		$triggeredWorkflows['ea32e2a8_8dd4_3b8b_0a13_51b208426a27'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads1_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="28e6776c-a7bf-cb96-829b-51a8bd011442")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_b')	 ){ 
	 

	 $trigger_time_count = '2'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '28e6776c-a7bf-cb96-829b-51a8bd011442'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['eacce3aa_a92b_72cf_2da8_51b2088674d1'])){
		$triggeredWorkflows['eacce3aa_a92b_72cf_2da8_51b2088674d1'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads2_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="d13ce452-cc3e-2a12-7fe8-51a8bd151f70")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_c')	 ){ 
	 

	 $trigger_time_count = '3'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'd13ce452-cc3e-2a12-7fe8-51a8bd151f70'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['eb67fb6d_4221_abdc_d614_51b2084fe7c5'])){
		$triggeredWorkflows['eb67fb6d_4221_abdc_d614_51b2084fe7c5'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads3_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="e6ffafc8-2e6f-489f-f2f6-51a8bde7f097")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_d')	 ){ 
	 

	 $trigger_time_count = '4'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'e6ffafc8-2e6f-489f-f2f6-51a8bde7f097'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['ebeaa832_43b5_b4e7_15e4_51b2085f3153'])){
		$triggeredWorkflows['ebeaa832_43b5_b4e7_15e4_51b2085f3153'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ());	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="143172f8-49fc-4027-7748-51ac8d687deb")){ 
 
 if( (  ( isset($focus->lead_quality_c) && ( empty($focus->fetched_row) || array_key_exists('lead_quality_c', $focus->fetched_row) ) && $focus->fetched_row['lead_quality_c'] != $focus->lead_quality_c)  || ( $focus->fetched_row['lead_quality_c'] == null && !isset($focus->lead_quality_c) ) )  ||  (  isset($focus->lead_quality_c) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->lead_quality_c 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_b')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')	 ){ 
	 

	 $time_array['time_int'] = '432000'; 

	 $time_array['parameters'] = $focus->lead_quality_c; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '143172f8-49fc-4027-7748-51ac8d687deb'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['ec56529c_3a0f_efd5_8580_51b2081c87f3'])){
		$triggeredWorkflows['ec56529c_3a0f_efd5_8580_51b2081c87f3'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads5_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="c6110e76-90b1-8adc-6b26-51ac8da3f728")){ 
 
 if( (  ( isset($focus->lead_quality_c) && ( empty($focus->fetched_row) || array_key_exists('lead_quality_c', $focus->fetched_row) ) && $focus->fetched_row['lead_quality_c'] != $focus->lead_quality_c)  || ( $focus->fetched_row['lead_quality_c'] == null && !isset($focus->lead_quality_c) ) )  ||  (  isset($focus->lead_quality_c) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->lead_quality_c 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_c')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')	 ){ 
	 

	 $time_array['time_int'] = '2592000'; 

	 $time_array['parameters'] = $focus->lead_quality_c; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'c6110e76-90b1-8adc-6b26-51ac8da3f728'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['eceec980_3336_2ff6_3b15_51b2088f79ef'])){
		$triggeredWorkflows['eceec980_3336_2ff6_3b15_51b2088f79ef'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads6_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (  ( isset($focus->lead_quality_c) && ( empty($focus->fetched_row) || array_key_exists('lead_quality_c', $focus->fetched_row) ) && $focus->fetched_row['lead_quality_c'] != $focus->lead_quality_c)  || ( $focus->fetched_row['lead_quality_c'] == null && !isset($focus->lead_quality_c) ) )  ||  (  isset($focus->lead_quality_c) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->lead_quality_c 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) 	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_a')	 ){ 
	 

	 $trigger_time_count = '7'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'e13d5e04-f7e7-71fc-78d1-51aca12cd44a'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['ed883963_ef54_4b53_04dd_51b20848ddc8'])){
		$triggeredWorkflows['ed883963_ef54_4b53_04dd_51b20848ddc8'] = true;
		 process_workflow_actions($focus, $action_meta_array['Leads7_action0']); 
 	$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads7_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (  ( isset($focus->lead_quality_c) && ( empty($focus->fetched_row) || array_key_exists('lead_quality_c', $focus->fetched_row) ) && $focus->fetched_row['lead_quality_c'] != $focus->lead_quality_c)  || ( $focus->fetched_row['lead_quality_c'] == null && !isset($focus->lead_quality_c) ) )  ||  (  isset($focus->lead_quality_c) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->lead_quality_c 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) 	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_b')	 ){ 
	 

	 $trigger_time_count = '8'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '6876a72c-0583-033f-09e7-51aca12381b9'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['eebf81ac_b978_1632_3372_51b208c35841'])){
		$triggeredWorkflows['eebf81ac_b978_1632_3372_51b208c35841'] = true;
		 process_workflow_actions($focus, $action_meta_array['Leads8_action0']); 
 	$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads8_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (  ( isset($focus->lead_quality_c) && ( empty($focus->fetched_row) || array_key_exists('lead_quality_c', $focus->fetched_row) ) && $focus->fetched_row['lead_quality_c'] != $focus->lead_quality_c)  || ( $focus->fetched_row['lead_quality_c'] == null && !isset($focus->lead_quality_c) ) )  ||  (  isset($focus->lead_quality_c) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->lead_quality_c 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) 	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_c')	 ){ 
	 

	 $trigger_time_count = '9'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'a3483bbf-1436-dcc0-857c-51aca1abefdd'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['efaa46cd_0932_01a2_75b8_51b20819a693'])){
		$triggeredWorkflows['efaa46cd_0932_01a2_75b8_51b20819a693'] = true;
		 process_workflow_actions($focus, $action_meta_array['Leads9_action0']); 
 	$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ());	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="7310b41e-f8db-3299-0a35-51aca17387df")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (  ( isset($focus->lead_quality_c) && ( empty($focus->fetched_row) || array_key_exists('lead_quality_c', $focus->fetched_row) ) && $focus->fetched_row['lead_quality_c'] != $focus->lead_quality_c)  || ( $focus->fetched_row['lead_quality_c'] == null && !isset($focus->lead_quality_c) ) )  ||  (  isset($focus->lead_quality_c) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->lead_quality_c 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) 	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_d')	 ){ 
	 

	 $trigger_time_count = '10'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '7310b41e-f8db-3299-0a35-51aca17387df'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['f07696ba_2343_0a3d_3e3e_51b2088541e8'])){
		$triggeredWorkflows['f07696ba_2343_0a3d_3e3e_51b2088541e8'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads10_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_a')	 ){ 
	 

	 $trigger_time_count = '11'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '2e76bdcc-503f-b3f0-5256-51acc03319ca'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['f1097008_32b3_d54e_2ce3_51b2086e4edc'])){
		$triggeredWorkflows['f1097008_32b3_d54e_2ce3_51b2086e4edc'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads11_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="98c884a3-8b51-5a2f-d4e5-51acc8a43a7b")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_b')	 ){ 
	 

	 $trigger_time_count = '12'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = '98c884a3-8b51-5a2f-d4e5-51acc8a43a7b'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['f1951644_562c_862a_70ae_51b208315611'])){
		$triggeredWorkflows['f1951644_562c_862a_70ae_51b208315611'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads12_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 

if(empty($focus->fetched_row['id']) || (!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" && !empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]=="e8af6f53-6b8d-391c-35ff-51acc845cb04")){ 
 
 if( (isset($focus->lead_segment_c) && $focus->lead_segment_c ==  'electronic_tool')){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_c')	 ){ 
	 

	 $trigger_time_count = '13'; 

 	 $time_array['time_int'] = ''; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'e8af6f53-6b8d-391c-35ff-51acc845cb04'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['f22a36a8_c26e_fd2a_a0c1_51b208ffe40c'])){
		$triggeredWorkflows['f22a36a8_c26e_fd2a_a0c1_51b208ffe40c'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads13_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 

		 //End if new, update, or all record
 		} 


 if( (  ( isset($focus->status) && ( empty($focus->fetched_row) || array_key_exists('status', $focus->fetched_row) ) && $focus->fetched_row['status'] != $focus->status)  || ( $focus->fetched_row['status'] == null && !isset($focus->status) ) )  ||  (  isset($focus->status) && isset($_SESSION['workflow_parameters']) && $_SESSION['workflow_parameters'] == $focus->status 
 && !empty($_SESSION['workflow_cron']) && $_SESSION['workflow_cron']=="Yes" ) ){ 
 

	 //Frame Secondary 

	 $secondary_array = array(); 
	 //Secondary Triggers 
	 //Secondary Trigger number #1
	 if( (isset($focus->workflow_line_c) && $focus->workflow_line_c ==  'tool')	 ){ 
	 

	 //Secondary Trigger number #2
	 if( (isset($focus->lead_quality_c) && $focus->lead_quality_c ==  'lead_type_a')	 ){ 
	 

	 //Secondary Trigger number #3
	 if( (isset($focus->status) && $focus->status ==  'New')	 ){ 
	 

	 $time_array['time_int'] = '172800'; 

	 $time_array['parameters'] = $focus->status; 

	 $time_array['time_int_type'] = 'normal'; 

	 $time_array['target_field'] = 'none'; 

	 $workflow_id = 'b356245a-c582-9817-75cc-51b2070d3c00'; 

if(!empty($_SESSION["workflow_cron"]) && $_SESSION["workflow_cron"]=="Yes" &&
				!empty($_SESSION["workflow_id_cron"]) && $_SESSION["workflow_id_cron"]==$workflow_id){
				
	global $triggeredWorkflows;
	if (!isset($triggeredWorkflows['f2da3d90_7b3c_f5ac_7b95_51b208c847d8'])){
		$triggeredWorkflows['f2da3d90_7b3c_f5ac_7b95_51b208c847d8'] = true;
		$_SESSION['WORKFLOW_ALERTS'] = isset($_SESSION['WORKFLOW_ALERTS']) && is_array($_SESSION['WORKFLOW_ALERTS']) ? $_SESSION['WORKFLOW_ALERTS'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = isset($_SESSION['WORKFLOW_ALERTS']['Leads']) && is_array($_SESSION['WORKFLOW_ALERTS']['Leads']) ? $_SESSION['WORKFLOW_ALERTS']['Leads'] : array();
		$_SESSION['WORKFLOW_ALERTS']['Leads'] = array_merge($_SESSION['WORKFLOW_ALERTS']['Leads'],array ('Leads14_alert0',));	}
}

else{
		 check_for_schedule($focus, $workflow_id, $time_array); 

 }

 

	 //End Frame Secondary 

	 // End Secondary Trigger number #1
 	 } 

	 // End Secondary Trigger number #2
 	 } 

	 // End Secondary Trigger number #3
 	 } 

	 unset($secondary_array); 
 

 //End if trigger is true 
 } 


	//end function process_wflow_triggers
	}

	//end class
	}

?>