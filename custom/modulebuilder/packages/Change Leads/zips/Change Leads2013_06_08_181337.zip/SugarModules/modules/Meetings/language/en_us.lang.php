<?php 
 // created: 2013-06-08 18:13:35
$mod_strings['LBL_MEET_TYPE'] = 'Meeting Type';
$mod_strings['LBL_MEET_RESULT'] = 'Meeting Result';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'New Panel 1';
$mod_strings['LBL_MEET_PRODUCT'] = 'Product';

?>
