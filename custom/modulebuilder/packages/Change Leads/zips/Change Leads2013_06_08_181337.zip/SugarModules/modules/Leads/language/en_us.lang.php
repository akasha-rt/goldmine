<?php 
 // created: 2013-06-08 18:13:34
$mod_strings['LBL_OPPORTUNITY_AMOUNT'] = 'Opportunity Amount:';
$mod_strings['LBL_OPPORTUNITY_ID'] = 'Opportunity ID';
$mod_strings['LBL_OPPORTUNITY_NAME'] = 'Opportunity Name:';
$mod_strings['LBL_CONVERTED_OPP'] = 'Converted Opportunity:';
$mod_strings['LBL_LEAD_QUALITY'] = 'Lead Quality';
$mod_strings['LBL_LEAD_STAGE'] = 'Lead Stage';
$mod_strings['LBL_STATUS'] = 'Lead Status';
$mod_strings['LBL_PANEL_ADVANCED'] = 'Lead Data';
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Personal Information';
$mod_strings['LBL_PANEL_ASSIGNMENT'] = 'Assignments';
$mod_strings['LBL_LEAD_SOURCE'] = 'Lead Source:';
$mod_strings['LBL_PRODUCT_SEGMENT1'] = 'Strategic Product Line';
$mod_strings['LBL_PRODUCT_SEGMENT2'] = 'Product Group';

?>
