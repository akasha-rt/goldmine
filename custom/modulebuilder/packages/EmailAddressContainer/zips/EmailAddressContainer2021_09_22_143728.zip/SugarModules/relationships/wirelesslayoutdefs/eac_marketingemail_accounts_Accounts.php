<?php
 // created: 2021-09-22 14:37:28
$layout_defs["Accounts"]["subpanel_setup"]['eac_marketingemail_accounts'] = array (
  'order' => 100,
  'module' => 'EAC_MarketingEmail',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_EAC_MARKETINGEMAIL_ACCOUNTS_FROM_EAC_MARKETINGEMAIL_TITLE',
  'get_subpanel_data' => 'eac_marketingemail_accounts',
);
