<?php
// created: 2021-09-22 14:16:58
$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_EAC_COMPANYEMAIL_ACCOUNTS_FROM_EAC_COMPANYEMAIL_TITLE',
  'context' => 
  array (
    'link' => 'eac_companyemail_accounts',
  ),
);

$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_EAC_COMPANYEMAIL_ACCOUNTS_FROM_EAC_COMPANYEMAIL_TITLE',
  'context' => 
  array (
    'link' => 'eac_companyemail_accounts',
  ),
);