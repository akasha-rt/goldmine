<?php
// created: 2021-09-22 14:18:35
$dictionary["Account"]["fields"]["eac_companyemail_accounts"] = array (
  'name' => 'eac_companyemail_accounts',
  'type' => 'link',
  'relationship' => 'eac_companyemail_accounts',
  'source' => 'non-db',
  'module' => 'EAC_CompanyEmail',
  'bean_name' => 'EAC_CompanyEmail',
  'vname' => 'LBL_EAC_COMPANYEMAIL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'eac_companyemail_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
