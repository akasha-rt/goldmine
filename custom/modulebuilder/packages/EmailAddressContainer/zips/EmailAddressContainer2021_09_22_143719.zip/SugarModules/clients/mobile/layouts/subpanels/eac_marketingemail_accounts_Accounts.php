<?php
// created: 2021-09-22 14:37:19
$viewdefs['Accounts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_EAC_MARKETINGEMAIL_ACCOUNTS_FROM_EAC_MARKETINGEMAIL_TITLE',
  'context' => 
  array (
    'link' => 'eac_marketingemail_accounts',
  ),
);