<?php
// created: 2021-09-22 14:37:19
$dictionary["Account"]["fields"]["eac_marketingemail_accounts"] = array (
  'name' => 'eac_marketingemail_accounts',
  'type' => 'link',
  'relationship' => 'eac_marketingemail_accounts',
  'source' => 'non-db',
  'module' => 'EAC_MarketingEmail',
  'bean_name' => false,
  'vname' => 'LBL_EAC_MARKETINGEMAIL_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'eac_marketingemail_accountsaccounts_ida',
  'link-type' => 'many',
  'side' => 'left',
);
