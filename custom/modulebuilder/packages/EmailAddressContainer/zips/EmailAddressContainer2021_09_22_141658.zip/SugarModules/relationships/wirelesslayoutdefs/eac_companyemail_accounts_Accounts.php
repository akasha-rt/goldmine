<?php
 // created: 2021-09-22 14:16:58
$layout_defs["Accounts"]["subpanel_setup"]['eac_companyemail_accounts'] = array (
  'order' => 100,
  'module' => 'EAC_CompanyEmail',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_EAC_COMPANYEMAIL_ACCOUNTS_FROM_EAC_COMPANYEMAIL_TITLE',
  'get_subpanel_data' => 'eac_companyemail_accounts',
);
