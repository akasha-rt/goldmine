<?php

$manifest = array (
  'built_in_version' => '12.0.0',
  'acceptable_sugar_versions' => 
  array (
    0 => '12.*.*',
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'ENT',
    1 => 'ULT',
  ),
  'readme' => '',
  'key' => '',
  'author' => '',
  'description' => '',
  'icon' => '',
  'is_uninstallable' => true,
  'name' => 'STAR_66_Copy_Cat_from_Prod',
  'published_date' => '2022-08-22 09:33:54',
  'type' => 'module',
  'version' => 1661160844,
  'remove_tables' => 'prompt',
);


$installdefs = array (
  'id' => 'STAR_66_Copy_Cat_from_Prod',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/custom/Extension/modules/Cases/Ext/Vardefs/product_fields.php',
      'to' => 'custom/Extension/modules/Cases/Ext/Vardefs/product_fields.php',
    ),
    
  ),
);