<?php
$dictionary['Quote']['fields']['quote_number_portal'] = array(
    'name' => 'quote_number_portal',
    'label' => 'LBL_QUOTE_NUMBER_PORTAL',
    'type' => 'varchar'
);