<?php

 // /custom/Extension/modules/Prospects/Ext/LogicHooks/

$hook_array['after_save'][] = Array(1, 'Lead Routing', 'custom/modules/Prospects/after_save_logic.php','after_save_logic', 'after_save_logic');
 


?>