<?php

 // /custom/Extension/modules/Leads/Ext/LogicHooks/

$hook_array['after_save'][] = Array(1, 'Lead Routing', 'custom/modules/Leads/after_save_logic.php','after_save_logic', 'after_save_logic');
 


?>