<?php

$mod_strings['LBL_OPS_NOTIFICATION_SETTINGS_LINK_NAME'] = 'Notification Settings';
$mod_strings['LBL_OPS_NOTIFICATION_SETTINGS_LINK_DESCRIPTION'] = 'Email Addresses that should be notified for system upgrades and SugarCloud changes.';
$mod_strings['LBL_OPS_ONDEMAND_SECTION_HEADER'] = 'SugarCloud';
$mod_strings['LBL_OPS_ONDEMAND_SECTION_DESCRIPTION'] = 'SugarCloud Modules and Settings';
$mod_strings['LBL_OPS_NOTIFICATION_EMAILS'] = 'Send Notifications To:';
$mod_strings['LBL_OPS_NOTIFICATION_EMAIL_SETTINGS'] = 'Email Settings';
$mod_strings['LBL_OPS_BACKUPS'] = 'Download Backups';
$mod_strings['LBL_OPS_BACKUPS_DESCRIPTION'] = 'Download Archived backups of the SugarCloud instance.';
