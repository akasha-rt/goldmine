<?php

$mod_strings['LBL_OPS_BACKUPS_FETCH_EXPORTS'] = 'Retrieve updated backup listing from SugarCRM';
