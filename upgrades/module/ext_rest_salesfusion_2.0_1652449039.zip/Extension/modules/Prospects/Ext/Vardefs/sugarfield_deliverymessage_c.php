<?php
 // created: 2012-09-04 14:40:15
$dictionary['Prospect']['fields']['deliverymessage_c']['enforced']='false';
$dictionary['Prospect']['fields']['deliverymessage_c']['dependency']='';

 ?>