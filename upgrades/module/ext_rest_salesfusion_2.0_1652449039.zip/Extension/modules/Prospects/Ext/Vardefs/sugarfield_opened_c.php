<?php
 // created: 2012-09-04 14:41:57
$dictionary['Prospect']['fields']['opened_c']['enforced']='false';
$dictionary['Prospect']['fields']['opened_c']['dependency']='';

 ?>