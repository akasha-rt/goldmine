<?php
 // created: 2012-09-04 14:40:59
$dictionary['Prospect']['fields']['clicked_c']['enforced']='false';
$dictionary['Prospect']['fields']['clicked_c']['dependency']='';

 ?>