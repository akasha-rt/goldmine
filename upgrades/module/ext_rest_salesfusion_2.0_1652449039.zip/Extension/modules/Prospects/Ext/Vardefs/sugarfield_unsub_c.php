<?php
 // created: 2012-09-04 14:37:41
$dictionary['Prospect']['fields']['unsub_c']['enforced']='false';
$dictionary['Prospect']['fields']['unsub_c']['dependency']='';

 ?>