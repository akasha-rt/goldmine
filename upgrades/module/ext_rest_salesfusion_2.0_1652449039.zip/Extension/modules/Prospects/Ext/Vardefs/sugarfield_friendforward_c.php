<?php
 // created: 2012-09-04 14:39:02
$dictionary['Prospect']['fields']['friendforward_c']['enforced']='false';
$dictionary['Prospect']['fields']['friendforward_c']['dependency']='';

 ?>