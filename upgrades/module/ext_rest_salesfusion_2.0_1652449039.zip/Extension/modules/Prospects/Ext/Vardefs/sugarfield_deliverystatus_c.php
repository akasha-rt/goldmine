<?php
 // created: 2012-09-04 14:39:43
$dictionary['Prospect']['fields']['deliverystatus_c']['enforced']='false';
$dictionary['Prospect']['fields']['deliverystatus_c']['dependency']='';

 ?>