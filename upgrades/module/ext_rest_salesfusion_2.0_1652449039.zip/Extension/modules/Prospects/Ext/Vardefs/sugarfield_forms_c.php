<?php
 // created: 2012-09-04 14:38:19
$dictionary['Prospect']['fields']['forms_c']['enforced']='false';
$dictionary['Prospect']['fields']['forms_c']['dependency']='';

 ?>