<?php
 // created: 2012-12-12 16:37:30
$layout_defs["Leads"]["subpanel_setup"]['sf_eventmanagement_leads'] = array (
  'order' => 100,
  'module' => 'sf_EventManagement',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_EVENTMANAGEMENT_LEADS_FROM_SF_EVENTMANAGEMENT_TITLE',
  'get_subpanel_data' => 'sf_eventmanagement_leads',
);
