<?php
 // created: 2012-12-12 16:37:24
$layout_defs["Leads"]["subpanel_setup"]['sf_dialogs_leads'] = array (
  'order' => 100,
  'module' => 'sf_Dialogs',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_DIALOGS_LEADS_FROM_SF_DIALOGS_TITLE',
  'get_subpanel_data' => 'sf_dialogs_leads',
);
