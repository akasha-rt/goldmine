<?php
 // created: 2017-06-20 11:49:20
$dictionary['Lead']['fields']['sf_lastactivity_default_c']['labelValue']='Salesfusion Last Activity';
$dictionary['Lead']['fields']['sf_lastactivity_default_c']['enforced']='';
$dictionary['Lead']['fields']['sf_lastactivity_default_c']['dependency']='';

 ?>