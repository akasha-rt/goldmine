<?php
// created: 2012-12-12 16:37:21
$dictionary["Lead"]["fields"]["sf_dialogs_leads"] = array (
  'name' => 'sf_dialogs_leads',
  'type' => 'link',
  'relationship' => 'sf_dialogs_leads',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SF_DIALOGS_LEADS_FROM_SF_DIALOGS_TITLE',
);
