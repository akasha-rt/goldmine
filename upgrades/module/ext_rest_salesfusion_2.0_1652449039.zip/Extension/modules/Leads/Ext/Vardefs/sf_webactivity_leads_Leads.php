<?php
// created: 2012-08-28 20:35:13
$dictionary["Lead"]["fields"]["sf_webactivity_leads"] = array (
  'name' => 'sf_webactivity_leads',
  'type' => 'link',
  'relationship' => 'sf_webactivity_leads',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITY_LEADS_FROM_SF_WEBACTIVITY_TITLE',
);
