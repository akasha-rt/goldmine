<?php
// created: 2012-12-12 16:37:20
$dictionary["Contact"]["fields"]["sf_dialogs_contacts"] = array (
  'name' => 'sf_dialogs_contacts',
  'type' => 'link',
  'relationship' => 'sf_dialogs_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SF_DIALOGS_CONTACTS_FROM_SF_DIALOGS_TITLE',
);
