<?php
 // created: 2017-06-20 11:46:55
$dictionary['Contact']['fields']['sf_lastactivity_default_c']['labelValue']='Salesfusion Last Activity';
$dictionary['Contact']['fields']['sf_lastactivity_default_c']['enforced']='';
$dictionary['Contact']['fields']['sf_lastactivity_default_c']['dependency']='';

 ?>