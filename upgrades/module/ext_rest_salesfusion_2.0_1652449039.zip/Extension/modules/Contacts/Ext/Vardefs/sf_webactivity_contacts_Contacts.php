<?php
// created: 2012-08-28 20:35:14
$dictionary["Contact"]["fields"]["sf_webactivity_contacts"] = array (
  'name' => 'sf_webactivity_contacts',
  'type' => 'link',
  'relationship' => 'sf_webactivity_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITY_CONTACTS_FROM_SF_WEBACTIVITY_TITLE',
);
