<?php
 // created: 2012-12-12 16:37:24
$layout_defs["Contacts"]["subpanel_setup"]['sf_dialogs_contacts'] = array (
  'order' => 100,
  'module' => 'sf_Dialogs',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_DIALOGS_CONTACTS_FROM_SF_DIALOGS_TITLE',
  'get_subpanel_data' => 'sf_dialogs_contacts',
);
