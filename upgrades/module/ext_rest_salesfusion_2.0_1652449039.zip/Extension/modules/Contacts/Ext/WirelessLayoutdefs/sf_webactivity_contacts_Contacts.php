<?php
 // created: 2012-08-28 20:35:14
$layout_defs["Contacts"]["subpanel_setup"]['sf_webactivity_contacts'] = array (
  'order' => 100,
  'module' => 'sf_webActivity',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_WEBACTIVITY_CONTACTS_FROM_SF_WEBACTIVITY_TITLE',
  'get_subpanel_data' => 'sf_webactivity_contacts',
);
