<?php
// created: 2014-01-23 15:24:41
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SF_EVENTMANAGEMENT_CONTACTS_FROM_CONTACTS_TITLE',
  'context' => 
  array (
    'link' => 'sf_eventmanagement_contacts',
  ),
);