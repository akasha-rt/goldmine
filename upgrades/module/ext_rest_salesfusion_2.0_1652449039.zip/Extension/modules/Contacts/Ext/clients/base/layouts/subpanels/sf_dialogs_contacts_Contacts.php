<?php
// created: 2014-01-23 15:24:41
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SF_DIALOGS_CONTACTS_FROM_SF_DIALOGS_TITLE',
  'context' => 
  array (
    'link' => 'sf_dialogs_contacts',
  ),
);