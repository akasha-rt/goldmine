<?php
 // created: 2012-08-27 20:11:36
$dictionary['Campaign']['fields']['forwards_c']['enforced']='false';
$dictionary['Campaign']['fields']['forwards_c']['dependency']='';

 ?>