<?php
 // created: 2012-08-27 20:10:24
$dictionary['Campaign']['fields']['unsubscribed_c']['enforced']='false';
$dictionary['Campaign']['fields']['unsubscribed_c']['dependency']='';

 ?>