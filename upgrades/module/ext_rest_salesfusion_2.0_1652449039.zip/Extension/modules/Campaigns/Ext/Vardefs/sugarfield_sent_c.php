<?php
 // created: 2012-08-27 20:05:36
$dictionary['Campaign']['fields']['sent_c']['enforced']='false';
$dictionary['Campaign']['fields']['sent_c']['dependency']='';

 ?>