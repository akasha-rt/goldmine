<?php
 // created: 2012-08-27 20:07:03
$dictionary['Campaign']['fields']['totalclicks_c']['enforced']='false';
$dictionary['Campaign']['fields']['totalclicks_c']['dependency']='';

 ?>