<?php
 // created: 2012-08-27 20:06:37
$dictionary['Campaign']['fields']['totalopens_c']['enforced']='false';
$dictionary['Campaign']['fields']['totalopens_c']['dependency']='';

 ?>