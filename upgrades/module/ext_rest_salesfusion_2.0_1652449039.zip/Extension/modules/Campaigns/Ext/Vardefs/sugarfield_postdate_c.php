<?php
 // created: 2012-08-27 20:04:49
$dictionary['Campaign']['fields']['postdate_c']['options']='date_range_search_dom';
$dictionary['Campaign']['fields']['postdate_c']['enforced']='false';
$dictionary['Campaign']['fields']['postdate_c']['dependency']='';
$dictionary['Campaign']['fields']['postdate_c']['enable_range_search']='1';

 ?>