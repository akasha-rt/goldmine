<?php
 // created: 2012-08-27 20:06:02
$dictionary['Campaign']['fields']['delivered_c']['enforced']='false';
$dictionary['Campaign']['fields']['delivered_c']['dependency']='';

 ?>