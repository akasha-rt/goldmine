<?php
 // created: 2012-08-27 20:10:50
$dictionary['Campaign']['fields']['notreported_c']['enforced']='false';
$dictionary['Campaign']['fields']['notreported_c']['dependency']='';

 ?>