<?php
 // created: 2012-08-27 20:09:26
$dictionary['Campaign']['fields']['unopened_c']['enforced']='false';
$dictionary['Campaign']['fields']['unopened_c']['dependency']='';

 ?>