<?php
 // created: 2012-08-27 20:07:39
$dictionary['Campaign']['fields']['peoplewhoopened_c']['enforced']='false';
$dictionary['Campaign']['fields']['peoplewhoopened_c']['dependency']='';

 ?>