<?php
 // created: 2012-08-27 20:11:11
$dictionary['Campaign']['fields']['social_c']['enforced']='false';
$dictionary['Campaign']['fields']['social_c']['dependency']='';

 ?>