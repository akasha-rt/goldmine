<?php
 // created: 2012-08-27 20:09:51
$dictionary['Campaign']['fields']['bounced_c']['enforced']='false';
$dictionary['Campaign']['fields']['bounced_c']['dependency']='';

 ?>