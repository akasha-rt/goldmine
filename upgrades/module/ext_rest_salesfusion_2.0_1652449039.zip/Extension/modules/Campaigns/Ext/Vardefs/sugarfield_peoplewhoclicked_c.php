<?php
 // created: 2012-08-27 20:08:09
$dictionary['Campaign']['fields']['peoplewhoclicked_c']['enforced']='false';
$dictionary['Campaign']['fields']['peoplewhoclicked_c']['dependency']='';

 ?>