<?php

//Test
require_once("modules/Dashboards/DefaultDashboardInstaller.php"); 

$obj = new DefaultDashboardInstaller();
$modules_1[0] = 'sf_webActivity';
$modules_1[1] = 'sf_Dialogs';
$modules_1[2] = 'sf_EventManagement';
$modules_1[3] = 'sf_WebActivityDetail';
$obj->buildDashboardsFromFiles($modules_1);