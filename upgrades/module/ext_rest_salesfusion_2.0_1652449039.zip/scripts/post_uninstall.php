<?php
/**
 * Clean up the custom buttons added to metadata
 *
 */

//remove all previously existing Salesfusion dashbaords for all users
$GLOBALS['log']->info('Sugar Market :: Uninstall :: Removing all Dashboard links');
global $db;
$db->query("UPDATE dashboards SET deleted=1 WHERE name='Salesfusion' AND deleted =0");
	
$GLOBALS['log']->info('Sugar Market Connector :: Uninstall :: Complete');

$modules_list[0] = '1ae9f19e-5294-11ec-9832-525400bc1033';
$modules_list[1] = '1ae9f19e-5294-11ec-9832-525400bc1038';
$modules_list[2] = '1ae9f19e-5294-11ec-9832-525400bc1087';

foreach($modules_list as $bid) {
	
   $db->query("UPDATE dashboards SET deleted=1 WHERE id='$bid' AND deleted =0");
}

