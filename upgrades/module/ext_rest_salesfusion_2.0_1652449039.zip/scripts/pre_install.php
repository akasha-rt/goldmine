<?php
/**
 * Post Installation script to add Campaign detail-view button, and sidecar buttons
 */

function pre_install()
{
    global $db;

	/*Remove custom dashboards */
	$modules_list[0] = '1ae9f19e-5294-11ec-9832-525400bc1033';
	$modules_list[1] = '1ae9f19e-5294-11ec-9832-525400bc1038';
	$modules_list[2] = '1ae9f19e-5294-11ec-9832-525400bc1087';
	$modules_list[3] = '1ae9f19e-5294-11ec-9832-525400bc1333';
	foreach($modules_list as $bid) {
		
	   $db->query("DELETE FROM dashboards WHERE id='$bid'");
	}
    
    $GLOBALS['log']->info("Pre-install for Sugar Market Connector beginning...");

    // get and cache any existing salesfusion settings
    $sourceConnector = @SourceFactory::getSource('ext_rest_salesfusion');

    if (!$sourceConnector) {
        return;
    }

    $orgName = @$sourceConnector->orgName;
    $iframeUrl = str_replace('&amp;', '&', @$sourceConnector->iframeUrl);
	echo "pre-existing orgName Sugar Market settings found.<br/>";	

    if (!$orgName && !$iframeUrl) {
        echo "No pre-existing Sugar Market settings found.<br/>";
        $GLOBALS['log']->info("No Sugar Market settings cached.");
		
		 // Truncate table for settings
		$query = "SHOW TABLES LIKE 'sf_temp_connector_settings'";		
		$result=$db->query($query);		
		if($row = $db->fetchByAssoc($result))
		{
			$db->query("TRUNCATE TABLE sf_temp_connector_settings");		
			echo "Truncate settings<br/>";			
		}		
        return;
    }

    // drop/create table for settings
    $query = "CREATE TABLE IF NOT EXISTS sf_temp_connector_settings ( orgId char(255), iframeUrl char(255) )";
    $db->query($query);

    // clear out any pre-existing settings, if any
    $db->query("TRUNCATE TABLE sf_temp_connector_settings");

    // insert current settings
    $query = "INSERT INTO sf_temp_connector_settings VALUES ('$orgName', '$iframeUrl')";
    $db->query($query);

    // confirm settings
    $query = "SELECT * FROM sf_temp_connector_settings LIMIT 1";
    $res = $db->query($query);
    if ($row = $db->fetchByAssoc($res)) {
        // output settings to user
        echo "Pre-existing Sugar Market settings found:<br/>\n";
        echo "&nbsp;&nbsp;&nbsp;\tOrg Name: {$row['orgId']}<br/>\n";
        echo "&nbsp;&nbsp;&nbsp;\tIframe URL: {$row['iframeUrl']}<br/>\n";

        $GLOBALS['log']->info("Pre-existing Sugar Market settings found:\n\tOrg Name: {$row['orgId']}\n\tIframe URL: {$row['iframeUrl']}\n");
    }
    else {
        // output settings to user
        echo "No Sugar Market settings cached.<br/>";
        $GLOBALS['log']->info("No Sugar Market settings cached.");
    }

}

?>