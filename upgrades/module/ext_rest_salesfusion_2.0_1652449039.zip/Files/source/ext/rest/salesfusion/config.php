<?php
/***CONNECTOR SOURCE***/
$config['name'] = 'Sugar Market';
$config['properties']['organization_name'] = '';
$config['properties']['iframe_url'] = '';

