<?php
// created: 2013-08-14 15:09:52
$mapping = array (
  'beans' => 
  array (
    'Accounts' => 
    array (
      'name' => 'name',
      'id' => 'id',
    ),
    'Contacts' => 
    array (
      'name' => 'full_name',
      'id' => 'id',
    ),
    'Leads' => 
    array (
      'name' => 'full_name',
      'id' => 'id',
    ),
  ),
);