<?php

	if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

	$connector_strings = array (
		'organization_name' => 'Organization Name',
        'iframe_url' => 'Sugar Market Iframe URL',
	);

?>