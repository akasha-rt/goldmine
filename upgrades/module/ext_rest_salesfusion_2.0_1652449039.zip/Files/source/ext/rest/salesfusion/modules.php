<?php

	$enabledModules = array(
		'Accounts' => 'Accounts', 
		'Campaigns' => 'Campaigns', 
		'Contacts' => 'Contacts', 
		'Leads' => 'Leads'
	);