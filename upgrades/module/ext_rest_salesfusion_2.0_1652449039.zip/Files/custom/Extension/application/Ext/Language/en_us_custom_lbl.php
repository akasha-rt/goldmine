<?php

$app_strings['LBL_SF_DIALOGS'] = 'Landing Pages';
$app_strings['LBL_SF_WEBACTIVITY'] = 'Web Activity';
$app_strings['LBL_SF_EVENTMANAGEMENT'] = 'Event Management';
$app_strings['LBL_SF_DIALOGS_FOCUS_DRAWER_DASHBOARD'] = 'Landing Page Focus Drawer';
$app_strings['LBL_SF_WEB_ACTIVITY_FOCUS_DRAWER_DASHBOARD']=  'Web Activity Focus Drawer';
$app_strings['LBL_SF_EVENT_MANAGEMENT_FOCUS_DRAWER_DASHBOARD'] = 'Event Management Focus Drawer';
$app_strings['LBL_SF_WEBDETAILSACTIVITY'] = 'Web Activity Detail';
$app_strings['LBL_WEB_ACTIVITY_DETAIL_FOCUS_DRAWER_DASHBOARD'] = 'Web Activity Detail Focus Drawer';
