<?php
$platforms[] = 'salesfusion_Data';
$platforms[] = 'salesfusion_Email';
$platforms[] = 'salesfusion_Frequent';
$platforms[] = 'salesfusion_Data_Integration';
$platforms[] = 'salesfusion_Email_Integration';
$platforms[] = 'salesfusion_Frequent_Integration';
$platforms[] = 'SugarMarket_Plaform1';
$platforms[] = 'SugarMarket_Plaform2';
