<?php
// created: 2012-12-12 16:37:26
$dictionary["sf_EventManagement"]["fields"]["sf_eventmanagement_contacts"] = array (
  'name' => 'sf_eventmanagement_contacts',
  'type' => 'link',
  'relationship' => 'sf_eventmanagement_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_SF_EVENTMANAGEMENT_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'sf_eventmanagement_contactscontacts_ida',
);
$dictionary["sf_EventManagement"]["fields"]["sf_eventmanagement_contacts_name"] = array (
  'name' => 'sf_eventmanagement_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SF_EVENTMANAGEMENT_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'sf_eventmanagement_contactscontacts_ida',
  'link' => 'sf_eventmanagement_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["sf_EventManagement"]["fields"]["sf_eventmanagement_contactscontacts_ida"] = array (
  'name' => 'sf_eventmanagement_contactscontacts_ida',
  'type' => 'id',
  'relationship' => 'sf_eventmanagement_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SF_EVENTMANAGEMENT_CONTACTS_FROM_SF_EVENTMANAGEMENT_TITLE',
);
