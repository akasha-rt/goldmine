<?php
// created: 2012-08-28 20:35:13
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_leads"] = array (
  'name' => 'sf_webactivity_leads',
  'type' => 'link',
  'relationship' => 'sf_webactivity_leads',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITY_LEADS_FROM_LEADS_TITLE',
  'id_name' => 'sf_webactivity_leadsleads_ida',
);
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_leads_name"] = array (
  'name' => 'sf_webactivity_leads_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITY_LEADS_FROM_LEADS_TITLE',
  'save' => true,
  'id_name' => 'sf_webactivity_leadsleads_ida',
  'link' => 'sf_webactivity_leads',
  'table' => 'leads',
  'module' => 'Leads',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_leadsleads_ida"] = array (
  'name' => 'sf_webactivity_leadsleads_ida',
  'type' => 'id',
  'relationship' => 'sf_webactivity_leads',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITY_LEADS_FROM_SF_WEBACTIVITY_TITLE',
);
