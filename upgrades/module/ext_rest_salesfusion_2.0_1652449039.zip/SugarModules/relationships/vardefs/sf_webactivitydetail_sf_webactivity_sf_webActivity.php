<?php
// created: 2012-08-28 20:35:15
$dictionary["sf_webActivity"]["fields"]["sf_webactivitydetail_sf_webactivity"] = array (
  'name' => 'sf_webactivitydetail_sf_webactivity',
  'type' => 'link',
  'relationship' => 'sf_webactivitydetail_sf_webactivity',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITYDETAIL_SF_WEBACTIVITY_FROM_SF_WEBACTIVITYDETAIL_TITLE',
);
