<?php
// created: 2012-08-28 20:35:15
$dictionary["sf_WebActivityDetail"]["fields"]["sf_webactivitydetail_sf_webactivity"] = array (
  'name' => 'sf_webactivitydetail_sf_webactivity',
  'type' => 'link',
  'relationship' => 'sf_webactivitydetail_sf_webactivity',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITYDETAIL_SF_WEBACTIVITY_FROM_SF_WEBACTIVITY_TITLE',
  'id_name' => 'sf_webactivitydetail_sf_webactivitysf_webactivity_ida',
);
$dictionary["sf_WebActivityDetail"]["fields"]["sf_webactivitydetail_sf_webactivity_name"] = array (
  'name' => 'sf_webactivitydetail_sf_webactivity_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITYDETAIL_SF_WEBACTIVITY_FROM_SF_WEBACTIVITY_TITLE',
  'save' => true,
  'id_name' => 'sf_webactivitydetail_sf_webactivitysf_webactivity_ida',
  'link' => 'sf_webactivitydetail_sf_webactivity',
  'table' => 'sf_webactivity',
  'module' => 'sf_webActivity',
  'rname' => 'name',
);
$dictionary["sf_WebActivityDetail"]["fields"]["sf_webactivitydetail_sf_webactivitysf_webactivity_ida"] = array (
  'name' => 'sf_webactivitydetail_sf_webactivitysf_webactivity_ida',
  'type' => 'id',
  'relationship' => 'sf_webactivitydetail_sf_webactivity',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITYDETAIL_SF_WEBACTIVITY_FROM_SF_WEBACTIVITYDETAIL_TITLE',
);
