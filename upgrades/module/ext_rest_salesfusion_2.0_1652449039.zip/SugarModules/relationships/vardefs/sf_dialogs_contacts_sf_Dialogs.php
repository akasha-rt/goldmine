<?php
// created: 2012-12-12 16:37:20
$dictionary["sf_Dialogs"]["fields"]["sf_dialogs_contacts"] = array (
  'name' => 'sf_dialogs_contacts',
  'type' => 'link',
  'relationship' => 'sf_dialogs_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_SF_DIALOGS_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'sf_dialogs_contactscontacts_ida',
);
$dictionary["sf_Dialogs"]["fields"]["sf_dialogs_contacts_name"] = array (
  'name' => 'sf_dialogs_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SF_DIALOGS_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'sf_dialogs_contactscontacts_ida',
  'link' => 'sf_dialogs_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["sf_Dialogs"]["fields"]["sf_dialogs_contactscontacts_ida"] = array (
  'name' => 'sf_dialogs_contactscontacts_ida',
  'type' => 'id',
  'relationship' => 'sf_dialogs_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SF_DIALOGS_CONTACTS_FROM_SF_DIALOGS_TITLE',
);
