<?php
// created: 2012-08-28 20:35:13
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_accounts"] = array (
  'name' => 'sf_webactivity_accounts',
  'type' => 'link',
  'relationship' => 'sf_webactivity_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'id_name' => 'sf_webactivity_accountsaccounts_ida',
);
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_accounts_name"] = array (
  'name' => 'sf_webactivity_accounts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'save' => true,
  'id_name' => 'sf_webactivity_accountsaccounts_ida',
  'link' => 'sf_webactivity_accounts',
  'table' => 'accounts',
  'module' => 'Accounts',
  'rname' => 'name',
);
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_accountsaccounts_ida"] = array (
  'name' => 'sf_webactivity_accountsaccounts_ida',
  'type' => 'id',
  'relationship' => 'sf_webactivity_accounts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_SF_WEBACTIVITY_TITLE',
);
