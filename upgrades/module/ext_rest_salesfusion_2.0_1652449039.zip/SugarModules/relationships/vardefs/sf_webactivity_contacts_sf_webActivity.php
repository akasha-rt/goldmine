<?php
// created: 2012-08-28 20:35:14
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_contacts"] = array (
  'name' => 'sf_webactivity_contacts',
  'type' => 'link',
  'relationship' => 'sf_webactivity_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITY_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'sf_webactivity_contactscontacts_ida',
);
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_contacts_name"] = array (
  'name' => 'sf_webactivity_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SF_WEBACTIVITY_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'sf_webactivity_contactscontacts_ida',
  'link' => 'sf_webactivity_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["sf_webActivity"]["fields"]["sf_webactivity_contactscontacts_ida"] = array (
  'name' => 'sf_webactivity_contactscontacts_ida',
  'type' => 'id',
  'relationship' => 'sf_webactivity_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITY_CONTACTS_FROM_SF_WEBACTIVITY_TITLE',
);
