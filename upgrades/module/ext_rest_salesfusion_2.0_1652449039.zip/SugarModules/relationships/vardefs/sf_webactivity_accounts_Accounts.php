<?php
// created: 2012-08-28 20:35:13
$dictionary["Account"]["fields"]["sf_webactivity_accounts"] = array (
  'name' => 'sf_webactivity_accounts',
  'type' => 'link',
  'relationship' => 'sf_webactivity_accounts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_SF_WEBACTIVITY_TITLE',
);
