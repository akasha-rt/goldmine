<?php
 // created: 2012-08-28 18:46:02
$layout_defs["sf_webActivity"]["subpanel_setup"]['sf_webactivity_leads'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_WEBACTIVITY_LEADS_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'sf_webactivity_leads',
);
