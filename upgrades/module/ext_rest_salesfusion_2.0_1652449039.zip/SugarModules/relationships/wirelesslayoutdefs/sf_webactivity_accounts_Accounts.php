<?php
 // created: 2012-08-28 20:35:14
$layout_defs["Accounts"]["subpanel_setup"]['sf_webactivity_accounts'] = array (
  'order' => 100,
  'module' => 'sf_webActivity',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_SF_WEBACTIVITY_TITLE',
  'get_subpanel_data' => 'sf_webactivity_accounts',
);
