<?php
 // created: 2012-08-28 18:46:02
$layout_defs["sf_webActivity"]["subpanel_setup"]['sf_webactivity_accounts'] = array (
  'order' => 100,
  'module' => 'Accounts',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'get_subpanel_data' => 'sf_webactivity_accounts',
);
