<?php
 // created: 2012-08-28 20:35:15
$layout_defs["sf_webActivity"]["subpanel_setup"]['sf_webactivitydetail_sf_webactivity'] = array (
  'order' => 100,
  'module' => 'sf_WebActivityDetail',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_SF_WEBACTIVITYDETAIL_SF_WEBACTIVITY_FROM_SF_WEBACTIVITYDETAIL_TITLE',
  'get_subpanel_data' => 'sf_webactivitydetail_sf_webactivity',
);
