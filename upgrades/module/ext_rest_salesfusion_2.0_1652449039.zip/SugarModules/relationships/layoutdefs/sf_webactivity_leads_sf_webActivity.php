<?php
 // created: 2012-08-28 18:45:59
$layout_defs["sf_webActivity"]["subpanel_setup"]['sf_webactivity_leads'] = array (
  'order' => 100,
  'module' => 'Leads',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SF_WEBACTIVITY_LEADS_FROM_LEADS_TITLE',
  'get_subpanel_data' => 'sf_webactivity_leads',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
