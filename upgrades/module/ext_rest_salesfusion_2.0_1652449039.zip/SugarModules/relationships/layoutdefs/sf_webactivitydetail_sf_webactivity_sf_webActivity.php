<?php
 // created: 2012-08-28 20:35:15
$layout_defs["sf_webActivity"]["subpanel_setup"]['sf_webactivitydetail_sf_webactivity'] = array (
  'order' => 100,
  'module' => 'sf_WebActivityDetail',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SF_WEBACTIVITYDETAIL_SF_WEBACTIVITY_FROM_SF_WEBACTIVITYDETAIL_TITLE',
  'get_subpanel_data' => 'sf_webactivitydetail_sf_webactivity',
  'top_buttons' => 
  array (

  ),
);
