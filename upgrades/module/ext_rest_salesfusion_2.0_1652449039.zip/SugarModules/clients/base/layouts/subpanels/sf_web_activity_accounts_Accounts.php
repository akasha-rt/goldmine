<?php
// created: 2014-01-23 15:24:40
$viewdefs['Accounts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SF_WEBACTIVITY_ACCOUNTS_FROM_ACCOUNTS_TITLE',
  'context' => 
  array (
    'link' => 'sf_webactivity_accounts',
  ),
);