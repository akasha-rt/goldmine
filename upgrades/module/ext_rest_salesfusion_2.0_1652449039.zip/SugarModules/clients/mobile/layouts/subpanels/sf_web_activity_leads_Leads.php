<?php
// created: 2014-01-23 15:24:41
$viewdefs['Leads']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SF_WEB_ACTIVITY_LEADS_FROM_SF_WEB_ACTIVITY_TITLE',
  'context' => 
  array (
    'link' => 'sf_webactivity_leads',
  ),
);