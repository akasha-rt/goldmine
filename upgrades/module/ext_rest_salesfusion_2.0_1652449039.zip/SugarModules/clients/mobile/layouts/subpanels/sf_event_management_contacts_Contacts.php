<?php
// created: 2014-01-23 15:24:41
$viewdefs['Contacts']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SF_EVENT_MANAGEMENT_CONTACTS_FROM_SF_EVENT_MANAGEMENT_TITLE',
  'context' => 
  array (
    'link' => 'sf_eventmanagement_contacts',
  ),
);