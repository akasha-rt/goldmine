<?php
// created: 2014-01-23 15:24:41
$viewdefs['sf_webActivity']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_SF_WEB_ACTIVITY_SF_WEB_ACTIVITY_DETAIL_FROM_SF_WEB_ACTIVITY_DETAIL_TITLE',
  'context' => 
  array (
    'link' => 'sf_webactivitydetail_sf_webactivity',
  ),
);