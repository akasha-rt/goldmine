<?php 
 // created: 2012-09-04 14:52:27
$mod_strings['LBL_SALESFUSIONEMAIL'] = 'SalesFusion Email';
?>
