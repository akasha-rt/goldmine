<?php 
 // created: 2012-09-04 14:52:27
$mod_strings['LBL_UNSUB'] = 'Unsubscribed';
$mod_strings['LBL_FORMS'] = 'Forms';
$mod_strings['LBL_FRIENDFORWARD'] = 'Friend Forward';
$mod_strings['LBL_DELIVERYSTATUS'] = 'Delivery Status';
$mod_strings['LBL_DELIVERYMESSAGE'] = 'Delivery Message';
$mod_strings['LBL_CLICKED'] = 'Clicked';
$mod_strings['LBL_OPENED'] = 'Open';

?>
