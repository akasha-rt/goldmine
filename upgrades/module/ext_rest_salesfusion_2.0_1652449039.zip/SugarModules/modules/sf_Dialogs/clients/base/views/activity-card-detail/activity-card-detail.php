<?php
$viewdefs['sf_Dialogs']['base']['view']['activity-card-detail'] = [
    'panels' => [
        [
            'name' => 'panel_header',
            'label' => 'LBL_PANEL_1',
            'css_class' => 'panel-header',
            'fields' => [],
            'dateTimeStamp' => [
                'name' => 'completed_date',
            ],
        ],
    ],
];