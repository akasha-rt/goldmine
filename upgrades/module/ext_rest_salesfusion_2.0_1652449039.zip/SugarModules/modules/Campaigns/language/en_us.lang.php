<?php 
 // created: 2012-09-04 14:52:27
$mod_strings['LBL_POSTDATE'] = 'Post Date';
$mod_strings['LBL_SENT'] = 'Sent';
$mod_strings['LBL_DELIVERED'] = 'Delivered';
$mod_strings['LBL_TOTALOPENS'] = 'Total Opens';
$mod_strings['LBL_TOTALCLICKS'] = 'Total Clicks';
$mod_strings['LBL_PEOPLEWHOOPENED'] = 'People Who Opened';
$mod_strings['LBL_PEOPLEWHOCLICKED'] = 'People Who Clicked';
$mod_strings['LBL_UNOPENED'] = 'Unopened';
$mod_strings['LBL_BOUNCED'] = 'Bounced';
$mod_strings['LBL_UNSUBSCRIBED'] = 'Unsubscribed';
$mod_strings['LBL_NOTREPORTED'] = 'Not Reported';
$mod_strings['LBL_SOCIAL'] = 'Social';
$mod_strings['LBL_FORWARDS'] = 'Forwards';

?>
