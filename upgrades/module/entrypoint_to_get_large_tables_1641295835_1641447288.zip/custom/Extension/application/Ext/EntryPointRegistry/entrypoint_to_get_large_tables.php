<?php

$entry_point_registry['entrypoint_to_get_large_tables'] = array(
    'file' => 'custom/entrypoint_to_get_large_tables.php',
    'auth' => true
);