<?php
// created: 2022-07-20 13:29:45
$viewdefs['PT_PortalTeams']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PT_PORTALTEAMS_PU_PORTALUSERS_FROM_PU_PORTALUSERS_TITLE',
  'context' => 
  array (
    'link' => 'pt_portalteams_pu_portalusers',
  ),
);

$viewdefs['PT_PortalTeams']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PT_PORTALTEAMS_PU_PORTALUSERS_FROM_PU_PORTALUSERS_TITLE',
  'context' => 
  array (
    'link' => 'pt_portalteams_pu_portalusers',
  ),
);

$viewdefs['PT_PortalTeams']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PT_PORTALTEAMS_PU_PORTALUSERS_FROM_PU_PORTALUSERS_TITLE',
  'context' => 
  array (
    'link' => 'pt_portalteams_pu_portalusers',
  ),
);

$viewdefs['PT_PortalTeams']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PT_PORTALTEAMS_PU_PORTALUSERS_FROM_PU_PORTALUSERS_TITLE',
  'context' => 
  array (
    'link' => 'pt_portalteams_pu_portalusers',
  ),
);