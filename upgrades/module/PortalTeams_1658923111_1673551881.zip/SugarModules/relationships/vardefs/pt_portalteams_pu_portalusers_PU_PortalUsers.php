<?php
// created: 2022-07-27 11:58:31
$dictionary["PU_PortalUsers"]["fields"]["pt_portalteams_pu_portalusers"] = array (
  'name' => 'pt_portalteams_pu_portalusers',
  'type' => 'link',
  'relationship' => 'pt_portalteams_pu_portalusers',
  'source' => 'non-db',
  'module' => 'PT_PortalTeams',
  'bean_name' => 'PT_PortalTeams',
  'vname' => 'LBL_PT_PORTALTEAMS_PU_PORTALUSERS_FROM_PT_PORTALTEAMS_TITLE',
  'id_name' => 'pt_portalteams_pu_portaluserspt_portalteams_ida',
);
