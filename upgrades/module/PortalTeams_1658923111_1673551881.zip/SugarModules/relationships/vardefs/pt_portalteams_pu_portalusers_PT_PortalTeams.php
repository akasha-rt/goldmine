<?php
// created: 2022-07-27 11:58:31
$dictionary["PT_PortalTeams"]["fields"]["pt_portalteams_pu_portalusers"] = array (
  'name' => 'pt_portalteams_pu_portalusers',
  'type' => 'link',
  'relationship' => 'pt_portalteams_pu_portalusers',
  'source' => 'non-db',
  'module' => 'PU_PortalUsers',
  'bean_name' => 'PU_PortalUsers',
  'vname' => 'LBL_PT_PORTALTEAMS_PU_PORTALUSERS_FROM_PU_PORTALUSERS_TITLE',
  'id_name' => 'pt_portalteams_pu_portaluserspu_portalusers_idb',
);
