<?php
// created: 2021-03-26 19:33:36
$dictionary["IN_Incentives"]["fields"]["in_incentives_cc_coupon_codes"] = array (
  'name' => 'in_incentives_cc_coupon_codes',
  'type' => 'link',
  'relationship' => 'in_incentives_cc_coupon_codes',
  'source' => 'non-db',
  'module' => 'CC_Coupon_Codes',
  'bean_name' => 'CC_Coupon_Codes',
  'vname' => 'LBL_IN_INCENTIVES_CC_COUPON_CODES_FROM_IN_INCENTIVES_TITLE',
  'id_name' => 'in_incentives_cc_coupon_codesin_incentives_ida',
  'link-type' => 'many',
  'side' => 'left',
);
