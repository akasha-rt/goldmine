<?php
 // created: 2021-03-26 19:33:36
$layout_defs["IN_Incentives"]["subpanel_setup"]['in_incentives_cc_coupon_codes'] = array (
  'order' => 100,
  'module' => 'CC_Coupon_Codes',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_IN_INCENTIVES_CC_COUPON_CODES_FROM_CC_COUPON_CODES_TITLE',
  'get_subpanel_data' => 'in_incentives_cc_coupon_codes',
);
