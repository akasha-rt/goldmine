<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipas',
  'LBL_TEAMS' => 'Equipas',
  'LBL_TEAM_ID' => 'Id Equipa',
  'LBL_ASSIGNED_TO_ID' => 'ID de Utilizador Atribuído',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuído a',
  'LBL_TAGS_LINK' => 'Etiquetas',
  'LBL_TAGS' => 'Etiquetas',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data da Criação',
  'LBL_DATE_MODIFIED' => 'Data da Modificação',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado Por Nome',
  'LBL_CREATED' => 'Criado Por',
  'LBL_CREATED_ID' => 'ID do Utilizador que Criou',
  'LBL_DOC_OWNER' => 'Proprietário do Documento',
  'LBL_USER_FAVORITES' => 'Utilizadores que adicionaram aos Favoritos',
  'LBL_DESCRIPTION' => 'Descrição',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nome',
  'LBL_CREATED_USER' => 'Criado por Utilizador',
  'LBL_MODIFIED_USER' => 'Modificado por Utilizador',
  'LBL_LIST_NAME' => 'Nome',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Remover',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificado Por Nome',
  'LBL_COMMENTLOG' => 'Comment Log',
  'LBL_LIST_FORM_TITLE' => 'Incentives Lista',
  'LBL_MODULE_NAME' => 'Incentives',
  'LBL_MODULE_TITLE' => 'Incentives',
  'LBL_MODULE_NAME_SINGULAR' => 'Incentives',
  'LBL_HOMEPAGE_TITLE' => 'Minha Incentives',
  'LNK_NEW_RECORD' => 'Criar Incentives',
  'LNK_LIST' => 'Vista Incentives',
  'LNK_IMPORT_IN_INCENTIVES' => 'Import Incentives',
  'LBL_SEARCH_FORM_TITLE' => 'Pesquisar Incentives',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Histórico',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Fluxo de Atividades',
  'LBL_IN_INCENTIVES_SUBPANEL_TITLE' => 'Incentives',
  'LBL_NEW_FORM_TITLE' => 'Novo Incentives',
  'LNK_IMPORT_VCARD' => 'Import Incentives vCard',
  'LBL_IMPORT' => 'Import Incentives',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Incentives record by importing a vCard from your file system.',
  'LBL_IN_INCENTIVES_FOCUS_DRAWER_DASHBOARD' => 'Incentives Focus Drawer',
  'LBL_START_DATE' => 'Start Date',
  'LBL_END_DATE' => 'End Date',
  'LBL_NOTES' => 'Notes',
  'LBL_STATUS' => 'Status',
  'LBL_COUPON' => 'Coupon?',
);