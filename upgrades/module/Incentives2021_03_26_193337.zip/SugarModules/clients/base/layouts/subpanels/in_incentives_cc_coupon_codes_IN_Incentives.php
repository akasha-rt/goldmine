<?php
// created: 2021-03-26 19:33:35
$viewdefs['IN_Incentives']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IN_INCENTIVES_CC_COUPON_CODES_FROM_CC_COUPON_CODES_TITLE',
  'context' => 
  array (
    'link' => 'in_incentives_cc_coupon_codes',
  ),
);