<?php
 // created: 2021-03-26 19:33:36
$layout_defs["ProductTemplates"]["subpanel_setup"]['in_incentives_producttemplates'] = array (
  'order' => 100,
  'module' => 'IN_Incentives',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_IN_INCENTIVES_PRODUCTTEMPLATES_FROM_IN_INCENTIVES_TITLE',
  'get_subpanel_data' => 'in_incentives_producttemplates',
);
