<?php
// created: 2022-10-21 15:52:35
$extensionOrderMap = array (
  'custom/Extension/modules/ProductTemplates/Ext/WirelessLayoutdefs/in_incentives_producttemplates_ProductTemplates.php' => 
  array (
    'md5' => '7852c647859d242333f14f27afd6ecda',
    'mtime' => 1616787228,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/WirelessLayoutdefs/producttemplates_pu_portalusers_1_ProductTemplates.php' => 
  array (
    'md5' => '4127af57c333e403ae270dc1da7c5bf4',
    'mtime' => 1659534257,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/WirelessLayoutdefs/producttemplates_pt_portalteams_1_ProductTemplates.php' => 
  array (
    'md5' => '1636940755912141d77e3bfeb2bdd1b7',
    'mtime' => 1659534365,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/WirelessLayoutdefs/producttemplates_pa_productaccessories_2_ProductTemplates.php' => 
  array (
    'md5' => 'c2164d26fd2f2ca30913b907658e9f1a',
    'mtime' => 1662547805,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/WirelessLayoutdefs/producttemplates_pa_productaccessories_1_ProductTemplates.php' => 
  array (
    'md5' => 'a3d76762c689e70e9989460d325fcf35',
    'mtime' => 1662554090,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/WirelessLayoutdefs/producttemplates_accounts_1_ProductTemplates.php' => 
  array (
    'md5' => '89ace63af47c491084a5d00314f7dd25',
    'mtime' => 1666367553,
    'is_override' => false,
  ),
);