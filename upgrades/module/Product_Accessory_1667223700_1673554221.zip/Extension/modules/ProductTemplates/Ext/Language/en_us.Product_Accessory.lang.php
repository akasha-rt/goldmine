<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_MODULE_NAME'] = 'Product Number';
$mod_strings['LNK_PRODUCT_LIST'] = 'View Product Number';
$mod_strings['LBL_PRODUCT_TEMPLATES_FOCUS_DRAWER_DASHBOARD'] = 'Product Number Focus Drawer';
$mod_strings['LBL_PRODUCT_TEMPLATE_RECORD_DASHBOARD'] = 'Product Number Record Dashboard';
$mod_strings['LBL_CREATE_QUOTE'] = 'Create Quote';
$mod_strings['LBL_MODEL_DESCRIPTION'] = 'Model Description';
