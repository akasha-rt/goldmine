<?php
// created: 2022-10-21 15:51:57
$extensionOrderMap = array (
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.Incentives.php' => 
  array (
    'md5' => 'b4a7e2a349b1d7d43c6e750f6af6ff0e',
    'mtime' => 1616787223,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.customproducttemplates_pu_portalusers_1.php' => 
  array (
    'md5' => '8f3865cebda583ab41630bb1df46dd15',
    'mtime' => 1659534254,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.customproducttemplates_pt_portalteams_1.php' => 
  array (
    'md5' => 'dcae63709454ab7040ba30bda236433a',
    'mtime' => 1659534316,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.customproducttemplates_pa_productaccessories_1.php' => 
  array (
    'md5' => 'e6f4a8eac10ea92974ac5a0f61c8bb3a',
    'mtime' => 1662374431,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.customproducttemplates_pa_productaccessories_2.php' => 
  array (
    'md5' => 'fc5d37125b01243280e37d0ded8262f5',
    'mtime' => 1662547800,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.customaccounts_producttemplates_1.php' => 
  array (
    'md5' => '67b79a0db8c6a43174662a5772205711',
    'mtime' => 1666361562,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Language/ru_RU.customproducttemplates_accounts_1.php' => 
  array (
    'md5' => 'c94b4c7313978b11c9e53050f59c1758',
    'mtime' => 1666362344,
    'is_override' => false,
  ),
);