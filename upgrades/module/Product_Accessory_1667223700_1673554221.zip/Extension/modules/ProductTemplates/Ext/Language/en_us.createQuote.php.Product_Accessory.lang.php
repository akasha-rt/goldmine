<?php
$mod_strings['LBL_CREATE_QUOTE_LABEL'] = 'Create Quote';
$mod_strings['LBL_MFT_PART_NUM'] = 'Model Number';