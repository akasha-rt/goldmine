<?php
 // created: 2022-10-05 12:38:56
$dictionary['ProductTemplate']['fields']['model_description_c']['labelValue']='Model Description';
$dictionary['ProductTemplate']['fields']['model_description_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['ProductTemplate']['fields']['model_description_c']['enforced']='';
$dictionary['ProductTemplate']['fields']['model_description_c']['dependency']='';
$dictionary['ProductTemplate']['fields']['model_description_c']['required_formula']='';
$dictionary['ProductTemplate']['fields']['model_description_c']['readonly_formula']='';

 ?>