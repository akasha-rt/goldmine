<?php
// created: 2022-09-07 10:49:55
$dictionary["ProductTemplate"]["fields"]["producttemplates_pa_productaccessories_2"] = array (
  'name' => 'producttemplates_pa_productaccessories_2',
  'type' => 'link',
  'relationship' => 'producttemplates_pa_productaccessories_2',
  'source' => 'non-db',
  'module' => 'PA_ProductAccessories',
  'bean_name' => 'PA_ProductAccessories',
  'vname' => 'LBL_PRODUCTTEMPLATES_PA_PRODUCTACCESSORIES_2_FROM_PA_PRODUCTACCESSORIES_TITLE',
  'id_name' => 'producttema15bssories_idb',
);
