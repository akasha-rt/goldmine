<?php

$dictionary['ProductTemplate']['fields']['shipping_cost']['name'] = 'shipping_cost';
$dictionary['ProductTemplate']['fields']['shipping_cost']['vname'] = 'LBL_SHIPPING_COST';
$dictionary['ProductTemplate']['fields']['shipping_cost']['type'] = 'decimal';
$dictionary['ProductTemplate']['fields']['shipping_cost']['enforced'] = '';
$dictionary['ProductTemplate']['fields']['shipping_cost']['dependency'] = '';
$dictionary['ProductTemplate']['fields']['shipping_cost']['required'] = false;
$dictionary['ProductTemplate']['fields']['shipping_cost']['massupdate'] = '0';
$dictionary['ProductTemplate']['fields']['shipping_cost']['default'] = '';
$dictionary['ProductTemplate']['fields']['shipping_cost']['no_default'] = false;
$dictionary['ProductTemplate']['fields']['shipping_cost']['comments'] = 'Shipping Cost';
$dictionary['ProductTemplate']['fields']['shipping_cost']['help'] = '';
$dictionary['ProductTemplate']['fields']['shipping_cost']['importable'] = 'true';
$dictionary['ProductTemplate']['fields']['shipping_cost']['duplicate_merge'] = 'disabled';
$dictionary['ProductTemplate']['fields']['shipping_cost']['duplicate_merge_dom_value'] = '0';
$dictionary['ProductTemplate']['fields']['shipping_cost']['audited'] = false;
$dictionary['ProductTemplate']['fields']['shipping_cost']['reportable'] = true;
$dictionary['ProductTemplate']['fields']['shipping_cost']['unified_search'] = false;
$dictionary['ProductTemplate']['fields']['shipping_cost']['merge_filter'] = 'disabled';
$dictionary['ProductTemplate']['fields']['shipping_cost']['calculated'] = false;
$dictionary['ProductTemplate']['fields']['shipping_cost']['len'] = '10';

