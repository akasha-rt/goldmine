<?php
// created: 2022-10-21 15:52:35
$extensionOrderMap = array (
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/full_text_search_admin.php' => 
  array (
    'md5' => '5d46537f047dd9b94e91ed43741fc473',
    'mtime' => 1557329896,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/in_incentives_producttemplates_ProductTemplates.php' => 
  array (
    'md5' => 'b15788b54469ecd51086e109b7114c11',
    'mtime' => 1616787228,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/sugarfield_shippiing_cost.php' => 
  array (
    'md5' => '9895d203b650cfbf3582b523e5820899',
    'mtime' => 1659533721,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/sugarfield_freight_insurance.php' => 
  array (
    'md5' => 'cc0c48b219aee28a960a2b310d4f56dd',
    'mtime' => 1659533727,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/producttemplates_pu_portalusers_1_ProductTemplates.php' => 
  array (
    'md5' => 'd372f2a1a0fd62f077abea0f6c6ac2cd',
    'mtime' => 1659534257,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/producttemplates_pt_portalteams_1_ProductTemplates.php' => 
  array (
    'md5' => '1c3f9138fc6d29e1a1574f7da9a8f079',
    'mtime' => 1659534365,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/producttemplates_pa_productaccessories_2_ProductTemplates.php' => 
  array (
    'md5' => '6d4874f8968f87e5b637599b76b4e8ee',
    'mtime' => 1662547805,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/producttemplates_pa_productaccessories_1_ProductTemplates.php' => 
  array (
    'md5' => 'a28fe941405f35a9f7b9ff284e1d5ddd',
    'mtime' => 1662554090,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/sugarfield_model_description_c.php' => 
  array (
    'md5' => 'd80fbfb9d03274833e47282a28c07fd1',
    'mtime' => 1664973536,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Vardefs/producttemplates_accounts_1_ProductTemplates.php' => 
  array (
    'md5' => 'aea0953e2b2f45cffb4f59e590a8073c',
    'mtime' => 1666367553,
    'is_override' => false,
  ),
);