<?php

$dictionary['ProductTemplate']['fields']['freight_insurance']['name'] = 'freight_insurance';
$dictionary['ProductTemplate']['fields']['freight_insurance']['vname'] = 'LBL_FREIGHT_INSURANCE';
$dictionary['ProductTemplate']['fields']['freight_insurance']['type'] = 'decimal';
$dictionary['ProductTemplate']['fields']['freight_insurance']['enforced'] = '';
$dictionary['ProductTemplate']['fields']['freight_insurance']['dependency'] = '';
$dictionary['ProductTemplate']['fields']['freight_insurance']['required'] = false;
$dictionary['ProductTemplate']['fields']['freight_insurance']['massupdate'] = '0';
$dictionary['ProductTemplate']['fields']['freight_insurance']['default'] = '';
$dictionary['ProductTemplate']['fields']['freight_insurance']['no_default'] = false;
$dictionary['ProductTemplate']['fields']['freight_insurance']['comments'] = 'FREIGHT INSURANCE';
$dictionary['ProductTemplate']['fields']['freight_insurance']['help'] = '';
$dictionary['ProductTemplate']['fields']['freight_insurance']['importable'] = 'true';
$dictionary['ProductTemplate']['fields']['freight_insurance']['duplicate_merge'] = 'disabled';
$dictionary['ProductTemplate']['fields']['freight_insurance']['duplicate_merge_dom_value'] = '0';
$dictionary['ProductTemplate']['fields']['freight_insurance']['audited'] = false;
$dictionary['ProductTemplate']['fields']['freight_insurance']['reportable'] = true;
$dictionary['ProductTemplate']['fields']['freight_insurance']['unified_search'] = false;
$dictionary['ProductTemplate']['fields']['freight_insurance']['merge_filter'] = 'disabled';
$dictionary['ProductTemplate']['fields']['freight_insurance']['calculated'] = false;
$dictionary['ProductTemplate']['fields']['freight_insurance']['len'] = '10';
