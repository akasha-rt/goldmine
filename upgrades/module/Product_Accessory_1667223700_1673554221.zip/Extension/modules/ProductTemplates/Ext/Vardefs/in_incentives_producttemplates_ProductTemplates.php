<?php
// created: 2021-03-26 19:33:36
$dictionary["ProductTemplate"]["fields"]["in_incentives_producttemplates"] = array (
  'name' => 'in_incentives_producttemplates',
  'type' => 'link',
  'relationship' => 'in_incentives_producttemplates',
  'source' => 'non-db',
  'module' => 'IN_Incentives',
  'bean_name' => false,
  'vname' => 'LBL_IN_INCENTIVES_PRODUCTTEMPLATES_FROM_PRODUCTTEMPLATES_TITLE',
  'id_name' => 'in_incentives_producttemplatesproducttemplates_ida',
  'link-type' => 'many',
  'side' => 'left',
);
