<?php
// created: 2022-09-07 12:34:47
$dictionary["ProductTemplate"]["fields"]["producttemplates_pa_productaccessories_1"] = array (
  'name' => 'producttemplates_pa_productaccessories_1',
  'type' => 'link',
  'relationship' => 'producttemplates_pa_productaccessories_1',
  'source' => 'non-db',
  'module' => 'PA_ProductAccessories',
  'bean_name' => 'PA_ProductAccessories',
  'vname' => 'LBL_PRODUCTTEMPLATES_PA_PRODUCTACCESSORIES_1_FROM_PA_PRODUCTACCESSORIES_TITLE',
  'id_name' => 'productteme68cssories_idb',
);
