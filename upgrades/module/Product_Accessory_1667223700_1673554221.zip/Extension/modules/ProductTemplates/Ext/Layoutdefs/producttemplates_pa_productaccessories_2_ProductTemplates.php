<?php
 // created: 2022-09-07 10:49:55
$layout_defs["ProductTemplates"]["subpanel_setup"]['producttemplates_pa_productaccessories_2'] = array (
  'order' => 100,
  'module' => 'PA_ProductAccessories',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_PRODUCTTEMPLATES_PA_PRODUCTACCESSORIES_2_FROM_PA_PRODUCTACCESSORIES_TITLE',
  'get_subpanel_data' => 'producttemplates_pa_productaccessories_2',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
