<?php
// created: 2022-10-21 15:52:35
$extensionOrderMap = array (
  'custom/Extension/modules/ProductTemplates/Ext/Layoutdefs/in_incentives_producttemplates_ProductTemplates.php' => 
  array (
    'md5' => '88d7f145b4b727e52940ceb5edfb9f77',
    'mtime' => 1616787228,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Layoutdefs/producttemplates_pu_portalusers_1_ProductTemplates.php' => 
  array (
    'md5' => 'ca49b49ff5ac75a7310df2c6b0f25acc',
    'mtime' => 1659534257,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Layoutdefs/producttemplates_pt_portalteams_1_ProductTemplates.php' => 
  array (
    'md5' => '7c93d9019e953b053f35384eb5d658f9',
    'mtime' => 1659534365,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Layoutdefs/producttemplates_pa_productaccessories_1_ProductTemplates.php' => 
  array (
    'md5' => 'bc4ff076797bc383a69b6bc3836f1b31',
    'mtime' => 1662554090,
    'is_override' => false,
  ),
  'custom/Extension/modules/ProductTemplates/Ext/Layoutdefs/producttemplates_accounts_1_ProductTemplates.php' => 
  array (
    'md5' => '3435f8eb6da630de2f9e6ad7e7fb7fbb',
    'mtime' => 1666367553,
    'is_override' => false,
  ),
);