<?php
// created: 2021-03-26 19:33:35
$viewdefs['ProductTemplates']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IN_INCENTIVES_PRODUCTTEMPLATES_FROM_IN_INCENTIVES_TITLE',
  'context' => 
  array (
    'link' => 'in_incentives_producttemplates',
  ),
);