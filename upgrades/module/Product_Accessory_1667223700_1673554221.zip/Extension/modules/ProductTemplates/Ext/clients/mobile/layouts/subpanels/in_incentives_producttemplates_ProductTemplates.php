<?php
// created: 2021-03-26 19:33:36
$viewdefs['ProductTemplates']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_IN_INCENTIVES_PRODUCTTEMPLATES_FROM_IN_INCENTIVES_TITLE',
  'context' => 
  array (
    'link' => 'in_incentives_producttemplates',
  ),
);