<?php
// created: 2022-09-07 10:49:55
$viewdefs['ProductTemplates']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_PRODUCTTEMPLATES_PA_PRODUCTACCESSORIES_2_FROM_PA_PRODUCTACCESSORIES_TITLE',
  'context' => 
  array (
    'link' => 'producttemplates_pa_productaccessories_2',
  ),
);