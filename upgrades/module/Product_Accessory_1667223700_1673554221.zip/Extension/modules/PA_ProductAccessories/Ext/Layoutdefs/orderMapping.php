<?php
// created: 2022-10-01 10:02:53
$extensionOrderMap = array (
  'custom/Extension/modules/PA_ProductAccessories/Ext/Layoutdefs/producttemplates_pa_productaccessories_1_PA_ProductAccessories.php' => 
  array (
    'md5' => '35432044a0ea2a50ccd4d23938eb72e6',
    'mtime' => 1662554090,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Layoutdefs/pa_productaccessories_pu_portalusers_1_PA_ProductAccessories.php' => 
  array (
    'md5' => '12d8efd25ba931b56172c8f4d12e1075',
    'mtime' => 1664618571,
    'is_override' => false,
  ),
);