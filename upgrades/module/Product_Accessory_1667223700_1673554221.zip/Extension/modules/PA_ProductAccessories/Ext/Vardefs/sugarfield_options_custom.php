<?php
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['dbType'] = 'text';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['size'] = '20';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['len'] = '';
