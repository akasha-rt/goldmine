<?php

$dictionary['PA_ProductAccessories']['fields']['product_options_c']['name'] = 'product_options_c';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['vname'] = 'LBL_PRODUCT_OPTIONS';  
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['type'] = 'option';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['enforced'] = '';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['dependency'] = '';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['required'] = false;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['massupdate'] = '0';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['default'] = '';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['no_default'] = false;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['comments'] = 'Custom Opt';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['help'] = '';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['importable'] = 'true';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['duplicate_merge'] = 'disabled';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['duplicate_merge_dom_value'] = '0';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['audited'] = true;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['reportable'] = true;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['unified_search'] = false;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['inline_edit'] = false;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['merge_filter'] = 'disabled';
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['calculated'] = false;
$dictionary['PA_ProductAccessories']['fields']['product_options_c']['dbType'] = 'text';
?>