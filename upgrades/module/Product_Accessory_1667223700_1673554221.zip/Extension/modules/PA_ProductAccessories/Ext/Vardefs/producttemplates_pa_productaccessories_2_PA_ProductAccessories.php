<?php
// created: 2022-09-07 10:49:55
$dictionary["PA_ProductAccessories"]["fields"]["producttemplates_pa_productaccessories_2"] = array (
  'name' => 'producttemplates_pa_productaccessories_2',
  'type' => 'link',
  'relationship' => 'producttemplates_pa_productaccessories_2',
  'source' => 'non-db',
  'module' => 'ProductTemplates',
  'bean_name' => 'ProductTemplate',
  'vname' => 'LBL_PRODUCTTEMPLATES_PA_PRODUCTACCESSORIES_2_FROM_PRODUCTTEMPLATES_TITLE',
  'id_name' => 'producttemplates_pa_productaccessories_2producttemplates_ida',
);
