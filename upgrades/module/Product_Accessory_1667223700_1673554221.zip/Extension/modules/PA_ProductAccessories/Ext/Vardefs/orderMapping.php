<?php
// created: 2022-10-05 14:29:20
$extensionOrderMap = array (
  'custom/Extension/modules/PA_ProductAccessories/Ext/Vardefs/producttemplates_pa_productaccessories_2_PA_ProductAccessories.php' => 
  array (
    'md5' => '6c2734710ab252e8c88c0a227b70eb63',
    'mtime' => 1662547805,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Vardefs/producttemplates_pa_productaccessories_1_PA_ProductAccessories.php' => 
  array (
    'md5' => '3540a42a794fe0e69e7c1b4c9efd9f42',
    'mtime' => 1662554090,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Vardefs/pa_productaccessories_pu_portalusers_1_PA_ProductAccessories.php' => 
  array (
    'md5' => 'b15adbfc1e4b9a0b571bb14fd8f913ba',
    'mtime' => 1664618571,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Vardefs/sugarfield_options.php' => 
  array (
    'md5' => 'd411c7a6043f8601fd4b026b0aac0c5e',
    'mtime' => 1664979643,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Vardefs/sugarfield_options_custom.php' => 
  array (
    'md5' => '2d9c6582763534150fc9777e26abcfc1',
    'mtime' => 1664980118,
    'is_override' => false,
  ),
);