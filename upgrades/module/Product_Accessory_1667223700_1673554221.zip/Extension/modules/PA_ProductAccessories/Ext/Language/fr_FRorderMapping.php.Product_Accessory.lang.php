<?php
// created: 2022-10-01 10:02:52
$extensionOrderMap = array (
  'custom/Extension/modules/PA_ProductAccessories/Ext/Language/fr_FR.customproducttemplates_pa_productaccessories_1.php' => 
  array (
    'md5' => '20e3fc60225587f7eec32f86887b3601',
    'mtime' => 1662374431,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Language/fr_FR.customproducttemplates_pa_productaccessories_2.php' => 
  array (
    'md5' => 'd84e33a832e179e47f4f9d74731a4806',
    'mtime' => 1662547800,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Language/fr_FR.custompa_productaccessories_pu_portalusers_1.php' => 
  array (
    'md5' => '8cad08b888fd6dcd59c749e7f7f09445',
    'mtime' => 1664616564,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/Language/fr_FR.custompu_portalusers_pa_productaccessories_1.php' => 
  array (
    'md5' => '03352193d73ebd175eb06afd6da0224b',
    'mtime' => 1664617308,
    'is_override' => false,
  ),
);