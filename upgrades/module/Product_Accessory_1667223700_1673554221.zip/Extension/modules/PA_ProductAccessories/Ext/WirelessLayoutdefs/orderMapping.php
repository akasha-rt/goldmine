<?php
// created: 2022-10-01 10:02:53
$extensionOrderMap = array (
  'custom/Extension/modules/PA_ProductAccessories/Ext/WirelessLayoutdefs/producttemplates_pa_productaccessories_2_PA_ProductAccessories.php' => 
  array (
    'md5' => '3afde3bdae58fddb77018adc2b6e6850',
    'mtime' => 1662547805,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/WirelessLayoutdefs/producttemplates_pa_productaccessories_1_PA_ProductAccessories.php' => 
  array (
    'md5' => '7d43ccab9b4366c8fa9b555bce1a13fa',
    'mtime' => 1662554090,
    'is_override' => false,
  ),
  'custom/Extension/modules/PA_ProductAccessories/Ext/WirelessLayoutdefs/pa_productaccessories_pu_portalusers_1_PA_ProductAccessories.php' => 
  array (
    'md5' => 'a293cbd43adcd98a67d8603caeeedf03',
    'mtime' => 1664618571,
    'is_override' => false,
  ),
);