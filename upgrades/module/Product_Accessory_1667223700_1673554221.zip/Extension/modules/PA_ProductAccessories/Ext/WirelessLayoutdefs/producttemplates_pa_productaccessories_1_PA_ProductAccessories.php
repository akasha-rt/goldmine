<?php
 // created: 2022-09-07 12:34:47
$layout_defs["PA_ProductAccessories"]["subpanel_setup"]['producttemplates_pa_productaccessories_1'] = array (
  'order' => 100,
  'module' => 'ProductTemplates',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_PRODUCTTEMPLATES_PA_PRODUCTACCESSORIES_1_FROM_PRODUCTTEMPLATES_TITLE',
  'get_subpanel_data' => 'producttemplates_pa_productaccessories_1',
);
