<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/producttemplates_pa_productaccessories_1MetaData.php');

?>