<?php
// created: 2021-04-12 23:13:59
$viewdefs['ProductTemplates']['base']['filter']['default'] = array (
  'default_filter' => 'all_records',
  'fields' => 
  array (
    'name' => 
    array (
    ),
    'mft_part_num' => 
    array (
    ),
    'vendor_part_num' => 
    array (
    ),
    'type_name' => 
    array (
    ),
    'category_name' => 
    array (
    ),
    'date_available' => 
    array (
    ),
    'support_term' => 
    array (
    ),
    'tag' => 
    array (
    ),
    '$favorite' => 
    array (
      'predefined_filter' => true,
      'vname' => 'LBL_FAVORITES_FILTER',
    ),
    'list_price' => 
    array (
    ),
    'discount_price' => 
    array (
    ),
  ),
);