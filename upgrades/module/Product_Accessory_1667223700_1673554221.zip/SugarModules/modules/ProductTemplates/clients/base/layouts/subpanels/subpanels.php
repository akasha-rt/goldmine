<?php
$viewdefs['ProductTemplates']['base']['layout']['subpanels'] = array(
    'components' => array(),
);