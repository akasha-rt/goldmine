<?php 
 // created: 2022-10-31 13:41:36
$mod_strings['LBL_PRODUCT_OPTIONS'] = 'Product Options';
$mod_strings['LBL_CATEGORY_URL'] = 'Category URL';

?>
