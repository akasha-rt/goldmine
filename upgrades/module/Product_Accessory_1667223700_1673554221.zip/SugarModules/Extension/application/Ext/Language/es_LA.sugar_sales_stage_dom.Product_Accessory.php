<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Calificación',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'Propuesta/Presupuesto',
  'Negotiation/Review' => 'Negociación/Revisión',
  'PO' => 'Waiting for Purchase Order',
  'Closed Won' => 'Cerrado',
  'Closed Lost' => 'Perdido',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);