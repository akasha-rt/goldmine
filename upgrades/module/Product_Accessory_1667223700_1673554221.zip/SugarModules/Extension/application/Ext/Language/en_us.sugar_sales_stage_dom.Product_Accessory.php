<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Qualification',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'Proposal/Price Quote',
  'Negotiation/Review' => 'Negotiation/Review',
  'PO' => 'Waiting for Purchase Order',
  'Project on Delay' => 'Still Active On Hold',
  'Closed Won' => 'Closed Won',
  'Closed Lost' => 'Closed Lost',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Legacy' => 'Legacy',
);