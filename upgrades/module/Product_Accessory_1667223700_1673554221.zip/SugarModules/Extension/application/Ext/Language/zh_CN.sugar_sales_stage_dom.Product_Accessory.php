<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => '资格',
  'Proposal/Price Quote' => '建议 / 出价',
  'Negotiation/Review' => '谈判 / 评估',
  'Closed Won' => '谈成结束',
  'Closed Lost' => '丢单结束',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);