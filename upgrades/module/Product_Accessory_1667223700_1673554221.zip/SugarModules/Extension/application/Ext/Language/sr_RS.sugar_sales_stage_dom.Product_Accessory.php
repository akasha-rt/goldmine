<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Kvalifikacija',
  'Proposal/Price Quote' => 'Predlog/Cene ponuda',
  'Negotiation/Review' => 'Pregovori/Pregledi',
  'Closed Won' => 'Zatvoreno',
  'Closed Lost' => 'Završeni izgubljeni',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);