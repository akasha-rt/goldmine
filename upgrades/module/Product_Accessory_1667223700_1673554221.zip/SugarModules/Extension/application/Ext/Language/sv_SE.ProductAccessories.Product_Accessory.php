<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'Befintlig verksamhet',
  'New Business' => 'Ny verksamhet',
  '' => '',
);