<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'Negócio existente',
  'New Business' => 'Novos negócios',
  '' => '',
);