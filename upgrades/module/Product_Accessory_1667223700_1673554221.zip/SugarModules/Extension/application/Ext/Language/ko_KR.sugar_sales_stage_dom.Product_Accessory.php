<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => '선별완료',
  'Proposal/Price Quote' => '제안및견적',
  'Negotiation/Review' => '최종교섭중',
  'Closed Won' => '완료',
  'Closed Lost' => '계약실패',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);