<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Оценка',
  'Proposal/Price Quote' => 'Коммерческое предложение',
  'Negotiation/Review' => 'Согласование КП',
  'Closed Won' => 'Закрытая состоявшаяся продажа',
  'Closed Lost' => 'Закрыто без успеха',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);