<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'Biznes ekzistues',
  'New Business' => 'Biznes i ri',
  '' => '',
);