<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Qualificação',
  'Proposal/Price Quote' => 'Proposta/Cotação de Preço',
  'Negotiation/Review' => 'Negociação/Revisão',
  'Closed Won' => 'Ganha',
  'Closed Lost' => 'Perdida',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);