<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => '기존 비즈니스',
  'New Business' => '새로운 비즈니스',
  '' => '',
);