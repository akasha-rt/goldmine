<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'Postojeće poduzeće',
  'New Business' => 'Novo poduzeće',
  '' => '',
);