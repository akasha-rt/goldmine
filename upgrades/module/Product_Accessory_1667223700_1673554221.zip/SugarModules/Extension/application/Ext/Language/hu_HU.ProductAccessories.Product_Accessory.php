<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'Meglévő üzlet',
  'New Business' => 'Új üzlet',
  '' => '',
);