<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'ธุรกิจที่มีอยู่',
  'New Business' => 'ธุรกิจใหม่',
  '' => '',
);