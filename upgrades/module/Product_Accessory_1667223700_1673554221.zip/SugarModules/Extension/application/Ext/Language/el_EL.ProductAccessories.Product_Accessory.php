<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => 'Υφιστάμενη επιχείρηση',
  'New Business' => 'Νέα επιχείρηση',
  '' => '',
);