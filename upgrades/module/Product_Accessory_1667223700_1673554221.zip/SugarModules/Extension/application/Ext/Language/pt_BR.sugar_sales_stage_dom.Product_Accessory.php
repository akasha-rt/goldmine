<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'Qualificação',
  'Proposal/Price Quote' => 'Proposta/cotação de preço',
  'Negotiation/Review' => 'Negociação/análise',
  'Closed Won' => 'Fechadas ganhas',
  'Closed Lost' => 'Fechada perdida',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);