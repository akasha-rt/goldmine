<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => 'คุณสมบัติ',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => 'ข้อเสนอ/การเสนอราคา',
  'Negotiation/Review' => 'การต่อรอง/การตรวจทาน',
  'PO' => 'Waiting for Purchase Order',
  'Project on Delay' => 'Still Active On Hold',
  'Closed Won' => 'ปิดโดยได้รับการขาย',
  'Closed Lost' => 'ปิดโดยไม่ได้รับการขาย',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Legacy' => 'Legacy',
);