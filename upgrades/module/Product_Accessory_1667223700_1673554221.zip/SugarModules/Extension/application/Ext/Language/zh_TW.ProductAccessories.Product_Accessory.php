<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => '現有企業',
  'New Business' => '新企業',
  '' => '',
);