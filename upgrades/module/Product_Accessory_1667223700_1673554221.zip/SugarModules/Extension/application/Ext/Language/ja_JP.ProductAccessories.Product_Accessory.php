<?php 
$app_list_strings['pa_productaccessories_type_dom'] = array (
  'Existing Business' => '既存ビジネス',
  'New Business' => '新規ビジネス',
  '' => '',
);