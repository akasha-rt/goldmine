<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => '資格',
  'demo' => 'Demonstration',
  'Proposal/Price Quote' => '提案/報價',
  'Negotiation/Review' => '交涉檢閱',
  'PO' => 'Waiting for Purchase Order',
  'Project on Delay' => 'Still Active On Hold',
  'Closed Won' => '結束並贏得客戶',
  'Closed Lost' => '結束但客戶流失',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Legacy' => 'Legacy',
);