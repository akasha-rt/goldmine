<?php 
$app_list_strings['sales_stage_dom'] = array (
  'Qualification' => '見込み',
  'Proposal/Price Quote' => '最終提案/見積中',
  'Negotiation/Review' => '交渉/見直し',
  'Closed Won' => '完了',
  'Closed Lost' => '失注',
  'demo' => 'Demonstration',
  'PO' => 'Waiting for Purchase Order',
  'distribution' => 'Sent to Distribution',
  'DistWon' => 'Distribution Won',
  'DistLost' => 'Distribution Lost',
  'Closed Terminated' => 'Closed Terminated',
  'Project on Delay' => 'Still Active On Hold',
  'Legacy' => 'Legacy',
);