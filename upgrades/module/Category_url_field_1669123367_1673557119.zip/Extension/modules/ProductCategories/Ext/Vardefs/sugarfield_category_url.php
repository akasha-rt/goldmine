<?php
$dictionary['ProductCategory']['fields']['category_url'] = array(
    'name' => 'category_url',
    'label' => 'LBL_CATEGORY_URL',
    'type' => 'url',
    'dbType' => 'varchar' 
);
