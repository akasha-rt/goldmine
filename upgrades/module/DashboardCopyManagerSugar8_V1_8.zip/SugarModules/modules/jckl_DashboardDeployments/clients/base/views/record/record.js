/**
 * Created by shad on 2/16/17.
 */
({
    extendsFrom: 'RecordView',

    initialize: function(options) {
        this._super('initialize', [options]);


        this.on("render", this.updateIcon, this);

        this.context.on('button:restore:click', this.restore_dashboards, this);

    },

    updateIcon: function() {
        $('.label-jckl_DashboardDeployments').css('background-color', '#e0cf05');
    },

    restore_dashboards: function() {
        var deployment_id = this.model.get('id');

        app.alert.show('confirm-restore', {
            level: 'confirmation',
            messages: app.lang.get('LBL_CONFIRM_RESTORE', 'jckl_DashboardDeployments'),
            autoClose: false,
            onConfirm: function(){

                app.alert.show('jckl_DashboardDeployments_restoring', {level: 'process', title: app.lang.get('STATUS_RESTORING_DASHBOARDS', 'jckl_DashboardDeployments'), autoClose: false});

                var payload = {
                        deployment_id : deployment_id
                    },
                    callbacks = {
                        success: function(data,response) {
                            app.alert.dismissAll();
                            if(data.success) {
                                app.alert.dismissAll();
                                app.alert.show('jckl_DashboardDeployment_restore_success', {
                                    level: 'info',
                                    title: app.lang.get('SUCCESS_RESTORE_TITLE', 'jckl_DashboardDeployments'),
                                    messages: '',
                                    autoClose: true
                                });


                            } else {
                                var errorMessages = '';
                                if(data.message) {
                                    errorMessages.push('<br/><br/>');
                                    errorMessages.push(data.message);
                                }
                                app.alert.show('jckl_DashboardDeployment_restore_error', {
                                    level: 'error',
                                    title: app.lang.get('ERR_RESTORE_DASHBOARD_FAILED', 'jckl_DashboardDeployments'),
                                    messages: errorMessages,
                                    autoClose: false
                                });

                                app.logger.error('Failed to restore dashboards. ' + error);
                            }
                        }
                    };
                debugger;

                app.api.call('create', app.api.buildURL('jckl_DashboardDeployments/restore'), payload, callbacks, {});


            },
            onCancel: function(){
                return;
            }
        });

    }

})
