<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$module_name = 'jckl_DashboardDeployments';
$viewdefs[$module_name]['base']['view']['subpanel-list'] = array(
  'panels' => 
  array(
    array(
      'name' => 'panel_header',
      'label' => 'LBL_PANEL_1',
      'fields' =>
          array (
              0 =>
                  array (
                      'name' => 'name',
                      'label' => 'LBL_NAME',
                      'default' => true,
                      'enabled' => true,
                      'link' => true,
                  ),
              1 =>
                  array (
                      'name' => 'assigned_user_name',
                      'label' => 'LBL_ASSIGNED_TO_NAME',
                      'default' => true,
                      'enabled' => true,
                      'link' => true,
                  ),
              2 =>
                  array (
                      'name' => 'date_entered',
                      'enabled' => true,
                      'default' => true,
                  ),
              3 =>
                  array (
                      'name' => 'created_by_name',
                      'enabled' => true,
                      'default' => true,
                  ),

          ),
    ),
  ),
    'orderBy' => array(
        'field' => 'date_entered',
        'direction' => 'desc',
    ),
);
