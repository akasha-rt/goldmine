<?php
$viewdefs['jckl_DashboardDeployments']['base']['view']['selection-list'] = array (
  'panels' => 
  array (
    0 => 
    array (
      'label' => 'LBL_PANEL_DEFAULT',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'name',
          'label' => 'LBL_NAME',
          'default' => true,
          'enabled' => true,
          'link' => true,
          'width' => '32%',
        ),
        1 => 
        array (
          'name' => 'assigned_user_name',
          'label' => 'LBL_ASSIGNED_TO_NAME',
          'default' => true,
          'enabled' => true,
          'link' => true,
          'width' => '9%',
          'id' => 'ASSIGNED_USER_ID',
        ),
        2 => 
        array (
          'name' => 'copied_from_user',
          'default' => true,
          'enabled' => true,
          'type' => 'relate',
          'studio' => 'visible',
          'label' => 'LBL_COPIED_FROM_USER',
          'id' => 'USER_ID_C',
          'link' => true,
          'width' => '10%',
        ),
        3 => 
        array (
          'name' => 'date_entered',
          'enabled' => true,
          'default' => true,
          'type' => 'datetime',
          'label' => 'LBL_DATE_ENTERED',
          'width' => '10%',
        ),
        4 => 
        array (
          'name' => 'date_modified',
          'enabled' => true,
          'default' => true,
          'type' => 'datetime',
          'label' => 'LBL_DATE_MODIFIED',
          'width' => '10%',
        ),
        5 => 
        array (
          'name' => 'description',
          'default' => false,
          'enabled' => true,
          'type' => 'text',
          'label' => 'LBL_DESCRIPTION',
          'sortable' => false,
          'width' => '10%',
        ),
      ),
    ),
  ),
);
