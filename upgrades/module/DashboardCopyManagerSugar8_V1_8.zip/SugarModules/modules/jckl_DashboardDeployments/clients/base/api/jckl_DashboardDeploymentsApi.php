<?php if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 3/10/17
     * Time: 12:22 PM
     * File Name: jckl_DashboardDeploymentsApi.php
     * Project: SugarTest
     */


    require_once('include/api/SugarApi.php');
    require_once('data/BeanFactory.php');
    require_once('modules/jckl_DashboardDeployments/jckl_DashboardDeployments.php');


class jckl_DashboardDeploymentsApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(

            'restoreDashboard' => array(
                'reqType'   => 'POST',
                'path'      => array('jckl_DashboardDeployments','restore'),
                'pathVars'  => array('module', 'path',),
                'method'    => 'restoreDashboard',
                'shortHelp' => 'Receives Deployment ID and restores backup to user',
            ),

        );
    }

    public function restoreDashboard($api, array $args)
    {
        global $db;

        $deployment_id = $args['deployment_id'];
        if (empty($deployment_id)) {
            throw new SugarApiExceptionMissingParameter('ERR_MISSING_PARAMETER_FIELD', $args, 'jckl_DashboardDeployments');
        }

        $deployment = BeanFactory::getBean('jckl_DashboardDeployments', $deployment_id);
        $restore_ids = $deployment->encoded_content;

        $sql = "UPDATE dashboards SET deleted = 1 WHERE assigned_user_id = '$deployment->assigned_user_id' AND id NOT IN ($restore_ids)";
        $db->query($sql); //@TODO Update to new query method

        $sql = "UPDATE dashboards SET deleted = 0 WHERE assigned_user_id = '$deployment->assigned_user_id' AND id IN ($restore_ids)";
        $db->query($sql);//@TODO Update to new query method

        $options = '';
        return array('success' => true, 'options' => $options);
    }


}