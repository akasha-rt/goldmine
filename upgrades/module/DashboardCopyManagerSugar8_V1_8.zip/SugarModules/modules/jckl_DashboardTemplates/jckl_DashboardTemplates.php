<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.

 * SuiteCRM is an extension to SugarCRM Community Edition developed by Salesagility Ltd.
 * Copyright (C) 2011 - 2014 Salesagility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 ********************************************************************************/

/**
 * THIS CLASS IS FOR DEVELOPERS TO MAKE CUSTOMIZATIONS IN
 */
require_once('modules/jckl_DashboardTemplates/jckl_DashboardTemplates_sugar.php');
class jckl_DashboardTemplates extends jckl_DashboardTemplates_sugar {

    public $encoded_pages;
    public $encoded_content;
    public $dashboards_where;

    function __construct(){
        parent::__construct();
    }

    /**
     * Process list of users, roles, or groups
     * @param $users array
     */
    public function deploy($deploy_ids, $category, $template_id, $dashboards_array)
    {

        $users = $this->getUsersArray($deploy_ids, $category);

        $has_users = $this->checkUsers($users, $template_id);

        if ($has_users) {

            $this->setDashboardWhere($dashboards_array);
            $result = $this->deployToUsers($users, $template_id, $dashboards_array);

        } else {

            $result = 0;

        }

        return $result;


    }

    /**
     * Process list of users, roles, or groups
     * @param $users array
     */
    public function append($deploy_ids, $category, $template_id, $location, $age = 'Oldest')
    {

        $users = $this->getUsersArray($deploy_ids, $category);

        $has_users = $this->checkUsers($users, $template_id);

        if ($has_users) {

            $result = $this->appendToUsers($users, $template_id, $location, $age);

        } else {

            $result = 0;

        }

        return $result;


    }

    protected function deployToUsers($users, $template_id, $dashboards_array)
    {
        global $current_user, $db;
        $template = new jckl_DashboardTemplates();
        $template->retrieve($template_id);

        $target_user = $template->assigned_user_id;


        $sql = "SELECT * FROM dashboards 
                    WHERE assigned_user_id = '$target_user' 
                    $this->dashboards_where
                    AND deleted = 0";
        $results = $db->query($sql); //TODO Update to new query method

        $dashboards = array();

        while ($row = $db->fetchByAssoc($results)) {
            //Loop through selected dashboard items.
            foreach ($dashboards_array as $item) {

                switch ($item) {
                    case 'Home':

                        if ($row['dashboard_module'] == 'Home') {
                            $dashboards[] = $row;

                        }
                        break;
                    case 'Record':
                        if ($row['view_name'] == 'record') {
                            $dashboards[] = $row;
                        }
                        break;
                    case 'List':
                        if ($row['view_name'] == 'records') {
                            $dashboards[] = $row;
                        }
                }

            }

        }

        /**
         * Backup current dashboards for restore
         */
        $this->backupUsersDashboard($users, $template);

        $i = 0;

        foreach ($users as $user_id) {

            $user = new User();
            $user->retrieve($user_id);

            $dashboard_ids = array();

            foreach ($dashboards as $dashboard) {

                $new_dashboard = BeanFactory::newBean('Dashboards');
                $new_dashboard->name = $dashboard['name'];
                $new_dashboard->modified_user_id = $user_id;
                $new_dashboard->created_by = $user_id;
                $new_dashboard->assigned_user_id = $user_id;
                $new_dashboard->description = $dashboard['description'];
                $new_dashboard->dashboard_module = $dashboard['dashboard_module'];
                $new_dashboard->view_name = $dashboard['view_name'];

                if (strpos($dashboard['metadata'],'filter_id')) {
                    $new_dashboard->metadata = $this->checkFilter($dashboard, $user_id);
                } else {
                    $new_dashboard->metadata = $dashboard['metadata'];
                }
                $new_dashboard->dashboard_type = $dashboard['dashboard_type'];
                $new_dashboard->save();


                $dashboard_ids[] = "'" . $new_dashboard->id . "'";

            }


            $ids_where = implode(",",$dashboard_ids);
            $sql = "UPDATE dashboards SET assigned_user_id = '$user_id' 
                            WHERE id IN ($ids_where)";
            $db->query($sql); //@TODO Update to new query method

            $sql = "UPDATE dashboards SET deleted = 1 
                            WHERE assigned_user_id = '$user_id' 
                            AND id NOT IN ($ids_where)
                            $this->dashboards_where";
            $db->query($sql); //@TODO Update to new query method

            require_once('modules/jckl_DashboardDeployments/jckl_DashboardDeployments.php');

            $deployment = new jckl_DashboardDeployments();
            $deployment->name = $template->name . ' Template - ' . $user->first_name . ' ' . $user->last_name;
            $deployment->assigned_user_id = $user->id;
            $deployment->encoded_content = $ids_where;
            $deployment->user_id_c = $current_user->id;
            $deployment->save();

            $relationship = 'jckl_dashboarddeployments_jckl_dashboardtemplates';
            $deployment->load_relationship($relationship);
            $deployment->$relationship->add($template->id);
            $deployment->save();
            $i++;
        }

        return $i;

    }

    /********************************************************
     *
     *  Check for and replace filter id for user. Duplicates if the
     *  filter does not exist
     *
     ********************************************************/
    protected function checkFilter($dashboard, $user_id)
    {
        $meta_array = json_decode($dashboard['metadata'],true);

        foreach($meta_array['components'] as $component_key => $component) {

            foreach($component['rows'] as $row_key => $row) {

                foreach($row as $view_key => $view) {
                    $filter_id = $view['view']['filter_id'];
                    if (!empty($filter_id)) {
                        // Check for uuid on filter
                        if (strlen($filter_id) == 36) {
                            //check and copy filter to user
                            $replace_id = $this->duplicateFilterIfNotExists($filter_id, $user_id);

                            $meta_array['components'][$component_key]['rows'][$row_key][$view_key]['view']['filter_id'] = $replace_id;

                        }
                    }
                }
            }
        }

        return json_encode($meta_array);
    }


    /**
     * Search for exiting filter for user and create if not found
     * Returns id of either existing or created filter.
     * @param $filter_id
     * @param $user_id
     * @return array|string
     */
    protected function duplicateFilterIfNotExists($filter_id, $user_id)
    {

        global $db;
        $filter_user = BeanFactory::retrieveBean('Users', $user_id);
        $return_id = '';
        $filter = BeanFactory::getBean('Filters', $filter_id);

        $sql = "SELECT id 
                        FROM filters 
                        WHERE filter_definition = '$filter->filter_definition'
                        AND filter_template = '$filter->filter_template'
                        AND created_by = '$user_id'
                        AND module_name = '$filter->module_name'
                        
                        AND deleted = 0
                        LIMIT 1";

        $existing_id = $this->db->getOne($sql);

        if ($existing_id) {
            $return_id = $existing_id;
        } else {
            $new_filter = BeanFactory::newBean('Filters');
            $new_filter->name = $filter->name;
            $new_filter->set_created_by = false;
            $new_filter->created_by = $user_id;
            $new_filter->filter_definition = $filter->filter_definition;
            $new_filter->filter_template = $filter->filter_template;
            $new_filter->module_name = $filter->module_name;
            $new_filter->team_id = '1';
            $new_filter->team_set_id = '1';
            $new_filter->save();
            $return_id = $new_filter->id;
        }

        return $return_id;
    }

    /**
     * Backup each user dashboard before deploying
     * @param $users
     * @param $template
     */
    protected function backupUsersDashboard($users, $template)
    {

        global $current_user, $db;

        foreach ($users as $user_id) {

            require_once('modules/Users/User.php');

            //Load User bean
            $user = new User();
            $user->retrieve($user_id);

            $sql = "SELECT id FROM dashboards WHERE assigned_user_id = '$user_id' AND deleted = 0";
            $results = $db->query($sql); //@TODO Update to new query method

            $backup_dashboards = array();

            while ($row = $db->fetchByAssoc($results)) {
                $backup_dashboards[] = "'" . $row['id'] . "'";
            }

            if (count($backup_dashboards) > 0) {

                $backup_ids = implode(",", $backup_dashboards);

                require_once('modules/jckl_DashboardDeployments/jckl_DashboardDeployments.php');

                $deployment = new jckl_DashboardDeployments();
                $deployment->name = 'Backup: ' . $template->name . ' - ' . $user->user_name;
                $deployment->assigned_user_id = $user->id;

                $deployment->encoded_content = $backup_ids;
                $deployment->user_id_c = $user->id;
                $deployment->save();

                $relationship = 'jckl_dashboarddeployments_jckl_dashboardtemplates';
                $deployment->load_relationship($relationship);
                $deployment->$relationship->add($template->id);
                $deployment->save();
            }

        }


    }

    protected function saveDeployment($user, $template)
    {

        global $current_user;
        require_once('modules/jckl_DashboardDeployments/jckl_DashboardDeployments.php');

        $deployment = new jckl_DashboardDeployments();
        $deployment->name = $template->name . ' - ' . $user->user_name;
        $deployment->assigned_user_id = $user->id;
        $deployment->encoded_pages = $template->encoded_pages;
        $deployment->encoded_content = $template->encoded_content;
        $deployment->user_id_c = $current_user->id;
        $deployment->save();

        $relationship = 'jckl_dashboarddeployments_jckl_dashboardtemplates';
        $deployment->load_relationship($relationship);
        $deployment->$relationship->add($template->id);
        $deployment->save();

    }

    /**
     * Check if there are any users selected
     * @param $users
     */
    protected function checkUsers($users)
    {
        $count = count($users);

        $valid = false;

        if ($count > 0) {
            $valid = true;
        }

        return $valid;

    }


    /**
     * Return array of users depending on whether we
     * are deploying to users, roles, or groups
     * @param $deploy_ids
     * @return array
     */
    protected function getUsersArray($deploy_ids, $category)
    {


        $users = array();

        if ($category == 'roles' ) {

            $users = $this->getUsersFromRoles($deploy_ids);

        } elseif($category == 'teams') {

            $users = $this->getUsersFromTeams($deploy_ids);

        }

        else {

            $users = $deploy_ids;

        }


        return $users;

    }


    /**
     * Query to get array of users if deploying to groups
     * @param $deploy_ids
     * @return array
     */
    protected function getUsersFromTeams($deploy_ids)
    {
        global $db;
        require_once('modules/Teams/Team.php');

        $team_obj = new Team();
        $users = array();

        foreach ($deploy_ids as $deploy_id) {
            $team_obj->retrieve($deploy_id);
            $team_members = $team_obj->get_team_members(true);
            foreach ($team_members as $team_member) {
                $users[] = $team_member->id;
            }

        }

        $users = array_unique($users);

        return $users;

    }

    /**
     * Query to get array of users if deploying to roles
     * @param $deploy_ids
     * @return array
     */
    protected function getUsersFromRoles($deploy_ids)
    {

        global $db;

        $deploy_array = array();
        foreach ($deploy_ids as $deploy_id) {
            $deploy_array[] = "'" . $deploy_id . "'";
        }

        $in_string = implode(',', $deploy_array);

        $sql = "SELECT aru.user_id 
                    FROM acl_roles_users aru
                    LEFT JOIN users u ON aru.user_id = u.id 
                    WHERE aru.role_id IN ($in_string)
                    AND aru.deleted = 0
                    AND u.deleted = 0
                    GROUP BY aru.user_id";

        $GLOBALS['log']->fatal("jckl_DashboardTemplates::getUsersFromRoles Query: $sql");

        $results = $db->query($sql); //@TODO Update to new query method

        $users = array();

        while ($row = $db->fetchByAssoc($results)) {

            $users[] = $row['user_id'];

        }

        return $users;

    }


    protected function setDashboardWhere($dashboards)
    {

        $where = " AND (";
        if (in_array('Home',$dashboards) ) {

            $where .= " dashboard_module = 'Home' ";

        }

        if (in_array('Record',$dashboards) ) {

            if (in_array('Home',$dashboards) ) {

                $where .= " OR view_name = 'record' ";

            } else {

                $where .= " view_name = 'record' ";
            }


        }

        if (in_array('List',$dashboards) ) {

            if (in_array('Record',$dashboards) ) {

                $where .= " OR view_name = 'records' ";

            } else {

                $where .= " view_name = 'records' ";
            }


        }

        $where .= ' )';

        $this->dashboards_where = $where;

    }

    /********************************************************
     *
     *  Append selected dashboard
     *
     ********************************************************/

    protected function appendToUsers($users, $template_id, $dashboard_location, $age)
    {
        global $db;
        $append_template = BeanFactory::getBean('jckl_DashboardAppend', $template_id);
        $metadata = json_decode($append_template->dashboard_contents);
        $data = json_decode($metadata->data);
        $module = $metadata->module;
        $type = $metadata->dashboard_type;
        $view_name = $metadata->view_name;

        if ($age == 'Oldest') {
            $order_by = 'ASC';
        } else {
            $order_by = 'DESC';
        }

        $i = 0;
        foreach ($users as $user) {

            $query = new SugarQuery();
            $query->from(BeanFactory::newBean('Dashboards'),array('team_security' => false));
            $query->select('id');
            $query->where()
                ->equals('assigned_user_id', $user)
                ->equals('dashboard_module', $module)

                ->equals('dashboard_type', $type);
            if ($view_name) {
                $query->where()
                    ->equals('view_name', $view_name);
            }
            $query->orderBy('date_entered', $order_by);
            $query->limit(1);

            $user_dashboard_id = $query->getOne();

            if ($user_dashboard_id) {

                $user_dashboard = BeanFactory::getBean('Dashboards', $user_dashboard_id);
                $parent_metadata = json_decode($user_dashboard->metadata);

                $new_meta = $this->appendMetadata($parent_metadata, $data, $dashboard_location);

                $user_dashboard->metadata = json_encode($new_meta);
                $user_dashboard->save();
                $sql = "UPDATE dashboards SET assigned_user_id = '$user' WHERE id = '$user_dashboard->id'";
                $db->query($sql);
                $i++;

            }


        }


        return $i;
    }


    protected function appendMetadata($parent_metadata, $insert_meta, $location)
    {

        $insert_meta = array(0 => $insert_meta);
        $column = $parent_metadata->components[0];

        if (strpos($location, 'Bottom')) {

            $column->rows[] = $insert_meta;

        } else {

            array_unshift($column->rows, $insert_meta);
        }

        $parent_metadata->components[0] = $column;

        return $parent_metadata;


    }




}
?>