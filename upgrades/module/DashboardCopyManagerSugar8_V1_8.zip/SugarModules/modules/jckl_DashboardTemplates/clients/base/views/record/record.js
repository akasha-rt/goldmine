/**
 * Created by shad on 2/16/17.
 */
({
    extendsFrom: 'RecordView',

    initialize: function(options) {
        this._super('initialize', [options]);

        this.on("render", this.updateIcon, this);

        this.context.on('button:deploy:click', this.deploy_tempate, this);

    },

    updateIcon: function() {
        $('.label-jckl_DashboardDeployments').css('background-color', '#e0cf05');
        $('.label-jckl_DashboardTemplates').css('background-color', '#e0a705');
    },


    deploy_tempate: function() {
        console.log(this.model.get('id'));
        app.user.set('jckl_template', this.model.get('id'));
        app.router.navigate('#jckl_DashboardTemplates/layout/deploy', {trigger: true});
    }

})
