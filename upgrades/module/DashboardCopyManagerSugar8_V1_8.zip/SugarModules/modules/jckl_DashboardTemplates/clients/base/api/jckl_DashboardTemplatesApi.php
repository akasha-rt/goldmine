<?php if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    require_once('include/api/SugarApi.php');
require_once('data/BeanFactory.php');
require_once('modules/jckl_DashboardTemplates/jckl_DashboardTemplates.php');
require_once('modules/jckl_DashboardTemplates/DeploymentUtilities.php');

class jckl_DashboardTemplatesApi extends SugarApi
{
    public function registerApiRest()
    {
        return array(
            'getCategoryData' => array(
                'reqType' => 'GET',
                'path' => array('jckl_DashboardTemplates', 'getCategoryData', '?'),
                'pathVars' => array('', '', 'category'),
                'method' => 'getCategoryData',
                'shortHelp' => 'Retrieves List of Users, Roles, Or Teams based on selection',
            ),
            'deployTemplate' => array(
                'reqType'   => 'POST',
                'path'      => array('jckl_DashboardTemplates','deployTemplate'),
                'pathVars'  => array('module', 'path',),
                'method'    => 'deployTemplate',
                'shortHelp' => 'Receives Template ID, Category, And Deploy IDs and copies Templates to proper users',
            ),

        );
    }
    
    public function getCategoryData($api, array $args)
    {
        $category = $args['category'];
        if (empty($args['category'])) {
            throw new SugarApiExceptionMissingParameter('ERR_MISSING_PARAMETER_FIELD', array('category'), 'jckl_DashboardTemplates');
        }

        $template = new jckl_DashboardTemplatesDeploymentUtilities();
        $options = $template->getDeployType($category);

        return array('success' => true, 'options' => $options);
    }
    
    public function deployTemplate($api, array $args)
    {
//        if (empty($args['apikey'])) {
//            throw new SugarApiExceptionMissingParameter('ERR_MISSING_PARAMETER_FIELD', array('apikey'), 'AddonBoilerplate');
//        }

        global $current_user, $sugar_config;
        require_once('modules/jckl_DashboardTemplates/license/OutfittersLicense.php');
        $validate_license = OutfittersLicense::isValid('jckl_DashboardTemplates');
        if($validate_license !== true) {

            $url = $sugar_config['site_url'] .'/#bwc/index.php?module=jckl_DashboardTemplates&action=license';
            throw new SugarApiExceptionMissingParameter('ERR_LICENSE_EXPIRED', '', 'jckl_DashboardTemplates', 0, $url );
            return false;
        }
        $deployer = new jckl_DashboardTemplates();

        $users = $deployer->deploy($args['deploy_records'], $args['category'], $args['template_id'], $args['deploy_dashboards']);

        return array('success' => true, 'count' => $users);
        


    }


}