<?php
/**
 * Created using PhpStorm.
 * User: shad
 * Date: 2/17/17
 * Time: 9:30 PM
 * File Name: header.php
 * Project: SugarTest
 */


$moduleName = 'jckl_DashboardTemplates';
$viewdefs[$moduleName]['base']['menu']['header'] = array(

    array(
        'label' =>'LNK_NEW_RECORD',
        'acl_action'=>'create',
        'acl_module'=>$moduleName,
        'icon' => 'fa-plus',
        'route'=>'#'.$moduleName.'/create',
    ),
    array(
        'route'=>'#'.$moduleName,
        'label' =>'LNK_LIST',
        'acl_action'=>'list',
        'acl_module'=>$moduleName,
        'icon' => 'fa-bars',
    ),
);