<?php
$viewdefs['jckl_DashboardTemplates']['base']['view']['selection-list'] = array (
  'panels' => 
  array (
    0 => 
    array (
      'label' => 'LBL_PANEL_DEFAULT',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'name',
          'label' => 'LBL_NAME',
          'default' => true,
          'enabled' => true,
          'link' => true,
          'width' => '32%',
        ),
        1 => 
        array (
          'name' => 'assigned_user_name',
          'label' => 'LBL_ASSIGNED_TO_NAME',
          'default' => true,
          'enabled' => true,
          'link' => true,
          'width' => '9%',
          'id' => 'ASSIGNED_USER_ID',
        ),
        2 => 
        array (
          'name' => 'date_entered',
          'enabled' => true,
          'default' => true,
          'type' => 'datetime',
          'label' => 'LBL_DATE_ENTERED',
          'width' => '10%',
        ),
        3 => 
        array (
          'name' => 'data_last_refreshed',
          'default' => true,
          'enabled' => true,
          'type' => 'datetimecombo',
          'label' => 'LBL_DATA_LAST_REFRESHED',
          'width' => '10%',
        ),
        4 => 
        array (
          'name' => 'modified_by_name',
          'default' => false,
          'enabled' => true,
          'type' => 'relate',
          'link' => true,
          'label' => 'LBL_MODIFIED_NAME',
          'id' => 'MODIFIED_USER_ID',
          'width' => '10%',
        ),
        5 => 
        array (
          'name' => 'created_by_name',
          'default' => false,
          'enabled' => true,
          'type' => 'relate',
          'link' => true,
          'label' => 'LBL_CREATED',
          'id' => 'CREATED_BY',
          'width' => '10%',
        ),
      ),
    ),
  ),
);
