<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 2/17/17
     * Time: 3:20 PM
     * File Name: deploy.php
     * Project: Dashboard Manager
     */

    $viewdefs['jckl_DashboardTemplates']['base']['layout']['deploy'] = array(
    'type' => 'simple',
    'components' =>
    array(
        array(
            'view' => 'deploy',
        ),
    ),
);