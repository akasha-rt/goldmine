<?php
/*********************************************************************************
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.

 * SuiteCRM is an extension to SugarCRM Community Edition developed by Salesagility Ltd.
 * Copyright (C) 2011 - 2014 Salesagility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for  technical reasons, the Appropriate Legal Notices must
 * display the words  "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 ********************************************************************************/

$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Copied From User',
  'LBL_ASSIGNED_TO' => 'Copy From User',
  'LBL_SECURITYGROUPS' => 'Security Groups',
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Security Groups',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_LIST_FORM_TITLE' => 'Dashboard Templates List',
  'LBL_MODULE_NAME' => 'Dashboard Templates',
  'LBL_MODULE_TITLE' => 'Dashboard Templates',
  'LBL_HOMEPAGE_TITLE' => 'My Dashboard Templates',
  'LNK_NEW_RECORD' => 'Create Dashboard Templates',
  'LNK_LIST' => 'View Dashboard Templates',
  'LNK_IMPORT_JCKL_DASHBOARDTEMPLATES' => 'Import Dashboard Templates',
  'LBL_SEARCH_FORM_TITLE' => 'Search Dashboard Templates',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_JCKL_DASHBOARDTEMPLATES_SUBPANEL_TITLE' => 'Dashboard Templates',
  'LBL_NEW_FORM_TITLE' => 'New Dashboard Templates',
  'LBL_ENCODED_PAGES' => 'Encoded Pages',
  'LBL_ENCODED_CONTENT' => 'Encoded Content',
  'LBL_DATA_LAST_REFRESHED' => 'Data Last Refreshed',
  'LBL_DEPLOY_DASHBOARD' => 'Deploy Template',
  'LBL_SELECT_DEPLOY_TO_LIST' => 'Select if you want to deploy to users, roles, or groups',
  'LBL_STEP_SUBMIT' => 'Continue',
  'LBL_STEP_COMMIT' => 'Deploy Template To Selected',
  'LBL_SELECT_ALL_BUTTON' => 'Select All',
  'LBL_OPTION_TYPE_ROLES' => 'Select Role(s)',
  'LBL_OPTION_TYPE_USERS' => 'Select User(s)',
  'LBL_OPTION_TYPE_GROUPS' => 'Select Security Group(s)',
  'LBL_DEPLOY_ONLY_WITH_USERS' => 'Only records with users associated with them are shown',
  'LBL_NONE_SELECTED' => 'Please select at least one record',
  'LBL_DEPLOY_TEMPLATE_BUTTON' => 'Deploy Template',
  'LBL_SELECT_CATEGORY' => 'Select Category To Deploy To',
  'LBL_SELECT_FROM_LIST' => 'Select Deployment Objects',
  'LBL_USERS_OPTION' => 'User(s)',
  'LBL_ROLES_OPTION' => 'Role(s)',
  'LBL_TEAMS_OPTION' => 'Team(s)',
  'LBL_CONTINUE' => 'Continue',
  'LBL_PROCESSING_REQUEST' => 'Processing...',
  'ERR_NO_CATEGORY_TITLE' => 'Select Category',
  'ERR_NO_CATEGORY_MESSAGE' => 'Please Select a Category',
  'LNK_DEPLOY' => 'Deploy Current Template',
  'ERR_CATEGORY_RETRIEVE' => 'Could not retrieve the category you selected',
  'ERR_RETRIEVE_FAILED' => 'Error Retrieving Data',
  'SUCCESS_CATEGORY_RETRIEVE_TITLE' => 'Success: ',
  'SUCCESS_SELECT_RECORDS' => 'Please Select Records To Deploy Template',
  'STATUS_RETRIEVING_OPTIONS' => 'Retrieving Options For Selection',
  'ERR_DATA_MISSING_TITLE' => 'Sorry Data Missing',
  'ERR_DATA_MISSING_MESSAGE'=> 'Missing Data For Deployment. Please begin again.',
  'SUCCESS_DEPLOY_TITLE' => 'Deployment Successful',
  'SUCCESS_DEPLOY_RECORDS' => 'Number Of Users Dashboard Deployed To: ',
  'LBL_SELECT_DASHBOARDS' => 'Select Dashboards to deploy',
  'ERR_LICENSE_EXPIRED' => 'License for this add-on has expired. Go to admin to configure and update license',
  'STATUS_DEPLOYING_DASHBOARDS' => 'Deploying Selected Dashboards... Please Wait',
  'ERR_TRY_AGAIN' => 'Please try again.',
  'ERR_LOGIN_TEST_TITLE' => 'Could not authenticate with remote API',
  'ERR_LOGIN_TEST' => 'Please check your login credentials and try again.',
  'ERR_NO_APIKEY_TITLE' => 'An Invalid API Key  Was Entered',
  'ERR_NO_APIKEY' => 'Please re-enter a key and try again.',
  'ERR_LICENSE_CONNECTION' => 'Cannot connect to the License Server',
);