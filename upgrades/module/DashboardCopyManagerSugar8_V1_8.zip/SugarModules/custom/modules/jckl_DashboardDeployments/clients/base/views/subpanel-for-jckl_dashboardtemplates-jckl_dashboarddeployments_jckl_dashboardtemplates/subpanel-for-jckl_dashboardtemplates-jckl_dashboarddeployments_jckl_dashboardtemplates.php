<?php
    /**
     * Created using PhpStorm.
     * User: shad
     * Date: 3/17/17
     * Time: 10:05 AM
     * File Name: subpanel-for-jckl_dashboardtemplates-jckl_dashboarddeployments_jckl_dashboardtemplates.php
     * Project: SugarDashboard
     */

    $viewdefs['jckl_DashboardDeployments']['base']['view']['subpanel-for-jckl_dashboardtemplates-jckl_dashboarddeployments_jckl_dashboardtemplates'] = array (
        'panels' =>
            array (
                0 =>
                    array (
                        'name' => 'panel_header',
                        'label' => 'LBL_PANEL_1',
                        'fields' =>
                            array (
                                0 =>
                                    array (
                                        'name' => 'name',
                                        'label' => 'LBL_NAME',
                                        'default' => true,
                                        'enabled' => true,
                                        'link' => true,
                                    ),
                                1 =>
                                    array (
                                        'name' => 'assigned_user_name',
                                        'label' => 'LBL_ASSIGNED_TO_NAME',
                                        'default' => true,
                                        'enabled' => true,
                                        'link' => true,
                                    ),
                                2 =>
                                    array (
                                        'name' => 'date_entered',
                                        'enabled' => true,
                                        'default' => true,
                                    ),
                                3 =>
                                    array (
                                        'name' => 'created_by_name',
                                        'enabled' => true,
                                        'default' => true,
                                    ),
                            ),
                    ),
            ),
        'orderBy' =>
            array (
                'field' => 'date_entered',
                'direction' => 'desc',
            ),
        'type' => 'subpanel-list',
    );