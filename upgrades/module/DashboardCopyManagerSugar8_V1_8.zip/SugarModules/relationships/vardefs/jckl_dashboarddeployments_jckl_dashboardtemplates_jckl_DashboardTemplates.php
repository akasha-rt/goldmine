<?php
// created: 2016-09-03 05:37:17
$dictionary["jckl_DashboardTemplates"]["fields"]["jckl_dashboarddeployments_jckl_dashboardtemplates"] = array (
  'name' => 'jckl_dashboarddeployments_jckl_dashboardtemplates',
  'type' => 'link',
  'relationship' => 'jckl_dashboarddeployments_jckl_dashboardtemplates',
  'source' => 'non-db',
  'module' => 'jckl_DashboardDeployments',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_JCKL_DASHBOARDDEPLOYMENTS_JCKL_DASHBOARDTEMPLATES_FROM_JCKL_DASHBOARDDEPLOYMENTS_TITLE',
);
