<?php
// created: 2017-03-16 11:43:21
$viewdefs['jckl_DashboardTemplates']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_JCKL_DASHBOARDTEMPLATES_JCKL_DASHBOARDDEPLOYMENTS_FROM_JCKL_DASHBOARDDEPLOYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'jckl_dashboardtemplates_jckl_dashboarddeployments',
  ),
);