<?php
// created: 2017-03-16 12:03:25
$viewdefs['jckl_DashboardTemplates']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_JCKL_DASHBOARDDEPLOYMENTS_JCKL_DASHBOARDTEMPLATES_FROM_JCKL_DASHBOARDDEPLOYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'jckl_dashboarddeployments_jckl_dashboardtemplates',
  ),
);