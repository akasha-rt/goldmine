<?php
// created: 2017-03-16 11:43:20
$viewdefs['jckl_DashboardTemplates']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_JCKL_DASHBOARDTEMPLATES_JCKL_DASHBOARDDEPLOYMENTS_FROM_JCKL_DASHBOARDDEPLOYMENTS_TITLE',
  'context' => 
  array (
    'link' => 'jckl_dashboardtemplates_jckl_dashboarddeployments',
  ),
);