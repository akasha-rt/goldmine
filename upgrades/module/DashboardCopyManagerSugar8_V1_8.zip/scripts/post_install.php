<?php
if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');

//At bottom of post_install - redirect to license validation page - CHANGE NAME BELOW - To your module name

function post_install() {

    global $sugar_version;


    /**
     * Repair and rebuild
     *
     */

    $autoexecute = true; //execute the SQL
    $show_output = true; //output to the screen
    require_once("modules/Administration/QuickRepairAndRebuild.php");
    $randc = new RepairAndClear();
    $randc->repairAndClearAll(array('clearAll'),array(translate('LBL_ALL_MODULES')), $autoexecute,$show_output);


    global $sugar_config;

    $url = $sugar_config['site_url'];

    $url .= '/#bwc/index.php?module=jckl_DashboardTemplates&action=license';


    echo "
            <script>
            var app = window.parent.SUGAR.App;
            app.alert.show('install_success', {
                            level: 'success',
                            title: 'Successfully Installed Add-On',
                            messages: '<a href=\"#bwc/index.php?module=jckl_DashboardTemplates&action=license\">Go To License Admin</a>',
                            autoClose: false
                        });
//            window.parent.SUGAR.App.sync({callback: function(){
//                app.router.navigate('#bwc/index.php?module=jckl_DashboardTemplates&action=license', {trigger:true});
//            }});
            </script>"
    ;
}
