<?php
    global $sugar_version, $sugar_config;
    if(preg_match( "/^6.*/", $sugar_version) ) {
        $url = 'index.php?module=jckl_DashboardTemplates&action=index';
    } else {
        $url = 'jckl_DashboardTemplates';
    }
    $outfitters_config = array(
        'name' => 'jckl_dashboard00103', //The matches the id value in your manifest file. This allow the library to lookup addon version from upgrade_history, so you can see what version of addon your customers are using
        'shortname' => 'dashboard-deployer',
        'public_key' => '5a8b12a9f4fb9bb5bb741475a400e496,83b746d292bae210c9f17fcb448bc091,549313682a6f7f95c7b7b85eaa6c3151',
        'api_url' => 'https://www.sugaroutfitters.com/api/v1',
        'validate_users' => false,
        'manage_licensed_users' => false,
        'validation_frequency' => 'weekly',
        'continue_url' => $url,
    );

