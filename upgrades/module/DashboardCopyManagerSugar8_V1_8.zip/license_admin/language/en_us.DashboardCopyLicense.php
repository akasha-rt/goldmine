<?php

$mod_strings['LBL_JCKL_DASHBOARD_LICENSEADDON'] = 'Dashboard Copy License';
$mod_strings['LBL_JCKL_DASHBOARD_LICENSEADDON_LICENSE_TITLE'] = 'Dashboard Copy License Configuration';
$mod_strings['LBL_JCKL_DASHBOARD_LICENSEADDON_LICENSE'] = 'Manage and configure the license for this add-on';
$mod_strings['LBL_JACKAL_DASHBOARD_MANAGER_GROUP_TITLE'] = 'Jackal Software Plugins';
$mod_strings['LBL_JACKAL_DASHBOARD_MANAGER_GROUP_DESCRIPTION'] = 'Configure Jackal Software Plugins';
$mod_strings['LBL_JACKAL_DASHBOARDCOPY_TITLE'] = 'Dashboard Copy Manager for SugarCRM7';
$mod_strings['LBL_JACKAL_DASHBOARDCOPY_DESCRIPTION'] = 'Copy user dashboards to other users';
