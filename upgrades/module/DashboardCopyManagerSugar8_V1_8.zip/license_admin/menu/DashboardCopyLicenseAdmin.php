<?php

    global $sugar_version;

    $admin_options_defs=array();

    $admin_options_defs['Administration']['jackal_DashboardManager_license']= array('helpInline',
        'LBL_JCKL_DASHBOARD_LICENSEADDON_LICENSE_TITLE',
        'LBL_JCKL_DASHBOARD_LICENSEADDON_LICENSE',
        'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=jckl_DashboardTemplates&action=license", {trigger: true});');

    $admin_options_defs['Administration']['jackal_DashboardManager_Access']=array(
        'Administration',
        'LBL_JACKAL_DASHBOARDCOPY_TITLE',
        'LBL_JACKAL_DASHBOARDCOPY_DESCRIPTION',
        'javascript:parent.SUGAR.App.router.navigate("#jckl_DashboardTemplates", {trigger: true});'
    );

    $admin_group_header[]=array(
        'LBL_JACKAL_DASHBOARD_MANAGER_GROUP_TITLE',
        '',
        'false',
        $admin_options_defs,
        'LBL_JACKAL_DASHBOARD_MANAGER_GROUP_DESCRIPTION',
    );