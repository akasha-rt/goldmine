<?php

    $mod_strings['LBL_PRUNESUGARBPMHISTORY'] = 'Prune SugarBPM History';
