<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\147\x61\x72\x45\156\x74\x72\171") || !sugarEntry)) { goto DyBw2; } die("\116\157\x74\x20\x41\x20\x56\141\154\x69\x64\x20\105\156\x74\162\171\40\120\157\151\156\164"); DyBw2: $module_name = "\x45\63\x38\137\115\x65\x72\147\x65\x64\104\165\x70\154\151\x63\x61\x74\x65\163"; $viewdefs[$module_name]["\155\x6f\x62\151\x6c\x65"]["\166\x69\x65\x77"]["\x6c\x69\163\164"] = array("\160\141\156\145\x6c\163" => array(array("\x6c\141\142\x65\154" => "\x4c\102\114\137\120\101\x4e\105\114\x5f\x44\x45\x46\x41\125\114\x54", "\x66\x69\145\154\x64\163" => array(array("\156\x61\155\145" => "\x6e\x61\155\145", "\x6c\x61\142\145\x6c" => "\x4c\x42\x4c\x5f\116\x41\x4d\x45", "\x64\x65\146\141\x75\x6c\164" => true, "\x65\x6e\x61\142\x6c\x65\144" => true, "\154\x69\x6e\153" => true), array("\156\x61\155\145" => "\x74\145\x61\155\x5f\156\x61\155\x65", "\154\x61\x62\x65\154" => "\x4c\102\114\137\124\105\x41\x4d", "\x64\x65\146\141\165\x6c\164" => true, "\145\x6e\x61\x62\154\x65\x64" => true), array("\x6e\x61\x6d\145" => "\x61\x73\163\x69\147\156\x65\144\137\165\163\x65\162\137\156\x61\x6d\145", "\154\x61\x62\145\154" => "\x4c\102\114\x5f\x41\x53\x53\x49\107\x4e\105\x44\137\124\117\137\116\101\x4d\x45", "\x64\145\x66\141\x75\x6c\164" => true, "\145\156\141\x62\x6c\145\x64" => true, "\x6c\151\156\x6b" => true)))));
