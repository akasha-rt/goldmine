<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\x38\x5f\115\x65\x72\147\x65\144\104\x75\x70\154\x69\x63\x61\164\x65\x73"; $viewdefs[$module_name]["\x6d\157\x62\x69\154\x65"]["\x76\151\145\167"]["\x65\144\151\x74"] = array("\164\145\x6d\x70\x6c\x61\164\145\115\x65\164\141" => array("\155\141\170\x43\x6f\x6c\x75\155\156\163" => "\61", "\x77\x69\144\164\150\x73" => array(array("\x6c\x61\x62\x65\154" => "\61\x30", "\146\151\145\154\x64" => "\x33\x30"), array("\x6c\x61\142\145\x6c" => "\x31\x30", "\x66\151\x65\x6c\144" => "\63\60"))), "\160\x61\156\x65\154\163" => array(array("\x6c\x61\x62\145\x6c" => "\x4c\x42\x4c\x5f\x50\101\x4e\x45\114\x5f\104\105\106\x41\x55\114\124", "\146\151\x65\154\144\163" => array("\x6e\141\155\145", "\141\x73\163\151\x67\x6e\145\x64\x5f\165\163\x65\x72\137\156\x61\x6d\x65", "\x74\145\x61\x6d\137\156\x61\155\145"))));
