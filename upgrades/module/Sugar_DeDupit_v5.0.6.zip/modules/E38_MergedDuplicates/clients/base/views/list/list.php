<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\x75\147\141\162\105\x6e\164\162\x79") || !sugarEntry)) { goto qWIjB; } die("\116\x6f\x74\40\x41\x20\x56\x61\x6c\x69\144\40\105\x6e\x74\162\171\x20\120\x6f\151\156\164"); qWIjB: $module_name = "\105\x33\x38\137\115\145\162\147\x65\144\x44\x75\x70\154\x69\x63\141\164\145\163"; $viewdefs[$module_name]["\142\x61\x73\x65"]["\x76\151\x65\x77"]["\x6c\151\x73\x74"] = array("\x70\141\156\145\x6c\x73" => array(array("\154\x61\142\145\154" => "\114\x42\114\137\120\x41\116\x45\x4c\137\x31", "\x66\151\145\x6c\x64\163" => array(array("\x6e\141\x6d\x65" => "\x6e\141\x6d\145", "\154\141\142\x65\x6c" => "\114\x42\114\137\116\x41\x4d\105", "\144\x65\x66\x61\165\x6c\164" => true, "\x65\x6e\x61\x62\x6c\x65\144" => true, "\x6c\x69\x6e\153" => true), array("\x6e\x61\x6d\145" => "\164\x65\x61\155\137\x6e\x61\x6d\145", "\x6c\141\x62\145\x6c" => "\114\x42\114\137\x54\105\x41\115", "\144\145\146\141\x75\x6c\164" => false, "\x65\x6e\141\142\x6c\145\144" => true), array("\156\141\x6d\145" => "\141\x73\163\x69\x67\156\145\x64\x5f\165\x73\145\x72\137\156\x61\155\145", "\154\x61\142\x65\154" => "\x4c\102\114\137\101\123\x53\x49\107\x4e\105\x44\137\x54\117\x5f\116\101\x4d\x45", "\x64\145\146\x61\x75\154\x74" => true, "\145\x6e\141\x62\154\x65\x64" => true, "\x6c\151\156\153" => true), array("\x6e\141\155\x65" => "\144\141\x74\x65\x5f\x6d\x6f\x64\151\x66\151\x65\x64", "\145\x6e\x61\142\x6c\145\144" => true, "\144\145\146\141\x75\154\164" => true), array("\x6e\141\x6d\x65" => "\144\141\164\x65\137\x65\x6e\x74\x65\162\x65\x64", "\x65\x6e\141\x62\x6c\x65\x64" => true, "\x64\x65\x66\141\x75\154\x74" => true)))), "\x6f\162\144\x65\162\102\x79" => array("\146\151\x65\154\144" => "\144\141\x74\145\137\x6d\x6f\144\x69\146\151\145\144", "\144\x69\x72\145\143\164\151\x6f\x6e" => "\144\145\163\x63"));
