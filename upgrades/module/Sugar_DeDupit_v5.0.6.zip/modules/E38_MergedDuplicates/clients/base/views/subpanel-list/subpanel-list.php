<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\x38\x5f\115\x65\162\x67\145\144\104\165\x70\154\x69\x63\141\x74\x65\163"; $viewdefs[$module_name]["\142\141\x73\145"]["\166\151\x65\167"]["\x73\165\142\x70\x61\x6e\x65\154\55\154\x69\163\x74"] = array("\160\141\156\145\x6c\x73" => array(array("\x6e\x61\155\x65" => "\160\141\x6e\x65\154\137\150\145\x61\144\145\x72", "\x6c\141\x62\145\x6c" => "\x4c\x42\114\137\x50\x41\x4e\105\114\x5f\61", "\146\x69\x65\154\144\163" => array(array("\154\141\142\x65\154" => "\114\x42\114\137\116\x41\115\105", "\x65\156\x61\142\154\145\144" => true, "\144\x65\x66\x61\165\x6c\164" => true, "\x6e\x61\x6d\x65" => "\156\141\155\145", "\x6c\151\x6e\x6b" => true), array("\154\141\x62\145\x6c" => "\x4c\x42\x4c\137\x44\101\x54\105\137\x4d\117\x44\111\106\x49\x45\x44", "\145\x6e\x61\142\x6c\145\x64" => true, "\144\145\x66\141\x75\154\x74" => true, "\156\x61\x6d\x65" => "\144\141\164\145\137\x6d\x6f\x64\151\146\151\x65\144")))), "\157\x72\144\x65\162\x42\171" => array("\x66\x69\x65\x6c\x64" => "\x64\141\x74\145\x5f\x6d\x6f\144\151\146\151\x65\144", "\x64\151\162\x65\x63\x74\151\157\156" => "\x64\x65\x73\143"));
