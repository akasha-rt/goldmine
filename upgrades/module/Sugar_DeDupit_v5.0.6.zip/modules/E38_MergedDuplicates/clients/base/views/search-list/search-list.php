<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\137\115\145\162\147\x65\144\104\165\x70\x6c\151\143\141\x74\x65\x73"; $viewdefs[$module_name]["\142\141\163\145"]["\166\x69\x65\167"]["\163\x65\x61\x72\x63\x68\x2d\x6c\x69\163\x74"] = array("\160\141\156\145\x6c\163" => array(array("\156\x61\155\x65" => "\160\162\151\x6d\141\x72\x79", "\x66\151\x65\x6c\x64\x73" => array(array("\x6e\141\155\x65" => "\160\x69\x63\x74\165\x72\x65", "\x74\171\160\145" => "\141\x76\x61\x74\x61\162", "\163\x69\x7a\145" => "\155\145\144\151\165\x6d", "\x72\145\141\x64\157\156\154\171" => true, "\x63\x73\163\x5f\x63\154\x61\x73\163" => "\160\165\x6c\x6c\x2d\154\145\146\x74"), array("\156\x61\x6d\x65" => "\156\x61\155\x65", "\164\171\x70\145" => "\156\x61\155\145", "\x6c\151\156\x6b" => true, "\x6c\x61\142\145\x6c" => "\x4c\102\x4c\x5f\123\125\102\112\x45\103\124")))));
