<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\137\115\x65\x72\x67\145\x64\104\x75\x70\154\151\143\141\164\145\163"; $viewdefs[$module_name]["\142\141\x73\145"]["\166\151\x65\x77"]["\155\x61\163\x73\165\x70\144\141\x74\x65"] = array("\x62\x75\x74\x74\157\x6e\x73" => array(array("\164\x79\160\145" => "\142\165\x74\x74\157\x6e", "\166\141\154\165\145" => "\143\x61\156\143\x65\x6c", "\x63\163\163\137\143\x6c\141\x73\x73" => "\x62\164\156\x2d\x6c\x69\x6e\153\x20\x62\x74\156\55\151\x6e\166\151\x73\x69\x62\x6c\x65\40\x63\x61\x6e\x63\x65\154\x5f\x62\x75\x74\x74\157\x6e", "\154\x61\x62\145\154" => "\114\x42\x4c\x5f\x43\101\116\x43\x45\x4c\137\102\x55\124\124\x4f\116\137\x4c\101\102\x45\114", "\160\x72\x69\x6d\141\162\x79" => false), array("\x6e\x61\155\x65" => "\x75\x70\144\141\164\145\137\x62\x75\164\x74\x6f\x6e", "\164\171\160\145" => "\142\x75\164\x74\x6f\x6e", "\x6c\141\142\x65\x6c" => "\114\x42\x4c\x5f\x55\120\x44\101\x54\105", "\x61\x63\154\137\141\143\x74\x69\157\x6e" => "\155\141\163\163\x75\160\x64\x61\x74\145", "\143\x73\163\x5f\x63\x6c\x61\x73\163" => "\142\x74\156\x2d\x70\x72\x69\155\141\162\171", "\160\162\x69\x6d\x61\162\x79" => true)), "\x70\x61\x6e\x65\x6c\x73" => array(array("\146\151\x65\154\x64\x73" => array())));
