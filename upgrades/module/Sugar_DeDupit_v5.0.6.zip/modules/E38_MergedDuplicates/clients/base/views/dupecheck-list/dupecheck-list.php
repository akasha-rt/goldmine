<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\x38\137\115\x65\162\x67\x65\x64\x44\x75\x70\154\151\x63\141\164\x65\x73"; $viewdefs[$module_name]["\142\x61\x73\145"]["\166\151\x65\x77"]["\x64\x75\x70\x65\x63\150\145\143\153\55\154\x69\163\x74"] = array("\160\x61\x6e\145\x6c\x73" => array(array("\x6c\141\x62\x65\x6c" => "\114\x42\114\x5f\x50\x41\x4e\x45\x4c\137\61", "\x66\x69\145\x6c\x64\163" => array(array("\156\141\155\x65" => "\x6e\141\x6d\x65", "\154\x61\142\x65\x6c" => "\114\102\114\x5f\x4e\x41\x4d\x45", "\x64\145\x66\141\165\x6c\x74" => true, "\x65\x6e\141\142\x6c\145\x64" => true, "\x6c\151\156\x6b" => true), array("\156\x61\155\x65" => "\164\145\x61\155\x5f\x6e\x61\x6d\x65", "\154\141\142\145\154" => "\x4c\102\x4c\x5f\124\105\101\x4d", "\x64\x65\146\x61\165\154\164" => true, "\145\156\141\x62\x6c\x65\x64" => true), array("\156\x61\155\x65" => "\141\163\x73\151\147\156\x65\144\x5f\165\163\x65\162\137\156\141\155\x65", "\154\x61\142\x65\154" => "\x4c\x42\x4c\x5f\101\123\123\x49\107\116\105\x44\137\x54\x4f\x5f\x4e\x41\115\x45", "\144\x65\x66\x61\x75\x6c\x74" => true, "\145\x6e\141\x62\x6c\x65\x64" => true, "\x6c\151\x6e\x6b" => true), array("\x6c\141\x62\x65\x6c" => "\114\x42\x4c\x5f\x44\101\x54\105\137\115\117\x44\x49\x46\111\105\104", "\x65\x6e\141\142\x6c\145\144" => true, "\144\x65\146\x61\165\154\164" => true, "\156\x61\x6d\x65" => "\x64\x61\164\145\137\155\x6f\x64\151\146\x69\x65\x64", "\x72\x65\141\x64\x6f\x6e\x6c\171" => true)))));
