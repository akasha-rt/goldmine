<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\x45\x33\x38\137\x4d\x65\162\x67\x65\x64\104\165\x70\154\151\143\x61\x74\145\163"]["\142\x61\x73\145"]["\x76\x69\x65\x77"]["\160\162\145\166\x69\145\x77\55\144\165\x70\154\x69\x63\141\x74\145\55\142\x65\141\x6e"] = array("\142\x75\x74\164\x6f\x6e\163" => array(array("\164\x79\x70\145" => "\x62\x75\x74\164\157\156", "\x6e\x61\155\x65" => "\143\x6c\157\163\x65\x5f\x62\165\x74\164\x6f\156", "\x6c\x61\142\x65\x6c" => "\114\102\114\x5f\103\x4c\117\x53\105\x5f\x42\x55\124\x54\x4f\x4e\x5f\x4c\101\x42\105\114", "\x63\163\163\x5f\x63\x6c\141\x73\x73" => "\142\164\156", "\145\x76\145\156\x74\x73" => array("\143\x6c\151\x63\x6b" => "\x62\165\x74\164\157\x6e\x3a\143\154\157\163\x65\137\142\165\x74\164\157\156\x3a\143\x6c\x69\143\153"))));
