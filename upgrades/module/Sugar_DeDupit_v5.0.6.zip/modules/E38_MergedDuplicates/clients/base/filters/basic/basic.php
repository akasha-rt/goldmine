<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\147\x61\x72\105\156\164\162\171") || !sugarEntry)) { goto ywX8D; } die("\116\157\164\x20\x41\40\126\x61\x6c\151\x64\x20\x45\x6e\164\162\x79\x20\120\157\x69\x6e\x74"); ywX8D: $viewdefs["\x45\x33\70\x5f\115\145\x72\x67\145\x64\104\165\160\x6c\x69\x63\141\x74\145\163"]["\x62\141\x73\145"]["\x66\151\x6c\x74\145\x72"]["\x62\x61\x73\x69\x63"] = array("\143\162\145\141\164\145" => true, "\161\165\151\143\153\163\145\x61\162\143\150\137\146\151\x65\154\x64" => array("\156\141\x6d\145"), "\161\165\151\x63\x6b\163\x65\141\x72\143\150\137\160\162\151\x6f\162\151\164\171" => 1, "\161\x75\151\x63\x6b\163\x65\x61\x72\x63\150\137\163\x70\x6c\x69\164\x5f\x74\x65\162\155\163" => false, "\x66\151\154\x74\145\162\163" => array(array("\151\x64" => "\x61\154\154\x5f\162\x65\x63\x6f\x72\x64\x73", "\x6e\x61\155\145" => "\114\x42\114\137\x4c\111\x53\x54\x56\111\105\x57\137\106\x49\114\124\105\x52\x5f\101\114\x4c", "\146\x69\x6c\164\x65\162\137\144\x65\146\151\x6e\151\x74\x69\x6f\x6e" => array(), "\x65\x64\x69\x74\141\142\x6c\x65" => false), array("\x69\x64" => "\x61\163\163\151\x67\156\x65\144\137\164\157\137\x6d\145", "\x6e\x61\155\x65" => "\x4c\102\x4c\137\101\123\x53\111\x47\x4e\x45\104\x5f\124\x4f\137\115\105", "\146\x69\x6c\164\x65\x72\x5f\x64\145\x66\x69\x6e\151\164\x69\x6f\x6e" => array("\44\x6f\167\x6e\x65\x72" => ''), "\145\144\x69\x74\x61\x62\x6c\x65" => false), array("\151\144" => "\x66\x61\166\157\162\151\x74\145\x73", "\x6e\x61\155\x65" => "\x4c\102\114\x5f\106\x41\126\x4f\x52\111\124\x45\123", "\146\x69\x6c\x74\x65\x72\137\144\x65\146\x69\x6e\151\164\x69\157\156" => array("\44\146\x61\166\157\162\x69\164\x65" => ''), "\145\144\x69\x74\x61\142\154\145" => false), array("\x69\x64" => "\x72\x65\x63\145\x6e\164\x6c\x79\137\166\151\x65\167\x65\144", "\156\x61\155\145" => "\x4c\102\x4c\x5f\122\105\103\x45\116\124\x4c\131\x5f\x56\111\105\127\105\x44", "\x66\x69\x6c\x74\x65\162\137\144\145\146\151\x6e\x69\164\x69\157\156" => array("\44\164\x72\x61\143\153\x65\x72" => "\55\x37\x20\x44\x41\131"), "\x65\144\x69\x74\141\142\154\x65" => false), array("\x69\x64" => "\x72\145\x63\145\156\x74\154\171\x5f\x63\162\x65\x61\x74\145\144", "\156\x61\155\145" => "\x4c\102\x4c\137\x4e\x45\x57\x5f\122\x45\103\x4f\122\x44\x53", "\x66\151\154\164\145\162\137\144\x65\x66\151\x6e\151\x74\151\157\x6e" => array("\144\141\x74\145\137\145\x6e\x74\145\x72\145\144" => array("\x24\144\x61\164\x65\122\x61\156\147\145" => "\x6c\141\163\x74\x5f\x37\137\x64\141\171\x73")), "\145\x64\x69\164\x61\142\154\x65" => false)));
