<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\x75\147\141\x72\x45\156\x74\162\171") || !sugarEntry)) { goto e6zrL; } die("\116\157\164\40\x41\x20\x56\x61\x6c\x69\144\x20\105\x6e\164\x72\x79\40\x50\157\x69\156\x74"); e6zrL: global $app_strings; $dashletMeta["\105\x33\x38\137\115\x65\x72\147\145\144\x44\x75\x70\x6c\151\143\141\x74\x65\x73\104\141\x73\x68\154\x65\164"] = array("\x6d\x6f\144\165\x6c\145" => "\105\x33\x38\x5f\115\145\x72\147\145\x64\104\165\160\x6c\x69\x63\141\164\145\163", "\164\x69\164\154\x65" => translate("\114\102\114\x5f\x48\x4f\x4d\x45\120\101\107\105\x5f\124\x49\124\114\105", "\105\x33\x38\137\x4d\145\x72\147\145\x64\x44\x75\160\x6c\x69\143\141\164\145\163"), "\144\145\x73\x63\162\x69\x70\164\x69\x6f\x6e" => "\x41\40\x63\x75\163\x74\x6f\155\151\172\141\142\154\145\x20\166\x69\145\x77\40\x69\156\x74\157\x20\105\63\x38\x5f\x4d\x65\x72\147\x65\144\x44\x75\x70\154\151\143\141\x74\x65\163", "\151\143\157\x6e" => "\x69\x63\x6f\156\137\x45\x33\x38\x5f\x4d\x65\162\x67\x65\x64\x44\x75\160\x6c\x69\143\x61\x74\x65\x73\137\x33\x32\x2e\x67\151\x66", "\x63\141\164\145\x67\x6f\x72\x79" => "\x4d\157\x64\x75\x6c\145\40\x56\x69\x65\x77\163");
