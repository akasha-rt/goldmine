<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\137\x4d\x65\162\x67\x65\x64\x44\165\160\x6c\x69\x63\141\164\145\163"; $viewdefs[$module_name]["\x44\x65\164\141\151\154\x56\151\x65\167"] = array("\164\x65\155\160\x6c\141\x74\x65\115\145\x74\x61" => array("\146\x6f\x72\155" => array("\x62\x75\x74\x74\x6f\x6e\x73" => array("\x45\104\x49\124", "\104\x55\120\114\x49\103\x41\x54\105", "\104\x45\114\x45\x54\x45", "\106\x49\116\104\137\104\125\x50\114\111\103\101\124\x45\123")), "\x6d\x61\x78\x43\x6f\x6c\x75\x6d\156\x73" => "\62", "\x77\x69\144\x74\150\x73" => array(array("\x6c\x61\142\145\x6c" => "\x31\60", "\146\x69\145\x6c\144" => "\63\60"), array("\154\141\142\145\154" => "\61\60", "\146\x69\x65\x6c\x64" => "\x33\x30"))), "\160\x61\156\145\154\163" => array(array("\156\x61\155\x65", "\x61\x73\163\x69\x67\156\145\144\137\165\x73\145\x72\137\156\x61\x6d\x65"), array("\x74\x65\141\x6d\137\156\x61\x6d\x65", ''), array(array("\156\141\x6d\145" => "\x64\141\164\145\x5f\145\156\x74\145\x72\145\144", "\143\165\x73\164\x6f\x6d\x43\157\x64\145" => "\173\44\146\x69\x65\x6c\144\x73\56\144\141\x74\x65\x5f\145\x6e\164\x65\x72\145\x64\56\x76\x61\154\165\x65\x7d\x20\x7b\44\x41\120\120\x2e\x4c\x42\114\137\x42\x59\x7d\x20\x7b\x24\146\151\x65\x6c\144\x73\56\143\162\x65\x61\x74\x65\144\x5f\142\171\137\156\x61\155\145\56\166\141\x6c\x75\x65\175", "\x6c\x61\x62\145\x6c" => "\x4c\x42\x4c\x5f\x44\101\x54\x45\x5f\x45\x4e\x54\x45\x52\105\x44"), array("\156\x61\155\145" => "\144\141\164\145\x5f\155\x6f\x64\151\x66\151\x65\144", "\x63\x75\x73\164\x6f\155\103\157\144\x65" => "\x7b\44\x66\x69\x65\x6c\144\x73\x2e\x64\141\x74\x65\137\x6d\x6f\144\x69\x66\151\x65\144\x2e\166\x61\154\x75\x65\175\40\173\44\x41\120\120\x2e\x4c\102\x4c\x5f\x42\131\x7d\x20\x7b\x24\x66\151\145\x6c\144\x73\x2e\x6d\x6f\144\x69\x66\x69\145\x64\137\x62\171\137\x6e\x61\155\x65\x2e\x76\x61\x6c\x75\x65\x7d", "\154\x61\x62\x65\154" => "\114\102\114\x5f\x44\101\124\105\137\x4d\x4f\104\x49\106\111\x45\104")), array("\144\145\163\143\162\x69\x70\164\151\157\156")));
