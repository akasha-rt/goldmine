<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\147\141\x72\105\156\x74\x72\x79") || !sugarEntry)) { goto HV5h2; } die("\x4e\157\164\x20\x41\40\126\141\154\x69\144\x20\105\x6e\164\162\x79\x20\120\x6f\151\x6e\x74"); HV5h2: $module_name = "\x45\x33\x38\137\115\x65\x72\x67\145\144\x44\165\x70\154\151\x63\141\164\x65\x73"; $object_name = "\105\63\70\x5f\115\145\162\x67\145\144\x44\x75\x70\154\x69\143\x61\x74\x65\163"; $_module_name = "\145\63\x38\x5f\x6d\x65\x72\147\145\144\x64\x75\x70\154\x69\143\x61\x74\145\x73"; $popupMeta = array("\155\x6f\x64\x75\x6c\x65\x4d\141\x69\156" => $module_name, "\x76\141\x72\x4e\x61\155\x65" => $object_name, "\x6f\162\144\145\x72\x42\x79" => $_module_name . "\x2e\156\141\x6d\x65", "\167\x68\145\162\145\x43\x6c\141\165\163\145\x73" => array("\x6e\x61\155\145" => $_module_name . "\x2e\x6e\x61\x6d\145"), "\163\x65\x61\x72\x63\x68\x49\x6e\x70\165\x74\x73" => array($_module_name . "\137\x6e\x75\155\142\145\x72", "\156\x61\x6d\145", "\x70\x72\151\157\x72\x69\x74\x79", "\x73\164\x61\164\x75\x73"));
