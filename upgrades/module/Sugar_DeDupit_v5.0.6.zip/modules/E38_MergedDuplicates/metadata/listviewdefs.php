<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\147\x61\162\x45\156\x74\162\x79") || !sugarEntry)) { goto j5QSO; } die("\116\x6f\164\40\101\x20\x56\141\x6c\151\144\40\105\x6e\x74\x72\171\x20\120\x6f\x69\156\x74"); j5QSO: $module_name = "\x45\63\70\x5f\115\x65\162\x67\145\x64\x44\165\160\x6c\151\x63\141\x74\x65\163"; $listViewDefs[$module_name] = array("\116\x41\115\105" => array("\x77\x69\144\x74\150" => "\63\62", "\x6c\141\x62\145\154" => "\x4c\x42\x4c\137\x4e\x41\x4d\x45", "\144\145\x66\x61\x75\x6c\x74" => true, "\x6c\x69\x6e\x6b" => true), "\124\105\x41\x4d\137\116\101\115\x45" => array("\167\x69\x64\x74\x68" => "\71", "\x6c\141\x62\145\154" => "\114\102\x4c\x5f\x54\105\x41\x4d", "\x64\145\x66\x61\x75\154\x74" => false), "\x41\x53\x53\x49\107\116\105\104\x5f\x55\123\105\122\x5f\x4e\101\x4d\x45" => array("\x77\151\x64\164\150" => "\71", "\x6c\141\x62\145\x6c" => "\x4c\x42\114\x5f\x41\123\123\111\x47\116\105\x44\137\x54\x4f\x5f\116\101\x4d\105", "\x6d\x6f\144\165\x6c\145" => "\x45\x6d\x70\x6c\157\x79\145\145\163", "\x69\x64" => "\x41\123\123\111\x47\x4e\x45\104\x5f\125\123\x45\x52\137\x49\x44", "\x64\145\146\141\x75\x6c\164" => true));
