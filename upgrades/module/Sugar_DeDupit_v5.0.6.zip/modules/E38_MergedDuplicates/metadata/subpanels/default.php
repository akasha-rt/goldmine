<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\147\x61\162\x45\156\164\x72\x79") || !sugarEntry)) { goto WJLJe; } die("\x4e\157\x74\x20\x41\x20\126\x61\x6c\x69\x64\40\105\x6e\164\x72\x79\x20\x50\x6f\x69\x6e\164"); WJLJe: $module_name = "\105\63\70\x5f\x4d\x65\162\147\x65\144\104\165\160\x6c\x69\x63\x61\x74\145\163"; $subpanel_layout = array("\x74\157\160\x5f\142\165\164\164\x6f\x6e\163" => array(array("\167\x69\144\x67\145\x74\x5f\143\154\141\163\x73" => "\x53\165\142\x50\141\x6e\x65\154\x54\x6f\160\x43\x72\145\141\164\x65\102\165\164\x74\x6f\156"), array("\x77\151\x64\147\145\x74\x5f\x63\x6c\x61\x73\163" => "\x53\x75\x62\x50\x61\156\x65\154\x54\157\160\x53\145\154\145\x63\x74\102\165\164\164\157\x6e", "\x70\157\160\165\160\137\155\157\144\165\x6c\x65" => $module_name)), "\x77\x68\145\162\145" => '', "\154\x69\163\164\137\x66\151\x65\154\144\163" => array("\x6e\x61\155\x65" => array("\x76\156\x61\155\x65" => "\114\x42\114\x5f\116\x41\x4d\x45", "\x77\151\144\147\x65\164\x5f\x63\x6c\141\x73\163" => "\123\x75\142\x50\x61\x6e\x65\x6c\x44\x65\x74\141\151\154\x56\151\145\x77\114\151\156\x6b", "\167\x69\x64\164\x68" => "\64\65\45"), "\x64\x61\x74\145\x5f\155\x6f\x64\151\x66\x69\145\x64" => array("\166\x6e\x61\155\x65" => "\x4c\102\114\x5f\x44\101\x54\105\137\x4d\x4f\x44\111\106\x49\x45\104", "\167\151\144\164\x68" => "\64\x35\45"), "\145\144\x69\x74\137\x62\165\x74\x74\157\156" => array("\x76\x6e\141\155\145" => "\114\102\114\x5f\x45\104\111\124\x5f\102\x55\124\x54\117\116", "\167\x69\144\147\x65\x74\x5f\143\x6c\141\163\163" => "\x53\165\142\x50\x61\156\x65\x6c\x45\144\x69\x74\102\x75\164\x74\x6f\156", "\x6d\157\144\x75\x6c\x65" => $module_name, "\x77\151\x64\x74\150" => "\x34\45"), "\162\x65\x6d\157\x76\x65\x5f\142\165\164\164\157\156" => array("\x76\x6e\x61\x6d\145" => "\x4c\x42\114\x5f\122\x45\115\117\126\x45", "\x77\x69\144\147\145\164\137\x63\154\x61\163\x73" => "\x53\165\142\120\141\x6e\x65\154\122\x65\155\157\x76\x65\102\165\164\164\157\x6e", "\x6d\157\x64\x75\x6c\x65" => $module_name, "\167\151\x64\164\x68" => "\65\x25")));
