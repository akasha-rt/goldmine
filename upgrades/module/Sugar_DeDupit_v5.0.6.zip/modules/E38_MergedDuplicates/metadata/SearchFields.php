<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\x67\141\162\x45\x6e\164\162\171") || !sugarEntry)) { goto YnDlW; } die("\x4e\157\164\x20\x41\x20\x56\x61\x6c\x69\144\40\105\x6e\x74\x72\x79\x20\x50\x6f\x69\x6e\x74"); YnDlW: $module_name = "\105\x33\70\x5f\x4d\x65\x72\147\145\x64\104\x75\x70\x6c\151\x63\141\x74\x65\x73"; $searchFields[$module_name] = array("\156\141\155\x65" => array("\161\x75\x65\x72\171\x5f\x74\x79\x70\145" => "\x64\x65\146\x61\x75\154\164"), "\143\165\x72\x72\x65\156\x74\137\165\x73\x65\162\137\157\x6e\x6c\x79" => array("\161\165\145\x72\171\137\x74\171\x70\145" => "\144\145\146\141\165\154\x74", "\144\x62\137\146\x69\x65\x6c\144" => array("\141\163\x73\x69\147\x6e\145\x64\x5f\165\163\x65\x72\137\151\144"), "\155\171\137\151\x74\145\155\x73" => true, "\x76\156\x61\155\145" => "\114\x42\114\137\103\x55\122\122\105\x4e\124\137\125\x53\x45\122\137\106\111\114\x54\x45\x52", "\x74\171\x70\x65" => "\142\x6f\x6f\154"), "\x61\x73\163\x69\x67\156\145\144\137\165\x73\x65\x72\x5f\x69\144" => array("\x71\165\145\x72\x79\137\x74\171\x70\145" => "\144\x65\x66\x61\x75\154\x74"), "\x66\141\166\x6f\162\x69\x74\145\163\x5f\157\156\154\x79" => array("\x71\165\145\x72\x79\x5f\x74\x79\160\145" => "\146\x6f\x72\155\x61\x74", "\x6f\160\145\x72\x61\x74\x6f\x72" => "\163\x75\x62\161\x75\x65\x72\171", "\x73\165\142\161\165\145\x72\171" => "\x53\105\114\105\x43\124\x20\x73\x75\147\x61\x72\x66\141\x76\x6f\162\x69\164\x65\x73\56\162\145\143\x6f\162\x64\137\x69\x64\40\106\x52\x4f\115\40\163\x75\x67\141\162\146\x61\x76\x6f\162\x69\x74\145\x73\x20\xa\x9\11\x9\40\40\40\x20\x20\x20\40\40\x20\40\40\40\40\40\x20\x20\40\x20\40\40\127\x48\x45\122\105\40\163\165\x67\141\x72\146\x61\x76\x6f\x72\151\164\145\x73\56\x64\x65\x6c\145\164\x65\x64\x3d\x30\40\12\11\x9\x9\x20\x20\40\40\x20\40\40\x20\40\x20\40\40\40\x20\x20\x20\x20\x20\40\40\40\x20\x20\x20\x61\156\144\x20\x73\165\147\141\162\146\x61\166\x6f\162\151\164\145\x73\x2e\x6d\x6f\x64\165\x6c\x65\40\75\40\x27" . $module_name . "\x27\12\x9\11\x9\x20\x20\x20\x20\40\x20\40\40\40\x20\40\x20\x20\40\40\40\x20\40\40\40\40\40\x20\40\141\156\144\40\163\x75\x67\x61\162\x66\141\166\157\x72\151\164\145\163\56\x61\x73\163\151\x67\x6e\x65\144\x5f\165\163\x65\162\x5f\x69\x64\40\75\x20\x27\173\x30\175\x27", "\x64\x62\x5f\146\151\145\154\144" => array("\x69\144")), "\162\x61\156\147\145\x5f\144\141\164\x65\x5f\145\156\x74\145\162\145\x64" => array("\161\x75\x65\162\171\137\x74\171\160\x65" => "\144\145\x66\141\165\154\x74", "\x65\156\141\142\x6c\145\x5f\162\x61\x6e\x67\x65\x5f\163\x65\x61\162\143\150" => true, "\x69\x73\x5f\x64\141\164\x65\x5f\x66\151\x65\154\144" => true), "\x73\x74\x61\162\x74\137\162\141\156\147\x65\137\x64\141\164\x65\x5f\x65\x6e\164\x65\162\x65\x64" => array("\x71\x75\x65\162\171\x5f\x74\x79\160\x65" => "\x64\x65\x66\141\165\154\164", "\145\x6e\141\x62\x6c\x65\x5f\x72\x61\156\x67\145\137\163\x65\141\x72\x63\150" => true, "\151\x73\x5f\x64\141\164\x65\137\x66\151\145\154\x64" => true), "\x65\x6e\x64\x5f\x72\x61\x6e\x67\145\x5f\x64\x61\164\x65\137\x65\x6e\164\145\162\x65\x64" => array("\x71\x75\145\x72\x79\137\164\x79\160\145" => "\x64\145\x66\141\165\154\164", "\x65\x6e\x61\142\x6c\145\137\162\x61\156\x67\x65\x5f\x73\145\x61\x72\143\150" => true, "\151\163\137\x64\x61\164\x65\137\146\x69\x65\154\x64" => true), "\162\x61\x6e\x67\145\137\144\x61\164\x65\137\x6d\x6f\144\x69\146\x69\x65\x64" => array("\161\x75\145\x72\x79\x5f\x74\171\160\x65" => "\x64\145\146\x61\165\x6c\x74", "\x65\x6e\x61\x62\x6c\145\x5f\162\141\156\x67\145\x5f\163\145\x61\162\143\x68" => true, "\151\x73\137\x64\x61\164\x65\137\x66\x69\145\154\144" => true), "\x73\164\x61\x72\x74\x5f\x72\x61\x6e\x67\x65\x5f\x64\x61\164\145\137\x6d\157\144\151\x66\151\145\144" => array("\161\165\145\x72\x79\x5f\x74\171\160\145" => "\144\x65\146\141\165\154\164", "\145\x6e\x61\x62\x6c\x65\137\162\141\x6e\x67\x65\x5f\x73\145\141\162\x63\x68" => true, "\x69\163\137\144\141\x74\145\x5f\x66\x69\145\154\x64" => true), "\x65\156\x64\x5f\162\x61\x6e\x67\x65\137\144\x61\164\x65\137\155\157\x64\x69\x66\151\x65\x64" => array("\x71\x75\x65\x72\x79\x5f\x74\x79\160\x65" => "\144\145\x66\141\x75\154\164", "\145\156\x61\x62\x6c\145\x5f\162\141\156\147\x65\x5f\163\x65\141\162\143\x68" => true, "\x69\x73\x5f\144\141\x74\145\137\x66\x69\145\x6c\x64" => true));
