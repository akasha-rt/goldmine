<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\70\137\115\145\162\x67\x65\x64\104\x75\160\154\x69\x63\141\x74\145\x73"; $searchdefs[$module_name] = array("\164\x65\x6d\x70\x6c\141\x74\x65\115\x65\164\x61" => array("\155\x61\170\103\x6f\x6c\x75\x6d\x6e\163" => "\x33", "\x6d\141\170\x43\157\154\165\x6d\156\x73\x42\x61\x73\x69\143" => "\x34", "\x77\151\144\x74\150\x73" => array("\154\141\142\145\154" => "\x31\x30", "\146\151\x65\154\x64" => "\63\x30")), "\154\141\171\x6f\165\164" => array("\142\141\x73\x69\143\x5f\x73\x65\x61\162\143\x68" => array("\156\141\x6d\145", array("\x6e\141\155\145" => "\x63\165\162\162\145\x6e\x74\x5f\165\163\145\162\x5f\157\x6e\x6c\171", "\x6c\141\x62\x65\154" => "\114\x42\114\137\103\x55\122\122\105\x4e\x54\x5f\x55\123\x45\x52\137\x46\111\x4c\124\105\122", "\164\171\x70\145" => "\142\157\x6f\154"), array("\x6e\141\155\x65" => "\x66\141\166\x6f\162\x69\164\x65\163\137\157\x6e\x6c\171", "\154\x61\142\x65\154" => "\x4c\102\114\x5f\106\101\126\x4f\122\111\x54\105\x53\137\106\x49\114\x54\105\122", "\x74\171\160\145" => "\142\x6f\157\154")), "\141\144\x76\x61\156\143\145\144\x5f\x73\145\x61\162\x63\150" => array("\156\x61\155\x65", array("\x6e\x61\155\x65" => "\141\163\163\151\x67\156\x65\x64\x5f\x75\163\x65\x72\137\x69\x64", "\x6c\x61\x62\x65\x6c" => "\114\102\x4c\137\101\x53\x53\x49\x47\x4e\x45\104\x5f\x54\117", "\164\x79\x70\145" => "\x65\x6e\x75\x6d", "\146\x75\156\x63\164\151\157\156" => array("\x6e\x61\x6d\x65" => "\147\x65\x74\x5f\165\163\x65\162\x5f\x61\162\162\141\171", "\x70\141\x72\141\x6d\x73" => array(false))), array("\x6e\x61\155\x65" => "\x66\141\166\x6f\x72\x69\x74\145\163\137\x6f\156\154\171", "\154\x61\142\x65\154" => "\x4c\102\x4c\137\106\101\126\117\x52\111\124\105\x53\x5f\x46\x49\114\124\105\122", "\x74\171\x70\x65" => "\142\157\157\154"))));
