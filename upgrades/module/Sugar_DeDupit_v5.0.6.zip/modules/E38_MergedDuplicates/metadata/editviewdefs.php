<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\x5f\115\145\162\147\x65\144\x44\165\x70\x6c\151\x63\x61\164\x65\x73"; $viewdefs[$module_name]["\105\144\151\164\x56\x69\x65\167"] = array("\164\x65\x6d\x70\x6c\141\x74\x65\115\145\164\x61" => array("\155\141\x78\103\157\x6c\x75\x6d\156\163" => "\62", "\167\151\144\x74\x68\x73" => array(array("\154\x61\x62\x65\154" => "\61\x30", "\x66\151\x65\154\x64" => "\x33\60"), array("\154\x61\x62\x65\x6c" => "\x31\x30", "\146\x69\x65\154\x64" => "\x33\60"))), "\x70\x61\156\145\154\x73" => array("\x64\145\146\141\x75\x6c\164" => array(array("\156\x61\155\x65", "\x61\163\x73\x69\x67\156\145\x64\x5f\x75\x73\x65\x72\137\x6e\x61\155\145"), array(array("\156\x61\x6d\145" => "\164\145\141\x6d\x5f\156\141\155\145", "\x64\151\163\160\x6c\x61\171\x50\141\x72\x61\x6d\x73" => array("\144\151\163\x70\154\141\x79" => true)), ''), array("\x64\x65\x73\x63\x72\x69\160\x74\x69\x6f\156"))));
