<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\x38\137\106\x6f\165\x6e\144\x44\165\x70\154\x69\143\141\164\x65\163"; $viewdefs[$module_name]["\x62\x61\x73\145"]["\166\151\x65\x77"]["\x64\x75\160\x65\143\150\145\x63\153\x2d\x6c\x69\x73\x74"] = array("\160\141\x6e\x65\154\x73" => array(array("\x6c\141\x62\x65\154" => "\x4c\102\114\137\x50\101\116\x45\114\x5f\61", "\x66\151\145\154\x64\163" => array(array("\156\141\x6d\x65" => "\156\x61\x6d\x65", "\x6c\141\x62\x65\154" => "\x4c\x42\x4c\137\116\x41\x4d\x45", "\144\145\146\141\x75\154\x74" => true, "\145\x6e\x61\142\154\145\144" => true, "\154\x69\156\x6b" => true), array("\x6e\x61\155\145" => "\x74\145\141\155\x5f\x6e\x61\155\145", "\x6c\141\x62\145\x6c" => "\114\x42\x4c\x5f\124\105\x41\115", "\x64\x65\146\141\x75\154\164" => true, "\145\x6e\x61\142\154\145\144" => true), array("\x6e\x61\155\x65" => "\x61\x73\x73\151\x67\x6e\x65\x64\137\x75\163\145\x72\x5f\x6e\x61\x6d\x65", "\x6c\x61\x62\145\154" => "\x4c\x42\x4c\137\101\x53\123\111\x47\x4e\x45\104\x5f\x54\117\137\116\101\x4d\105", "\144\145\146\141\x75\x6c\164" => true, "\x65\156\x61\x62\154\145\144" => true, "\x6c\151\x6e\153" => true), array("\154\x61\x62\x65\x6c" => "\x4c\102\x4c\x5f\104\x41\x54\105\137\115\117\x44\111\106\111\x45\104", "\x65\156\141\142\x6c\145\144" => true, "\144\145\x66\x61\x75\x6c\164" => true, "\156\x61\155\145" => "\x64\x61\164\x65\137\155\x6f\x64\151\146\x69\x65\144", "\162\x65\x61\144\x6f\x6e\154\x79" => true)))));
