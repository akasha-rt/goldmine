<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\x45\x33\x38\137\106\157\x75\156\x64\x44\x75\160\x6c\x69\143\141\x74\145\x73"]["\142\x61\x73\145"]["\x76\151\x65\167"]["\162\145\x63\x6f\162\144\154\x69\163\x74"] = array("\146\x61\166\157\x72\151\x74\x65" => false, "\x66\x6f\x6c\154\x6f\167\x69\156\147" => false, "\163\164\151\x63\x6b\x79\x5f\x72\145\x73\x69\172\x61\142\x6c\x65\x5f\x63\x6f\154\165\155\156\163" => true, "\x73\x65\154\145\143\164\151\x6f\156" => array("\151\163\123\145\141\162\143\150\x41\x6e\x64\x53\145\x6c\145\x63\164\x41\x63\x74\151\x6f\156" => false), "\162\x6f\167\x61\x63\164\151\157\x6e\x73" => array("\x61\x63\x74\x69\x6f\156\163" => array(array("\164\171\160\145" => "\162\x6f\x77\x61\143\164\151\157\156", "\x63\163\x73\137\x63\154\141\163\x73" => "\142\x74\x6e", "\x74\x6f\x6f\x6c\x74\x69\x70" => "\x4c\102\114\137\115\105\x52\107\105", "\x65\x76\145\156\x74" => "\154\x69\163\x74\x3a\x33\70\145\x6c\x65\x6d\x65\x6e\x74\x73\72\63\x38\145\x6c\145\x6d\145\x6e\164\163\x2d\155\x65\162\147\x65", "\x69\x63\x6f\156" => "\x66\x61\x2d\x63\x6f\x6d\x70\162\x65\x73\x73", "\x61\x63\x6c\x5f\141\143\164\x69\157\156" => "\166\x69\145\167"), array("\164\x79\x70\x65" => "\162\157\167\x61\143\164\151\157\156", "\164\157\x6f\x6c\x74\151\160" => "\114\x42\x4c\x5f\111\x47\116\117\x52\105\x5f\x50\x41\x49\122", "\x65\x76\145\x6e\x74" => "\x6c\151\163\164\x3a\x33\x38\145\154\145\155\x65\x6e\164\x73\72\x69\x67\156\157\x72\x65\x2d\x64\x75\x70\154\151\x63\141\164\145\163", "\x61\143\154\x5f\x61\x63\x74\151\x6f\156" => "\x76\x69\145\x77", "\x6c\141\x62\x65\154" => "\114\102\x4c\x5f\105\63\x38\x5f\x49\107\116\x4f\x52\105\137\104\x55\120\114\x49\x43\101\124\x45\x53"))), "\154\x61\163\x74\137\163\x74\141\x74\145" => array("\x69\x64" => "\x72\x65\x63\157\162\144\x2d\154\151\x73\x74"));
