<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\137\106\x6f\165\156\x64\104\x75\160\154\151\143\x61\x74\145\163"; $viewdefs[$module_name]["\x62\141\163\x65"]["\x76\151\145\167"]["\x73\x75\x62\x70\x61\x6e\x65\x6c\55\154\x69\x73\x74"] = array("\x70\141\x6e\145\x6c\x73" => array(array("\x6e\x61\x6d\145" => "\x70\141\x6e\145\154\137\x68\x65\x61\x64\x65\x72", "\x6c\141\x62\x65\x6c" => "\x4c\102\x4c\137\x50\x41\x4e\x45\x4c\137\x31", "\x66\151\145\x6c\144\163" => array(array("\154\x61\x62\145\x6c" => "\114\x42\x4c\137\x4e\101\115\x45", "\145\156\141\x62\154\145\x64" => true, "\144\x65\x66\141\165\x6c\164" => true, "\156\141\x6d\x65" => "\x6e\x61\x6d\145", "\154\151\x6e\153" => true), array("\154\141\x62\x65\x6c" => "\x4c\102\114\x5f\x44\101\124\x45\x5f\115\x4f\104\111\x46\111\105\x44", "\x65\156\x61\x62\154\145\144" => true, "\x64\x65\x66\141\x75\x6c\x74" => true, "\156\141\x6d\145" => "\144\x61\164\x65\137\155\157\x64\151\x66\151\x65\144")))), "\x6f\x72\x64\145\x72\102\x79" => array("\146\x69\x65\x6c\144" => "\144\141\164\145\137\x6d\157\144\151\x66\x69\x65\144", "\144\x69\162\x65\x63\x74\151\x6f\x6e" => "\x64\145\x73\143"));
