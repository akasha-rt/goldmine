<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\70\137\106\x6f\165\x6e\x64\104\x75\x70\x6c\x69\x63\141\164\x65\x73"; $viewdefs[$module_name]["\142\141\x73\x65"]["\x76\151\x65\167"]["\163\x65\x6c\145\x63\x74\x69\157\x6e\x2d\x6c\x69\x73\164"] = array("\x70\141\x6e\x65\x6c\x73" => array(array("\154\141\142\x65\154" => "\x4c\102\x4c\137\x50\101\x4e\105\114\137\61", "\146\151\145\x6c\144\x73" => array(array("\156\141\155\145" => "\x6e\x61\x6d\145", "\x6c\x61\142\x65\x6c" => "\x4c\x42\x4c\137\x4e\101\x4d\105", "\144\145\146\x61\165\154\x74" => true, "\x65\x6e\x61\x62\154\x65\144" => true, "\154\151\156\x6b" => true), array("\156\141\155\145" => "\164\x65\x61\155\137\x6e\141\155\x65", "\154\141\142\145\154" => "\x4c\102\114\137\x54\105\x41\115", "\144\145\x66\141\165\x6c\x74" => true, "\145\156\x61\142\x6c\145\x64" => true), array("\x6e\141\155\145" => "\x61\x73\x73\151\147\156\x65\x64\x5f\x75\x73\x65\x72\137\156\141\155\145", "\154\141\x62\145\154" => "\x4c\102\x4c\137\101\123\123\111\x47\116\x45\104\x5f\124\117\137\116\x41\115\105", "\x64\145\146\141\165\154\x74" => true, "\145\x6e\141\x62\154\145\x64" => true, "\x6c\x69\156\153" => true), array("\154\141\x62\x65\x6c" => "\x4c\102\x4c\x5f\x44\101\124\105\x5f\115\117\x44\111\x46\111\105\104", "\145\x6e\141\x62\x6c\145\x64" => true, "\144\145\146\141\x75\x6c\164" => true, "\156\141\x6d\145" => "\144\x61\x74\x65\137\x6d\157\144\151\146\x69\x65\144", "\x72\x65\x61\144\x6f\156\154\171" => true)))), "\157\x72\x64\145\162\x42\x79" => array("\146\x69\145\154\x64" => "\x64\141\164\145\137\x6d\157\x64\x69\x66\x69\x65\x64", "\144\151\162\x65\143\x74\151\x6f\x6e" => "\144\145\163\143"));
