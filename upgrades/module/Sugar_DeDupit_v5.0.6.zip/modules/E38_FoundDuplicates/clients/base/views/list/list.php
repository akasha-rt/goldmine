<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\105\x33\70\137\106\x6f\x75\156\144\x44\x75\160\x6c\151\x63\141\x74\x65\163"] = array("\142\x61\x73\x65" => array("\x76\151\145\167" => array("\x6c\x69\163\164" => array("\160\141\x6e\145\154\163" => array(array("\x6c\141\x62\x65\x6c" => "\x4c\102\114\137\x50\101\116\x45\114\x5f\x31", "\146\151\x65\x6c\144\163" => array(0 => array("\x6e\141\155\x65" => "\144\141\x74\145\137\145\x6e\x74\145\x72\x65\x64", "\x65\x6e\141\x62\x6c\x65\144" => true, "\144\x65\146\x61\x75\154\x74" => true), 1 => array("\x6e\141\x6d\x65" => "\x72\x65\154\141\x74\145\144\137\144\x75\x70\154\151\143\x61\x74\x65\x5f\x6d\157\144\165\154\x65", "\x6c\x61\x62\x65\x6c" => "\x4c\x42\114\137\x52\105\x4c\101\x54\x45\x44\x5f\x44\125\120\x4c\111\103\x41\124\x45\137\115\x4f\x44\125\x4c\105", "\x65\156\x61\x62\154\x65\x64" => true, "\144\x65\146\x61\165\x6c\164" => true, "\x73\157\162\x74\x61\x62\x6c\145" => false), 2 => array("\156\x61\x6d\145" => "\x64\165\160\x6c\x69\x63\x61\164\x65\x5f\x72\x65\143\x6f\x72\144\137\61\137\162\x65\154\141\164\x65", "\154\x61\x62\145\x6c" => "\114\x42\x4c\137\104\x55\x50\x4c\x49\103\101\x54\105\137\122\105\x43\117\122\104\x5f\61\137\122\105\x4c\101\124\x45", "\x65\x6e\141\x62\x6c\145\144" => true, "\144\x65\146\x61\x75\x6c\164" => true, "\x72\x65\x6c\141\x74\145\144\137\x66\x69\145\x6c\x64\163" => array(0 => "\144\x75\x70\x6c\x69\x63\141\164\145\137\x72\145\x63\157\x72\x64\x5f\151\x64\x5f\x31", 1 => "\x69\x67\156\157\162\x65\x5f\160\141\151\162"), "\163\x6f\162\164\x61\142\x6c\x65" => false), 3 => array("\x6e\141\x6d\145" => "\x64\x75\160\x6c\x69\143\x61\x74\145\x5f\x72\145\x63\157\x72\144\x5f\62\x5f\162\145\154\141\x74\x65", "\154\x61\x62\145\154" => "\x4c\102\114\x5f\x44\125\120\x4c\111\x43\x41\x54\x45\x5f\122\x45\103\x4f\x52\104\x5f\62\x5f\122\105\x4c\x41\124\x45", "\x65\x6e\x61\x62\154\145\144" => true, "\144\x65\x66\141\x75\x6c\164" => true, "\x72\145\154\x61\x74\145\144\137\146\151\x65\x6c\144\163" => array(0 => "\144\165\x70\x6c\x69\x63\x61\164\145\x5f\162\145\x63\x6f\162\x64\137\151\x64\137\62"), "\x73\x6f\162\164\x61\142\x6c\x65" => false), 4 => array("\156\x61\155\x65" => "\x72\x65\154\141\x74\x65\144\137\160\x72\x6f\143\145\x73\163", "\x6c\x61\x62\x65\154" => "\x4c\x42\x4c\x5f\122\105\114\101\124\x45\x44\x5f\x50\122\x4f\103\105\x53\x53", "\x65\156\x61\142\154\x65\144" => true, "\x64\145\146\141\165\154\x74" => true, "\x72\x65\154\141\164\x65\x64\x5f\x66\151\x65\x6c\144\163" => array(0 => "\145\x33\x38\x5f\144\x75\x70\154\151\143\x61\x74\145\143\x68\145\x63\153"))))), "\157\162\x64\145\x72\x42\x79" => array("\146\151\x65\154\x64" => "\144\141\164\x65\137\x65\156\164\x65\x72\x65\144", "\x64\x69\162\145\x63\164\151\157\x6e" => "\x61\x73\x63")))));
