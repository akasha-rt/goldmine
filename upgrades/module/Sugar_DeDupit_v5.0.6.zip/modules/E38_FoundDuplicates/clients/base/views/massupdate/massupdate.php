<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\70\137\x46\157\165\156\x64\104\x75\160\x6c\151\143\x61\164\x65\x73"; $viewdefs[$module_name]["\142\x61\163\145"]["\166\x69\x65\167"]["\x6d\141\163\x73\165\x70\144\x61\164\145"] = array("\142\x75\164\x74\x6f\x6e\163" => array(array("\164\171\x70\145" => "\x62\165\x74\164\x6f\156", "\166\141\154\165\x65" => "\143\141\x6e\x63\145\154", "\x63\x73\163\137\x63\x6c\141\x73\x73" => "\x62\164\x6e\55\x6c\151\x6e\x6b\x20\142\x74\x6e\55\151\x6e\166\x69\x73\x69\x62\x6c\145\x20\143\x61\156\143\145\x6c\137\142\165\x74\x74\x6f\x6e", "\154\x61\142\145\154" => "\114\x42\x4c\137\103\x41\116\103\x45\x4c\137\102\125\x54\x54\117\116\137\114\x41\102\x45\x4c", "\160\162\151\155\141\162\171" => false), array("\x6e\141\155\x65" => "\165\160\x64\x61\x74\x65\x5f\142\x75\164\x74\157\156", "\x74\x79\x70\145" => "\x62\165\x74\x74\x6f\156", "\x6c\x61\x62\145\154" => "\114\102\114\x5f\125\x50\104\101\x54\105", "\141\x63\154\137\x61\x63\164\x69\157\156" => "\x6d\141\x73\163\x75\x70\144\x61\x74\145", "\x63\163\x73\137\x63\154\x61\163\163" => "\x62\x74\x6e\x2d\160\x72\x69\155\x61\162\171", "\160\162\x69\155\141\x72\171" => true)), "\x70\141\x6e\145\x6c\163" => array(array("\146\x69\145\x6c\x64\x73" => array())));
