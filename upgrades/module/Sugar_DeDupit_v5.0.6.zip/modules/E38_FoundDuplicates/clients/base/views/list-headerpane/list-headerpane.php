<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\x45\63\x38\x5f\106\x6f\165\x6e\144\x44\x75\x70\x6c\151\x63\141\x74\145\x73"]["\142\x61\x73\145"]["\166\151\x65\x77"]["\154\151\163\x74\x2d\x68\x65\141\144\x65\162\x70\141\156\145"] = array("\146\151\x65\154\144\x73" => array(array("\156\141\155\x65" => "\164\151\x74\x6c\x65", "\x74\x79\160\x65" => "\154\x61\142\x65\154", "\144\145\x66\x61\x75\x6c\x74\137\x76\x61\x6c\x75\145" => "\x4c\x42\114\x5f\x46\117\x55\x4e\104\x5f\x44\x55\120\137\x50\101\x49\x52\x53"), array("\x6e\141\x6d\145" => "\143\x6f\x6c\x6c\x65\x63\x74\151\157\x6e\55\x63\157\x75\x6e\x74", "\x74\x79\x70\x65" => "\143\157\154\154\x65\x63\x74\151\x6f\x6e\55\x63\157\x75\x6e\164")), "\x62\x75\164\164\x6f\156\163" => array(array("\156\x61\155\145" => "\x73\151\x64\145\142\x61\162\137\x74\x6f\x67\147\x6c\145", "\x74\171\160\x65" => "\163\x69\144\x65\142\141\x72\x74\157\x67\147\x6c\145")));
