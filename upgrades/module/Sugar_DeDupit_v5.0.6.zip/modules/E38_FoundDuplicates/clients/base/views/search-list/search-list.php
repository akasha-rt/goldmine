<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\x5f\106\x6f\x75\156\144\x44\165\160\x6c\151\x63\141\x74\145\x73"; $viewdefs[$module_name]["\142\x61\163\145"]["\x76\151\145\x77"]["\x73\145\141\x72\143\x68\55\x6c\x69\163\164"] = array("\x70\x61\156\145\154\163" => array(array("\x6e\x61\155\x65" => "\x70\x72\151\x6d\x61\162\x79", "\146\x69\145\x6c\x64\163" => array(array("\156\141\155\x65" => "\160\151\143\164\165\x72\x65", "\x74\171\x70\145" => "\141\166\141\x74\x61\x72", "\163\151\x7a\x65" => "\155\x65\144\x69\x75\155", "\x72\145\141\144\x6f\x6e\x6c\171" => true, "\143\x73\x73\x5f\143\x6c\141\x73\163" => "\x70\165\154\x6c\x2d\x6c\x65\x66\164"), array("\156\x61\155\145" => "\x6e\141\x6d\x65", "\164\x79\x70\x65" => "\x6e\x61\155\145", "\154\x69\x6e\x6b" => true, "\154\x61\142\145\x6c" => "\x4c\102\114\137\x53\x55\102\x4a\105\103\124")))));
