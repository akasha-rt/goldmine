<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\x45\x33\70\x5f\106\157\165\x6e\x64\x44\165\160\x6c\151\143\x61\x74\x65\x73"]["\x62\141\x73\145"]["\166\x69\145\167"]["\144\x65\144\x75\x70\151\x74\55\x73\164\x61\164\x69\163\x74\151\143\55\144\141\163\150\x6c\145\164"] = array("\x64\141\163\x68\154\x65\164\163" => array(array("\x6c\141\142\x65\154" => "\114\x42\114\137\x45\x33\70\x5f\104\105\104\x55\x50\111\x54\x5f\123\x54\x41\x54\x49\123\x54\x49\103\137\x44\x41\123\110\114\x45\x54", "\144\145\163\143\162\151\x70\164\x69\157\x6e" => "\x4c\102\114\x5f\105\63\70\x5f\104\x45\104\x55\x50\x49\x54\x5f\x53\124\x41\124\x49\123\124\x49\x43\137\104\101\x53\110\x4c\105\x54\137\104\105\x53\103\122\x49\120\x54\x49\x4f\116", "\x63\157\156\x66\x69\147" => array(), "\x66\x69\154\164\x65\162" => array("\x6d\x6f\x64\165\154\145" => array("\105\x33\70\137\x46\157\165\x6e\x64\x44\165\x70\154\x69\143\141\x74\x65\163"), "\x76\x69\145\167" => "\x72\145\143\157\x72\x64\163"))));
