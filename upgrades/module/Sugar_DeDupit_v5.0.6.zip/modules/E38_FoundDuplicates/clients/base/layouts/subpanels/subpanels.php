<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\147\141\162\105\156\164\162\171") || !sugarEntry)) { goto yZh4G; } die("\116\x6f\164\40\x41\40\x56\141\154\151\x64\40\x45\x6e\164\162\x79\40\120\x6f\x69\156\x74"); yZh4G: $viewdefs["\x45\x33\x38\x5f\106\x6f\x75\156\144\104\x75\x70\154\x69\143\141\x74\x65\x73"]["\x62\x61\163\x65"]["\x6c\141\x79\x6f\x75\164"]["\x73\165\142\x70\x61\156\x65\x6c\x73"] = array("\143\x6f\x6d\160\x6f\x6e\x65\156\164\x73" => array(array("\154\141\171\157\x75\164" => "\163\x75\x62\x70\141\156\x65\154", "\x6c\141\x62\x65\154" => "\x4c\102\x4c\137\104\x55\120\x4c\111\x43\x41\x54\105\x5f\103\110\x45\103\x4b", "\x6f\166\145\x72\162\151\x64\145\x5f\163\x75\x62\x70\x61\156\145\154\x5f\154\151\163\164\137\x76\151\x65\167" => "\x73\165\x62\x70\x61\156\145\154\x2d\146\x6f\162\x2d\145\63\70\x5f\146\x6f\165\x6e\144\144\165\x70\x6c\151\143\x61\x74\145\163", "\x63\157\x6e\x74\x65\170\164" => array("\x6c\151\156\x6b" => "\x45\x33\70\137\x44\165\x70\x6c\151\x63\x61\x74\145\103\x68\x65\143\153"))), "\164\x79\160\x65" => "\x73\x75\x62\x70\141\156\x65\154\163", "\163\160\x61\156" => 12);
