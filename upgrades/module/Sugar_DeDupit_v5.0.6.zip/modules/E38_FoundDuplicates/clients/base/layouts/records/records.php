<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\105\63\x38\137\106\157\165\156\x64\104\165\x70\154\x69\143\x61\x74\x65\x73"]["\x62\141\163\145"]["\154\x61\171\x6f\165\164"]["\x72\145\x63\157\162\144\x73"] = array("\143\157\155\x70\157\x6e\145\x6e\x74\163" => array(array("\x6c\x61\x79\x6f\x75\x74" => array("\x74\x79\160\145" => "\x64\x65\146\141\165\154\x74", "\x6e\141\x6d\x65" => "\x73\151\144\x65\x62\x61\x72", "\143\x6f\x6d\160\x6f\x6e\145\156\x74\163" => array(array("\x6c\x61\x79\x6f\x75\x74" => array("\164\171\160\145" => "\x62\x61\163\x65", "\x6e\141\x6d\x65" => "\x6d\141\151\x6e\x2d\x70\x61\x6e\145", "\x63\163\163\137\x63\x6c\x61\163\x73" => "\x6d\x61\151\x6e\55\160\x61\156\145\x20\x73\160\141\x6e\x38", "\x63\x6f\x6d\x70\157\x6e\x65\x6e\x74\163" => array(array("\166\x69\145\167" => "\154\151\x73\164\55\150\x65\141\x64\145\x72\160\141\x6e\x65"), array("\x76\151\x65\x77" => "\x70\162\x6f\x63\x65\x73\163\145\163\x2d\146\x69\x6c\x74\145\162"), array("\154\141\x79\157\x75\164" => array("\x63\157\155\x70\157\156\x65\x6e\x74\163" => array(array("\x6c\x61\171\x6f\165\x74" => "\x6c\x69\163\164"))))))), array("\x6c\x61\171\157\x75\164" => array("\164\171\160\145" => "\142\141\x73\x65", "\x6e\141\155\145" => "\x64\141\163\150\x62\157\x61\162\144\55\160\x61\156\145", "\143\x73\163\x5f\x63\x6c\141\163\163" => "\144\x61\x73\x68\x62\157\141\x72\x64\55\x70\141\156\145", "\x63\157\x6d\x70\157\x6e\x65\x6e\x74\163" => array(array("\154\x61\171\157\165\x74" => array("\164\x79\160\x65" => "\x64\x61\163\x68\x62\157\141\x72\144", "\x6c\141\163\x74\137\163\x74\141\x74\x65" => array("\x69\x64" => "\x6c\141\163\x74\55\x76\x69\163\151\164")), "\143\157\x6e\x74\145\170\x74" => array("\146\157\162\x63\x65\116\145\x77" => true, "\155\157\144\165\x6c\145" => "\x48\157\155\145"), "\x6c\x6f\141\x64\115\157\x64\x75\x6c\x65" => "\x44\141\163\x68\142\x6f\x61\162\144\163")))), array("\154\x61\171\157\x75\x74" => array("\164\171\160\x65" => "\x62\x61\163\145", "\x6e\x61\x6d\145" => "\x70\162\145\x76\x69\x65\x77\x2d\160\x61\x6e\x65", "\143\163\163\137\x63\154\x61\163\163" => "\160\162\x65\166\x69\x65\x77\55\x70\141\156\145", "\143\x6f\x6d\x70\x6f\156\145\156\164\x73" => array(array("\154\x61\x79\157\x75\164" => "\x70\162\145\166\x69\x65\167", "\x78\x6d\x65\x74\x61" => array("\145\x64\151\164\141\142\154\x65" => true))))))))));
