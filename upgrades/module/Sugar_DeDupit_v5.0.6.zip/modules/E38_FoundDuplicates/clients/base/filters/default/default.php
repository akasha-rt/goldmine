<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\137\x46\157\x75\156\144\x44\165\160\x6c\x69\143\141\x74\145\163"; $viewdefs[$module_name]["\142\141\163\145"]["\146\x69\154\164\x65\x72"]["\x64\x65\x66\141\165\154\164"] = array("\x64\145\x66\141\165\154\x74\x5f\x66\x69\154\x74\x65\162" => "\x61\154\154\x5f\162\145\143\157\162\x64\163", "\x66\151\145\x6c\x64\163" => array("\x6e\x61\155\145" => array(), "\164\x61\147" => array(), "\141\x73\163\151\147\156\x65\144\137\x75\163\145\162\137\156\141\155\145" => array(), "\44\157\167\156\x65\x72" => array("\x70\162\x65\144\145\x66\x69\156\x65\144\x5f\x66\151\154\164\145\162" => true, "\166\156\x61\155\x65" => "\x4c\x42\x4c\137\x43\125\122\x52\x45\116\x54\x5f\125\x53\105\x52\137\106\111\x4c\124\105\122"), "\x24\x66\x61\166\157\162\x69\164\145" => array("\x70\x72\x65\144\x65\x66\x69\156\x65\x64\137\x66\151\154\x74\x65\x72" => true, "\x76\x6e\x61\x6d\145" => "\114\x42\x4c\137\x46\101\126\117\122\x49\124\105\123\x5f\x46\x49\x4c\124\x45\x52")));
