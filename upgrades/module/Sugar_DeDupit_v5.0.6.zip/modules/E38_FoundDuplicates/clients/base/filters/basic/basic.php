<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\147\x61\162\x45\x6e\x74\162\x79") || !sugarEntry)) { goto DWD0x; } die("\x4e\157\164\x20\x41\40\x56\x61\x6c\x69\x64\40\105\x6e\164\x72\x79\x20\x50\x6f\x69\156\164"); DWD0x: $viewdefs["\105\63\x38\137\106\x6f\165\156\144\x44\x75\160\154\151\143\x61\x74\x65\x73"]["\x62\141\163\x65"]["\x66\151\x6c\164\x65\162"]["\142\141\163\x69\x63"] = array("\x63\162\145\x61\x74\x65" => true, "\161\x75\151\143\153\163\145\x61\162\143\x68\x5f\146\x69\x65\x6c\144" => array("\x6e\141\x6d\x65"), "\161\165\x69\143\153\x73\x65\x61\x72\x63\150\137\160\x72\x69\x6f\162\x69\x74\171" => 1, "\x71\x75\151\x63\x6b\163\145\141\162\143\x68\x5f\163\x70\x6c\151\164\x5f\164\145\x72\155\163" => false, "\146\151\x6c\x74\x65\162\x73" => array(array("\x69\144" => "\x61\154\x6c\137\x72\x65\x63\x6f\x72\144\x73", "\x6e\141\155\x65" => "\x4c\x42\x4c\x5f\x4c\x49\123\124\126\x49\105\x57\137\106\x49\114\124\105\x52\137\x41\114\x4c", "\x66\x69\x6c\164\145\x72\x5f\144\x65\x66\x69\x6e\x69\164\151\x6f\156" => array(), "\145\144\151\164\x61\142\x6c\x65" => false), array("\x69\144" => "\x61\x73\163\x69\x67\156\x65\144\137\x74\157\137\155\x65", "\x6e\x61\155\145" => "\114\x42\114\137\101\123\x53\x49\107\116\x45\x44\137\124\117\137\x4d\x45", "\146\x69\154\x74\145\162\137\x64\x65\x66\151\156\151\164\x69\x6f\x6e" => array("\x24\157\167\x6e\145\x72" => ''), "\145\x64\x69\x74\x61\x62\x6c\x65" => false), array("\x69\x64" => "\x66\x61\166\x6f\162\x69\x74\145\163", "\156\141\155\x65" => "\114\x42\114\137\x46\x41\x56\117\x52\111\124\x45\x53", "\146\151\154\164\145\162\x5f\144\x65\x66\151\x6e\x69\x74\x69\157\x6e" => array("\44\x66\141\x76\x6f\162\x69\164\x65" => ''), "\x65\144\x69\x74\x61\x62\154\145" => false), array("\151\144" => "\162\x65\x63\145\x6e\164\154\171\137\166\151\145\167\145\144", "\x6e\x61\x6d\145" => "\114\102\114\x5f\x52\105\x43\105\116\x54\114\x59\137\126\111\105\127\x45\104", "\146\151\x6c\x74\145\162\x5f\144\x65\146\151\x6e\x69\164\151\157\156" => array("\44\164\x72\x61\143\153\145\x72" => "\x2d\x37\40\x44\101\131"), "\x65\144\x69\164\141\142\154\x65" => false), array("\151\144" => "\x72\x65\143\145\x6e\x74\x6c\x79\x5f\143\x72\x65\x61\x74\x65\x64", "\x6e\141\155\x65" => "\114\102\114\x5f\x4e\x45\127\137\122\105\103\x4f\x52\x44\123", "\146\x69\154\x74\145\162\137\144\x65\146\x69\156\x69\164\x69\x6f\156" => array("\144\x61\x74\145\x5f\x65\156\164\x65\162\x65\x64" => array("\44\144\141\164\x65\122\x61\156\147\x65" => "\x6c\x61\x73\164\x5f\67\137\144\141\x79\x73")), "\x65\144\151\x74\x61\142\154\x65" => false)));
