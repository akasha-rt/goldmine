<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\137\x46\x6f\x75\156\x64\x44\x75\x70\154\151\x63\x61\x74\x65\x73"; $viewdefs[$module_name]["\155\x6f\142\x69\154\x65"]["\x76\x69\x65\167"]["\x64\x65\x74\141\x69\154"] = array("\164\145\x6d\x70\154\141\164\x65\115\145\164\141" => array("\146\157\162\x6d" => array("\x62\165\x74\164\157\x6e\x73" => array("\x45\104\x49\x54", "\x44\x55\120\114\111\103\101\x54\x45", "\104\x45\x4c\105\124\105")), "\155\x61\x78\103\x6f\x6c\165\155\x6e\x73" => "\x31", "\x77\151\x64\164\150\163" => array(array("\154\141\x62\145\x6c" => "\61\x30", "\x66\151\x65\x6c\x64" => "\63\x30"), array("\x6c\x61\142\145\154" => "\61\x30", "\146\151\x65\154\x64" => "\63\60"))), "\160\141\x6e\x65\x6c\x73" => array(array("\x6c\x61\x62\x65\x6c" => "\114\x42\114\137\120\x41\x4e\105\114\137\104\105\x46\101\125\x4c\x54", "\146\151\145\154\144\163" => array("\156\141\155\145", "\x61\x73\x73\x69\x67\x6e\x65\144\x5f\x75\163\145\x72\x5f\156\141\155\x65", "\164\x65\x61\x6d\137\x6e\x61\x6d\x65"))));
