<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\147\141\162\x45\156\x74\162\171") || !sugarEntry)) { goto H3men; } die("\116\157\x74\40\101\x20\126\x61\154\151\144\x20\105\156\164\x72\x79\40\120\157\x69\x6e\164"); H3men: $module_name = "\105\x33\x38\x5f\106\157\165\x6e\x64\x44\165\x70\x6c\151\x63\x61\x74\145\163"; $viewdefs[$module_name]["\155\x6f\142\151\x6c\x65"]["\166\151\x65\167"]["\x6c\x69\x73\x74"] = array("\x70\141\x6e\x65\154\x73" => array(array("\154\x61\x62\145\154" => "\114\x42\x4c\x5f\x50\x41\116\x45\x4c\x5f\x44\x45\106\101\x55\114\x54", "\146\x69\145\154\144\163" => array(array("\156\141\x6d\x65" => "\156\141\x6d\x65", "\154\x61\x62\x65\x6c" => "\x4c\102\x4c\137\116\101\115\105", "\144\x65\x66\x61\165\154\164" => true, "\145\156\141\142\154\x65\144" => true, "\154\151\x6e\153" => true), array("\x6e\x61\x6d\x65" => "\164\x65\x61\155\x5f\x6e\x61\x6d\145", "\x6c\141\142\x65\154" => "\114\102\114\137\124\x45\x41\x4d", "\144\x65\x66\x61\165\x6c\x74" => true, "\x65\x6e\141\142\x6c\x65\144" => true), array("\x6e\x61\155\x65" => "\141\163\x73\151\x67\x6e\x65\144\x5f\x75\163\145\x72\137\156\x61\155\x65", "\154\141\x62\145\154" => "\x4c\x42\114\x5f\101\123\123\111\107\116\x45\x44\x5f\124\117\x5f\116\101\115\x45", "\x64\x65\x66\141\165\154\164" => true, "\x65\156\x61\142\x6c\145\x64" => true, "\154\x69\156\153" => true)))));
