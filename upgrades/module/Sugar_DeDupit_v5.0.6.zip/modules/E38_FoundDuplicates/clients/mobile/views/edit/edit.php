<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\70\137\106\157\165\x6e\144\x44\x75\x70\x6c\x69\143\x61\x74\x65\163"; $viewdefs[$module_name]["\155\x6f\x62\x69\x6c\145"]["\166\151\x65\x77"]["\x65\144\x69\164"] = array("\164\145\x6d\x70\154\x61\164\145\x4d\x65\164\x61" => array("\155\x61\170\103\x6f\154\x75\155\x6e\x73" => "\x31", "\167\151\144\164\150\163" => array(array("\154\141\142\x65\154" => "\61\x30", "\x66\x69\145\154\x64" => "\x33\60"), array("\x6c\x61\x62\145\154" => "\x31\x30", "\146\151\145\154\144" => "\63\60"))), "\x70\x61\x6e\x65\x6c\x73" => array(array("\x6c\141\142\145\154" => "\x4c\x42\x4c\x5f\x50\x41\x4e\x45\114\137\104\105\106\x41\x55\x4c\x54", "\146\151\145\154\144\163" => array("\156\141\155\145", "\141\x73\x73\151\147\x6e\145\144\137\165\x73\x65\x72\x5f\x6e\x61\x6d\x65", "\164\x65\141\155\137\x6e\x61\x6d\145"))));
