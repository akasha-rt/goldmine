<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\x38\137\106\157\x75\156\144\104\165\x70\154\151\143\141\164\x65\x73"; $viewdefs[$module_name]["\x51\165\x69\x63\x6b\103\x72\145\141\164\x65"] = array("\164\x65\x6d\x70\154\x61\164\x65\x4d\x65\164\x61" => array("\155\x61\170\103\157\x6c\165\x6d\156\163" => "\x32", "\167\151\x64\164\150\x73" => array(array("\x6c\141\142\145\154" => "\61\x30", "\x66\x69\145\x6c\x64" => "\63\x30"), array("\x6c\x61\x62\x65\154" => "\61\60", "\x66\x69\145\x6c\x64" => "\x33\x30"))), "\x70\141\156\x65\154\x73" => array("\x64\145\x66\141\165\x6c\x74" => array(array("\x6e\x61\155\145", "\x61\163\163\x69\x67\x6e\145\144\x5f\x75\163\145\x72\137\156\x61\155\x65"), array("\144\145\x73\143\162\x69\x70\x74\x69\x6f\156", array("\156\141\155\145" => "\x74\x65\x61\155\137\156\x61\x6d\145", "\144\151\x73\160\x6c\x61\171\120\x61\x72\x61\155\163" => array("\x64\x69\x73\x70\154\x61\171" => true))))));
