<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\x38\137\x46\157\165\x6e\x64\104\x75\160\x6c\x69\143\x61\x74\x65\163"; $metafiles[$module_name] = array("\144\145\164\x61\x69\x6c\166\151\x65\167\x64\145\x66\163" => "\155\157\x64\165\154\145\x73\x2f" . $module_name . "\x2f\x6d\x65\x74\141\x64\x61\x74\x61\57\x64\145\164\141\x69\x6c\166\x69\145\x77\144\x65\146\x73\x2e\160\x68\160", "\145\x64\x69\x74\x76\151\x65\167\x64\x65\x66\163" => "\155\157\x64\165\154\x65\x73\57" . $module_name . "\57\x6d\x65\x74\141\x64\141\164\141\57\145\x64\x69\164\x76\x69\145\167\144\x65\x66\163\x2e\160\x68\x70", "\154\x69\163\164\166\151\x65\x77\144\x65\146\x73" => "\x6d\x6f\144\165\154\x65\163\57" . $module_name . "\57\155\x65\164\x61\x64\x61\x74\141\57\154\151\163\x74\166\151\145\x77\144\145\146\163\56\x70\x68\x70", "\163\145\141\162\143\150\x64\x65\x66\163" => "\155\157\x64\x75\x6c\x65\x73\57" . $module_name . "\57\x6d\145\x74\141\144\x61\164\x61\57\x73\x65\141\x72\x63\150\144\145\146\x73\56\x70\150\160", "\x70\x6f\x70\x75\x70\144\x65\x66\163" => "\x6d\x6f\144\x75\154\x65\x73\57" . $module_name . "\x2f\155\145\x74\x61\x64\x61\x74\x61\57\x70\157\x70\165\x70\x64\145\146\163\56\x70\x68\160", "\163\x65\x61\162\143\x68\146\x69\x65\154\x64\163" => "\x6d\x6f\x64\165\154\x65\163\57" . $module_name . "\x2f\x6d\x65\x74\141\144\x61\164\x61\57\123\x65\x61\x72\x63\150\106\151\145\x6c\x64\163\x2e\160\x68\160");
