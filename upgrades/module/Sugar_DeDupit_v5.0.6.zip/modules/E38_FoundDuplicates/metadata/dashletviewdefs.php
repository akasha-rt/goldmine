<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\x67\141\x72\105\156\164\162\x79") || !sugarEntry)) { goto a3vy2; } die("\116\x6f\x74\40\101\40\126\x61\x6c\x69\x64\x20\x45\156\164\x72\171\x20\x50\157\x69\156\x74"); a3vy2: global $current_user; $dashletData["\x45\63\x38\x5f\x46\157\x75\156\x64\x44\165\x70\154\151\x63\141\x74\145\x73\104\141\x73\x68\x6c\x65\164"]["\163\x65\x61\x72\x63\150\106\x69\x65\154\x64\x73"] = array("\x64\x61\164\x65\x5f\145\156\x74\x65\162\145\144" => array("\144\x65\x66\141\x75\x6c\x74" => ''), "\144\141\164\x65\137\x6d\x6f\144\x69\146\151\145\x64" => array("\x64\145\146\141\165\154\x74" => ''), "\x74\x65\x61\x6d\137\151\144" => array("\x64\145\146\x61\165\154\x74" => ''), "\x61\x73\x73\151\147\156\145\x64\x5f\165\x73\145\162\137\151\144" => array("\164\171\x70\145" => "\x61\163\163\151\147\x6e\x65\144\137\x75\x73\x65\x72\137\156\x61\155\145", "\x64\x65\x66\141\165\154\164" => $current_user->name)); $dashletData["\105\63\x38\x5f\x46\x6f\x75\x6e\144\x44\165\160\x6c\151\143\x61\164\145\x73\104\141\163\150\154\145\x74"]["\143\157\154\165\155\x6e\x73"] = array("\156\x61\155\x65" => array("\167\151\144\164\x68" => "\x34\60", "\x6c\141\x62\145\x6c" => "\114\102\114\137\x4c\x49\123\x54\x5f\x4e\x41\x4d\x45", "\x6c\x69\156\x6b" => true, "\144\x65\146\141\165\x6c\164" => true), "\x64\141\164\x65\x5f\x65\x6e\x74\x65\162\x65\x64" => array("\167\x69\x64\164\150" => "\61\x35", "\x6c\141\142\145\x6c" => "\x4c\x42\x4c\137\x44\101\124\x45\x5f\x45\x4e\x54\105\x52\105\x44", "\x64\145\146\141\165\x6c\x74" => true), "\144\141\164\145\x5f\155\157\144\151\146\x69\145\144" => array("\167\x69\x64\164\x68" => "\x31\x35", "\x6c\x61\x62\145\x6c" => "\x4c\102\114\x5f\104\101\x54\105\x5f\115\x4f\x44\x49\106\x49\105\104"), "\x63\162\145\x61\x74\145\x64\137\x62\171" => array("\167\x69\144\x74\150" => "\70", "\x6c\141\142\x65\x6c" => "\x4c\x42\x4c\137\103\122\105\101\x54\105\x44"), "\x61\163\x73\151\147\x6e\145\x64\137\x75\163\x65\162\137\156\x61\155\145" => array("\167\x69\144\x74\x68" => "\x38", "\154\x61\x62\145\154" => "\x4c\x42\x4c\x5f\x4c\x49\123\124\x5f\101\123\x53\111\107\116\x45\x44\x5f\x55\x53\105\x52"), "\164\x65\141\155\137\156\x61\x6d\145" => array("\x77\151\144\164\x68" => "\x31\65", "\154\141\x62\x65\x6c" => "\x4c\x42\x4c\137\x4c\x49\x53\124\x5f\124\x45\x41\115"));
