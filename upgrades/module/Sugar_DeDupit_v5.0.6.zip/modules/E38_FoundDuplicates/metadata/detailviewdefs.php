<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\70\137\x46\157\x75\x6e\144\x44\165\x70\154\x69\143\141\164\x65\x73"; $viewdefs[$module_name]["\104\145\164\141\x69\154\x56\151\145\x77"] = array("\x74\145\x6d\x70\x6c\141\x74\x65\x4d\145\x74\x61" => array("\146\157\162\x6d" => array("\x62\165\164\x74\157\156\163" => array("\x45\104\111\124", "\104\125\x50\114\x49\103\x41\124\105", "\x44\x45\x4c\x45\x54\x45", "\106\x49\116\104\137\x44\x55\x50\x4c\111\103\x41\x54\105\123")), "\x6d\141\x78\x43\157\154\x75\x6d\156\x73" => "\x32", "\167\x69\144\x74\x68\x73" => array(array("\154\x61\142\x65\154" => "\x31\x30", "\x66\151\145\154\x64" => "\x33\60"), array("\x6c\x61\142\x65\154" => "\61\60", "\x66\151\x65\x6c\144" => "\x33\x30"))), "\160\141\156\x65\154\x73" => array(array("\x6e\x61\x6d\145", "\141\163\163\x69\x67\x6e\x65\x64\137\x75\x73\145\x72\137\156\141\x6d\x65"), array("\x74\145\141\155\x5f\156\141\155\145", ''), array(array("\156\141\155\145" => "\144\x61\x74\x65\137\145\156\164\145\x72\145\x64", "\143\165\163\164\157\155\103\x6f\144\145" => "\x7b\44\146\151\145\154\144\x73\x2e\144\x61\164\x65\x5f\145\156\x74\145\162\x65\x64\56\166\x61\154\165\x65\x7d\x20\x7b\x24\x41\120\x50\x2e\x4c\102\114\x5f\x42\131\x7d\x20\173\x24\x66\x69\145\x6c\144\x73\56\143\x72\x65\141\x74\145\144\137\142\x79\137\156\x61\155\145\x2e\x76\141\x6c\x75\x65\x7d", "\x6c\141\x62\x65\154" => "\x4c\102\x4c\137\104\x41\124\105\137\105\x4e\x54\105\122\105\x44"), array("\156\x61\155\145" => "\x64\x61\x74\x65\137\x6d\x6f\x64\151\x66\x69\x65\144", "\143\x75\x73\164\x6f\x6d\103\x6f\144\x65" => "\173\44\146\151\x65\x6c\144\x73\56\x64\141\164\145\x5f\155\157\x64\151\x66\x69\x65\x64\56\166\141\x6c\165\x65\175\40\173\x24\x41\120\120\x2e\114\102\x4c\137\102\x59\175\x20\x7b\x24\x66\151\145\154\x64\x73\x2e\x6d\157\144\x69\x66\x69\x65\144\137\142\171\x5f\156\x61\x6d\x65\56\x76\x61\154\x75\145\x7d", "\x6c\x61\x62\x65\x6c" => "\x4c\102\114\137\104\101\124\x45\x5f\x4d\x4f\104\x49\x46\111\x45\x44")), array("\x64\145\x73\x63\x72\x69\x70\164\x69\x6f\x6e")));
