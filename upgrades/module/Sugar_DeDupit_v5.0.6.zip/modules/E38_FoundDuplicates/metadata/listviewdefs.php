<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\x67\141\x72\105\x6e\164\162\x79") || !sugarEntry)) { goto Cqh5R; } die("\x4e\157\164\40\x41\40\x56\x61\154\151\x64\x20\x45\156\x74\x72\x79\40\120\x6f\x69\156\x74"); Cqh5R: $module_name = "\105\x33\x38\x5f\x46\x6f\x75\x6e\x64\x44\165\160\x6c\151\143\141\164\x65\x73"; $listViewDefs[$module_name] = array("\x4e\101\115\x45" => array("\x77\151\x64\x74\x68" => "\x33\x32", "\x6c\x61\x62\x65\x6c" => "\114\x42\x4c\x5f\x4e\x41\115\105", "\x64\145\x66\141\x75\154\x74" => true, "\154\151\x6e\153" => true), "\x54\x45\101\x4d\137\x4e\x41\x4d\x45" => array("\x77\151\144\164\x68" => "\71", "\154\x61\142\x65\154" => "\x4c\102\114\x5f\x54\x45\x41\115", "\144\145\x66\141\x75\x6c\x74" => false), "\101\x53\x53\111\x47\116\105\x44\137\x55\123\x45\x52\137\x4e\101\115\105" => array("\167\x69\144\x74\x68" => "\71", "\x6c\141\x62\x65\154" => "\114\x42\x4c\x5f\101\123\x53\111\107\x4e\x45\104\x5f\x54\117\x5f\116\101\x4d\105", "\155\x6f\144\x75\154\145" => "\x45\x6d\160\154\157\171\x65\x65\163", "\151\144" => "\x41\123\123\111\107\x4e\105\x44\x5f\x55\x53\x45\122\137\111\104", "\x64\145\x66\x61\165\154\x74" => true));
