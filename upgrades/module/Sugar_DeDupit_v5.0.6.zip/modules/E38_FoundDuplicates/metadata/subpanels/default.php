<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\x75\x67\x61\162\105\x6e\164\162\x79") || !sugarEntry)) { goto LvVKP; } die("\116\x6f\164\40\101\40\x56\141\x6c\151\144\40\105\x6e\x74\x72\x79\40\120\x6f\x69\156\164"); LvVKP: $module_name = "\x45\63\70\137\x46\x6f\x75\156\144\104\x75\160\154\x69\143\x61\164\145\163"; $subpanel_layout = array("\x74\157\160\137\x62\165\164\164\x6f\156\x73" => array(array("\167\151\144\x67\145\x74\137\143\x6c\141\x73\x73" => "\x53\x75\142\120\141\x6e\145\x6c\124\x6f\x70\103\x72\x65\x61\164\145\102\x75\x74\164\x6f\x6e"), array("\167\151\x64\x67\x65\x74\137\143\154\141\x73\x73" => "\x53\x75\142\120\x61\156\x65\154\124\x6f\x70\x53\145\154\x65\x63\x74\x42\165\164\164\157\x6e", "\160\157\160\165\x70\x5f\x6d\x6f\x64\165\x6c\x65" => $module_name)), "\x77\x68\x65\162\x65" => '', "\154\x69\x73\164\137\x66\151\x65\x6c\144\163" => array("\x6e\141\155\x65" => array("\166\x6e\141\x6d\145" => "\114\x42\114\x5f\x4e\101\115\x45", "\x77\x69\x64\x67\145\164\x5f\x63\x6c\x61\x73\x73" => "\123\165\142\120\141\x6e\x65\x6c\x44\145\164\141\151\154\x56\x69\x65\167\114\151\156\x6b", "\x77\151\x64\x74\x68" => "\x34\x35\x25"), "\144\x61\164\145\x5f\x6d\x6f\144\151\146\151\145\144" => array("\x76\x6e\141\x6d\x65" => "\x4c\x42\x4c\137\x44\101\124\105\x5f\115\117\x44\x49\x46\111\105\x44", "\x77\151\144\x74\x68" => "\x34\65\x25"), "\145\144\151\164\x5f\x62\x75\x74\x74\157\x6e" => array("\x76\156\x61\x6d\145" => "\114\102\x4c\x5f\105\104\x49\x54\137\x42\x55\124\x54\x4f\x4e", "\167\151\144\147\145\164\137\x63\x6c\141\163\163" => "\x53\x75\x62\x50\141\156\145\154\105\144\151\x74\x42\x75\164\x74\157\x6e", "\x6d\157\144\165\154\x65" => $module_name, "\167\151\144\164\150" => "\x34\x25"), "\162\145\155\x6f\166\x65\x5f\x62\165\x74\x74\157\156" => array("\x76\x6e\141\x6d\145" => "\x4c\102\x4c\137\122\105\115\117\126\105", "\x77\x69\x64\147\x65\164\x5f\x63\154\x61\x73\163" => "\x53\x75\142\x50\141\x6e\145\x6c\x52\x65\x6d\157\x76\x65\x42\x75\164\164\157\x6e", "\155\x6f\x64\165\154\145" => $module_name, "\x77\x69\144\164\150" => "\x35\x25")));
