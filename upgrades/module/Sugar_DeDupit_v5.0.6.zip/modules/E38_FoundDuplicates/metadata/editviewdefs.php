<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\137\106\x6f\x75\156\144\104\165\x70\x6c\x69\x63\141\x74\x65\163"; $viewdefs[$module_name]["\x45\144\151\x74\x56\x69\145\167"] = array("\x74\x65\155\x70\x6c\141\x74\x65\x4d\145\x74\x61" => array("\x6d\x61\170\103\157\x6c\x75\x6d\156\x73" => "\x32", "\x77\x69\144\x74\150\x73" => array(array("\154\x61\x62\x65\154" => "\x31\x30", "\146\x69\145\154\x64" => "\x33\60"), array("\x6c\141\142\145\x6c" => "\x31\x30", "\146\x69\145\x6c\144" => "\x33\x30"))), "\160\x61\156\x65\x6c\163" => array("\144\x65\146\x61\x75\154\164" => array(array("\x6e\x61\155\145", "\141\x73\163\151\147\156\145\144\x5f\165\163\x65\x72\137\156\141\x6d\145"), array(array("\156\x61\155\145" => "\164\145\x61\155\x5f\156\141\155\145", "\x64\151\x73\x70\154\141\171\120\141\162\141\155\x73" => array("\x64\151\163\160\x6c\141\171" => true)), ''), array("\144\145\163\x63\162\x69\160\x74\151\157\x6e"))));
