<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\147\141\x72\105\x6e\x74\x72\x79") || !sugarEntry)) { goto GO2JJ; } die("\116\157\x74\40\101\40\126\x61\154\x69\x64\40\105\x6e\x74\x72\171\40\x50\157\151\156\164"); GO2JJ: $module_name = "\x45\63\x38\x5f\106\x6f\x75\x6e\x64\104\165\160\154\x69\x63\141\x74\145\x73"; $searchFields[$module_name] = array("\x6e\141\x6d\145" => array("\161\165\145\162\x79\137\x74\171\160\x65" => "\144\145\146\141\165\154\x74"), "\143\x75\x72\162\145\x6e\x74\137\165\163\x65\x72\x5f\x6f\x6e\154\171" => array("\161\165\145\x72\x79\137\164\x79\x70\x65" => "\144\145\x66\141\165\x6c\164", "\144\142\x5f\x66\151\145\154\x64" => array("\141\x73\163\x69\147\156\145\144\x5f\165\x73\145\162\x5f\151\144"), "\155\171\x5f\151\x74\145\155\x73" => true, "\166\x6e\141\x6d\145" => "\x4c\102\114\137\x43\125\122\x52\105\116\x54\x5f\x55\123\105\122\x5f\106\111\x4c\124\105\x52", "\164\171\160\x65" => "\x62\x6f\157\154"), "\141\x73\x73\151\147\x6e\145\144\137\x75\x73\145\162\137\151\x64" => array("\x71\x75\145\x72\171\137\164\171\160\x65" => "\x64\145\x66\141\165\154\164"), "\x66\x61\166\157\x72\151\x74\x65\163\137\x6f\156\x6c\x79" => array("\161\x75\x65\162\171\137\x74\171\160\145" => "\x66\x6f\x72\155\x61\x74", "\x6f\x70\145\162\x61\164\x6f\x72" => "\x73\165\142\x71\x75\145\162\171", "\163\165\142\161\x75\x65\x72\x79" => "\123\x45\x4c\x45\103\124\40\163\165\x67\x61\x72\x66\141\166\157\x72\151\x74\145\163\56\162\x65\143\x6f\162\x64\137\x69\144\40\106\122\117\115\x20\163\165\147\x61\162\146\x61\x76\x6f\162\151\164\145\x73\x20\12\x9\x9\x9\40\x20\x20\40\x20\x20\40\40\x20\40\x20\x20\40\40\x20\x20\40\40\40\40\127\x48\x45\x52\105\x20\163\x75\x67\x61\x72\x66\x61\166\157\162\x69\x74\145\163\56\x64\145\x6c\x65\x74\x65\144\x3d\x30\40\12\11\x9\x9\x20\40\40\x20\x20\x20\x20\40\40\40\40\x20\x20\40\40\40\40\x20\40\x20\x20\x20\x20\x20\141\156\144\x20\163\x75\147\141\x72\x66\141\166\x6f\162\151\164\x65\163\x2e\155\x6f\144\x75\154\145\x20\75\x20\47" . $module_name . "\x27\xa\11\x9\11\40\40\40\40\x20\x20\x20\x20\x20\x20\40\x20\x20\40\40\40\x20\40\40\x20\40\x20\x20\40\141\x6e\144\40\x73\165\147\x61\x72\x66\x61\x76\157\x72\x69\164\145\x73\x2e\x61\x73\163\x69\147\x6e\x65\x64\x5f\165\163\x65\162\137\x69\x64\40\75\x20\47\x7b\60\175\47", "\144\142\137\146\x69\x65\154\144" => array("\x69\144")), "\162\x61\x6e\x67\x65\x5f\144\x61\164\145\x5f\145\x6e\x74\x65\x72\x65\x64" => array("\161\165\145\x72\171\x5f\x74\171\x70\x65" => "\144\x65\x66\141\165\154\164", "\x65\x6e\141\x62\154\x65\137\162\x61\x6e\x67\145\137\x73\145\x61\x72\x63\150" => true, "\151\x73\x5f\x64\x61\x74\x65\137\x66\x69\145\x6c\x64" => true), "\x73\x74\141\x72\x74\x5f\x72\141\156\147\145\137\144\141\164\145\x5f\145\x6e\x74\145\x72\145\144" => array("\x71\165\145\162\x79\137\164\171\160\145" => "\x64\145\146\141\x75\154\x74", "\145\x6e\141\142\154\x65\137\x72\141\x6e\147\x65\137\163\x65\141\162\143\x68" => true, "\x69\x73\137\144\x61\164\x65\x5f\146\151\145\x6c\x64" => true), "\145\x6e\x64\x5f\162\141\156\147\145\x5f\x64\141\164\145\137\x65\x6e\x74\x65\x72\x65\x64" => array("\x71\165\145\162\x79\x5f\164\x79\160\x65" => "\144\x65\146\141\165\x6c\x74", "\145\x6e\141\x62\154\x65\x5f\162\141\x6e\x67\x65\x5f\163\145\x61\162\143\150" => true, "\151\163\x5f\x64\x61\164\x65\x5f\146\x69\x65\154\144" => true), "\x72\x61\156\x67\145\x5f\x64\x61\164\x65\x5f\x6d\x6f\144\151\x66\151\145\x64" => array("\161\x75\145\162\x79\137\x74\171\x70\145" => "\144\x65\146\141\165\x6c\164", "\145\x6e\141\142\x6c\145\x5f\x72\141\156\x67\x65\137\x73\x65\x61\162\143\150" => true, "\151\x73\137\x64\x61\164\145\x5f\146\151\x65\154\144" => true), "\x73\x74\x61\x72\x74\137\x72\141\x6e\147\145\x5f\144\141\164\x65\x5f\x6d\157\x64\151\146\151\145\x64" => array("\x71\x75\145\162\171\x5f\x74\x79\x70\x65" => "\x64\x65\146\141\x75\154\164", "\x65\x6e\141\142\x6c\x65\x5f\162\141\156\147\x65\137\163\x65\141\x72\143\x68" => true, "\151\x73\137\144\141\x74\145\137\x66\151\x65\154\144" => true), "\x65\x6e\x64\x5f\x72\141\x6e\147\x65\x5f\x64\x61\x74\145\137\x6d\x6f\x64\151\x66\x69\x65\x64" => array("\161\165\x65\x72\171\137\x74\171\x70\x65" => "\x64\x65\x66\x61\165\154\164", "\145\x6e\141\142\154\145\x5f\162\x61\x6e\147\145\137\x73\145\x61\162\x63\x68" => true, "\151\163\x5f\144\x61\x74\145\137\146\x69\145\x6c\x64" => true));
