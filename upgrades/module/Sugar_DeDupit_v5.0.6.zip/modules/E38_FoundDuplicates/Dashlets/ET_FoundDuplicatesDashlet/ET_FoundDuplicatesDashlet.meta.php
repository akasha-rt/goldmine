<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\147\x61\162\x45\x6e\164\x72\x79") || !sugarEntry)) { goto osv30; } die("\116\157\x74\40\x41\40\126\141\154\151\144\x20\105\x6e\x74\x72\x79\x20\120\x6f\x69\156\x74"); osv30: global $app_strings; $dashletMeta["\105\63\x38\x5f\106\157\x75\156\144\x44\165\x70\154\151\x63\141\x74\145\163\x44\x61\x73\150\x6c\145\x74"] = array("\x6d\157\144\x75\x6c\145" => "\105\63\x38\137\x46\157\x75\x6e\x64\104\x75\160\154\x69\143\x61\164\145\163", "\164\x69\x74\x6c\x65" => translate("\x4c\102\x4c\x5f\110\x4f\115\105\x50\x41\x47\x45\137\x54\x49\124\x4c\x45", "\105\63\x38\x5f\106\157\x75\x6e\x64\x44\165\160\154\151\143\141\164\145\x73"), "\x64\145\163\143\x72\151\x70\x74\x69\x6f\x6e" => "\101\x20\143\x75\x73\x74\x6f\x6d\x69\x7a\141\142\154\145\40\166\x69\x65\167\40\x69\x6e\164\157\x20\x45\63\70\x5f\x46\157\x75\156\x64\104\165\160\154\151\143\141\164\x65\x73", "\x69\x63\x6f\156" => "\151\143\x6f\x6e\137\105\63\70\x5f\106\157\x75\156\144\x44\165\160\154\x69\x63\x61\x74\x65\163\x5f\x33\x32\x2e\x67\x69\x66", "\143\x61\164\145\147\157\162\x79" => "\x4d\157\144\165\x6c\145\x20\126\x69\145\x77\x73");
