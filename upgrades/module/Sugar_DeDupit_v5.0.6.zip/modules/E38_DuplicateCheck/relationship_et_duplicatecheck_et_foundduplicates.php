<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $dictionary["\x65\63\x38\137\144\x75\x70\154\151\143\141\164\145\143\150\145\x63\x6b\137\145\63\70\137\146\x6f\x75\x6e\144\144\165\160\154\x69\143\x61\164\x65\x73"] = array("\x74\x61\x62\x6c\x65" => "\x65\x33\70\137\144\165\x70\154\151\143\x61\x74\145\143\x68\x65\x63\x6b\x5f\x65\63\70\x5f\146\157\x75\x6e\x64\x64\165\x70\154\x69\143\141\x74\145\163", "\x66\x69\x65\154\144\163" => array("\x69\144" => array("\156\x61\155\145" => "\151\144", "\164\171\160\x65" => "\166\141\x72\143\x68\141\162", "\154\145\156" => "\x33\66"), "\x65\x33\x38\137\x64\165\x70\154\151\143\141\x74\145\x63\x68\x65\x63\153\x5f\151\x64" => array("\156\141\155\x65" => "\x65\63\x38\x5f\144\165\160\154\x69\x63\x61\x74\145\143\150\145\x63\x6b\x5f\151\x64", "\x74\x79\x70\145" => "\166\x61\x72\x63\x68\x61\162", "\154\145\x6e" => "\x33\x36"), "\x65\63\70\137\x66\157\x75\x6e\144\x64\x75\160\x6c\151\x63\141\164\x65\x73\x5f\x69\144" => array("\x6e\141\x6d\x65" => "\145\x33\x38\x5f\146\x6f\x75\x6e\x64\144\165\160\x6c\151\x63\x61\x74\145\x73\137\x69\x64", "\164\x79\x70\145" => "\x76\141\x72\x63\x68\141\x72", "\154\x65\x6e" => "\63\66"), "\x64\141\x74\145\137\155\157\x64\x69\146\x69\x65\x64" => array("\x6e\141\x6d\145" => "\x64\141\164\x65\137\155\x6f\144\x69\x66\x69\145\144", "\x74\x79\x70\145" => "\x64\141\164\145\x74\151\155\145"), "\144\145\x6c\x65\164\x65\x64" => array("\x6e\x61\x6d\x65" => "\x64\145\154\145\x74\x65\144", "\x74\171\x70\x65" => "\x62\157\157\x6c", "\x6c\x65\x6e" => "\61", "\x72\x65\x71\x75\151\x72\145\144" => false, "\144\145\146\141\165\154\x74" => "\x30")), "\151\156\x64\151\143\x65\x73" => array(array("\156\141\x6d\145" => "\145\63\x38\x5f\144\x75\160\x6c\x69\x63\141\164\x65\x63\x68\145\x63\153\137\145\x33\x38\137\146\x6f\x75\x6e\x64\x64\165\160\154\x69\143\141\x74\145\x73\163\160\x6b", "\x74\x79\x70\x65" => "\160\x72\151\155\x61\x72\x79", "\146\151\x65\154\144\x73" => array("\151\x64")), array("\156\141\x6d\145" => "\x69\144\x78\137\x65\63\x38\137\x64\165\x70\x6c\151\x63\x61\164\145\143\x68\145\x63\x6b\x5f\145\63\x38\x5f\x66\157\165\x6e\144\x64\x75\x70\154\x69\143\x61\x74\145\163", "\x74\x79\160\x65" => "\x61\x6c\164\145\162\x6e\141\164\x65\137\x6b\x65\171", "\x66\x69\x65\x6c\144\163" => array("\145\x33\x38\x5f\x64\165\x70\154\x69\143\x61\x74\x65\143\x68\145\143\153\x5f\151\x64", "\145\x33\x38\137\x66\x6f\165\156\144\x64\165\160\154\x69\143\141\164\145\163\x5f\151\x64")), array("\156\x61\x6d\145" => "\151\144\x78\137\x64\165\x70\143\150\143\x6b\x69\x64\137\x64\x65\x6c\137\x66\156\x64\144\165\160\151\144", "\164\x79\x70\145" => "\151\x6e\144\x65\x78", "\146\x69\145\x6c\x64\x73" => array("\x65\x33\x38\137\x64\165\160\x6c\x69\x63\141\164\145\x63\150\x65\143\153\137\x69\x64", "\144\145\154\145\164\145\144", "\145\x33\x38\x5f\146\157\x75\156\x64\x64\x75\x70\x6c\x69\x63\x61\x74\145\163\137\151\x64"))), "\x72\x65\x6c\141\164\x69\x6f\x6e\163\150\x69\160\163" => array("\145\x33\70\x5f\144\165\160\154\151\x63\x61\x74\x65\x63\150\x65\x63\x6b\137\145\x33\70\137\146\x6f\165\x6e\x64\x64\x75\x70\x6c\x69\x63\141\164\x65\x73" => array("\x6c\x68\163\x5f\x6d\x6f\144\165\x6c\x65" => "\x45\x33\70\x5f\104\x75\160\154\x69\x63\x61\164\145\103\150\145\143\x6b", "\x6c\x68\x73\x5f\164\x61\x62\154\x65" => "\145\63\x38\137\x64\x75\x70\154\x69\143\x61\164\x65\143\x68\x65\x63\153", "\x6c\x68\163\x5f\x6b\x65\x79" => "\151\x64", "\162\150\x73\x5f\155\x6f\144\165\154\145" => "\x45\63\x38\137\x46\157\x75\156\144\x44\165\160\154\151\143\141\164\x65\163", "\162\x68\163\x5f\x74\x61\x62\x6c\145" => "\x65\63\x38\x5f\x66\157\x75\x6e\x64\144\x75\160\x6c\x69\143\x61\x74\x65\163", "\x72\150\x73\137\153\145\x79" => "\x69\x64", "\162\x65\x6c\x61\x74\151\x6f\156\163\150\151\x70\137\164\x79\x70\145" => "\155\x61\156\171\x2d\x74\x6f\x2d\x6d\141\x6e\x79", "\152\157\x69\x6e\x5f\x74\x61\x62\x6c\145" => "\145\x33\70\137\144\x75\x70\x6c\x69\143\x61\164\x65\x63\x68\x65\x63\153\x5f\145\x33\70\137\146\x6f\165\x6e\144\144\x75\x70\x6c\151\143\141\x74\145\x73", "\152\x6f\x69\156\137\x6b\145\171\x5f\154\x68\x73" => "\145\63\x38\137\144\x75\160\x6c\x69\143\141\x74\x65\143\150\x65\143\153\x5f\151\144", "\152\x6f\x69\x6e\x5f\153\x65\171\x5f\162\x68\163" => "\145\63\70\x5f\146\x6f\x75\x6e\144\144\165\x70\x6c\x69\x63\141\x74\145\163\x5f\151\144")));
