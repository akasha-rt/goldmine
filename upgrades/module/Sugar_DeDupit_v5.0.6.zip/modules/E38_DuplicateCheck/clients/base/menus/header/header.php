<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $moduleName = "\105\63\x38\137\104\x75\160\x6c\x69\143\x61\164\x65\x43\x68\145\x63\153"; $viewdefs[$moduleName]["\142\x61\163\x65"]["\x6d\x65\x6e\165"]["\x68\x65\141\x64\x65\162"] = array(array("\x72\157\x75\x74\145" => "\43{$moduleName}\57\143\x72\x65\x61\164\x65", "\x6c\x61\142\145\x6c" => "\114\116\x4b\x5f\116\x45\x57\x5f\122\105\x43\117\122\x44", "\x61\x63\154\x5f\141\143\164\151\157\156" => "\143\162\145\x61\164\x65", "\x61\143\154\137\x6d\x6f\x64\165\x6c\x65" => $moduleName, "\151\143\157\x6e" => "\146\x61\x2d\x70\x6c\x75\163"), array("\162\x6f\x75\x74\x65" => "\x23{$moduleName}", "\154\141\142\145\x6c" => "\x4c\x4e\113\x5f\x4c\111\x53\x54", "\x61\143\154\137\141\x63\164\x69\x6f\x6e" => "\x6c\151\163\164", "\141\143\154\x5f\x6d\157\144\x75\x6c\x65" => $moduleName, "\x69\143\157\156" => "\146\141\55\x62\141\162\163"));
