<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\147\x61\162\x45\156\x74\x72\171") || !sugarEntry)) { goto sU12o; } die("\116\157\164\x20\x41\x20\126\141\x6c\x69\x64\40\105\156\164\x72\171\40\x50\157\151\x6e\164"); sU12o: $module_name = "\x45\63\x38\137\104\165\x70\154\151\143\x61\x74\145\103\150\x65\143\x6b"; $viewdefs[$module_name]["\142\141\x73\x65"]["\x76\151\145\x77"]["\x6c\x69\x73\164"] = array("\x70\x61\x6e\x65\x6c\163" => array(array("\154\x61\x62\x65\x6c" => "\x4c\102\x4c\137\x50\101\116\x45\x4c\137\x31", "\x66\151\x65\x6c\144\x73" => array(array("\156\x61\155\x65" => "\156\141\x6d\145", "\154\141\x62\145\154" => "\x4c\x42\x4c\137\x4e\101\115\105", "\x64\x65\146\x61\x75\154\164" => true, "\145\156\141\142\154\x65\144" => true, "\x6c\x69\x6e\x6b" => true), array("\156\x61\x6d\x65" => "\164\x65\x61\155\x5f\x6e\x61\155\x65", "\154\141\142\x65\x6c" => "\x4c\102\x4c\x5f\124\105\x41\115", "\x64\145\x66\141\x75\x6c\x74" => false, "\x65\156\x61\x62\154\145\x64" => true), array("\x6e\x61\x6d\x65" => "\141\163\x73\x69\147\156\145\144\137\165\x73\145\162\x5f\x6e\x61\x6d\145", "\x6c\141\142\x65\x6c" => "\x4c\x42\x4c\x5f\x41\x53\x53\111\x47\116\105\104\137\124\x4f\137\116\101\115\105", "\144\x65\x66\141\x75\x6c\164" => true, "\x65\x6e\141\142\154\x65\144" => true, "\154\x69\156\153" => true), array("\156\x61\x6d\x65" => "\x64\141\164\145\137\x6d\x6f\144\x69\x66\x69\145\x64", "\x65\156\x61\142\154\x65\144" => true, "\x64\x65\x66\x61\165\154\164" => true), array("\x6e\x61\155\145" => "\x64\141\x74\x65\x5f\x65\x6e\x74\145\x72\x65\x64", "\145\x6e\141\142\x6c\x65\x64" => true, "\144\x65\x66\x61\165\154\164" => true)))), "\x6f\162\144\145\162\102\x79" => array("\x66\x69\x65\154\144" => "\x64\x61\x74\x65\137\x6d\157\144\151\x66\151\145\x64", "\x64\151\x72\145\x63\x74\x69\x6f\156" => "\x64\145\163\x63"));
