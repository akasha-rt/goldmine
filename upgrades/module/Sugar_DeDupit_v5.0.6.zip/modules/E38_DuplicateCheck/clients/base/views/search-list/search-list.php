<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\137\104\x75\160\154\x69\143\141\164\145\103\x68\x65\143\x6b"; $viewdefs[$module_name]["\x62\x61\x73\145"]["\x76\x69\x65\x77"]["\163\x65\x61\162\x63\x68\55\154\x69\x73\x74"] = array("\x70\141\156\x65\154\163" => array(array("\x6e\141\x6d\x65" => "\160\162\151\155\x61\x72\171", "\146\151\145\154\144\163" => array(array("\156\141\x6d\145" => "\x70\151\143\164\x75\162\x65", "\x74\x79\x70\145" => "\x61\x76\x61\x74\x61\162", "\163\151\x7a\x65" => "\155\145\144\151\x75\155", "\x72\145\141\144\157\x6e\x6c\171" => true, "\143\163\x73\137\143\x6c\x61\x73\x73" => "\x70\x75\x6c\154\x2d\154\x65\x66\x74"), array("\156\141\x6d\145" => "\156\x61\x6d\x65", "\x74\171\x70\145" => "\156\x61\x6d\145", "\x6c\x69\x6e\x6b" => true, "\154\x61\x62\145\154" => "\114\x42\x4c\137\123\125\x42\112\x45\103\124")))));
