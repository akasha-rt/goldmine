<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\x38\137\104\165\x70\x6c\x69\x63\x61\164\145\103\x68\x65\143\153"; $viewdefs[$module_name]["\x62\x61\x73\145"]["\166\x69\x65\x77"]["\163\145\154\x65\x63\164\151\x6f\156\x2d\154\x69\x73\164"] = array("\x70\141\156\145\x6c\163" => array(array("\x6c\141\x62\145\154" => "\x4c\x42\114\x5f\x50\101\x4e\105\114\x5f\x31", "\x66\151\145\x6c\x64\x73" => array(array("\156\141\x6d\x65" => "\x6e\141\155\145", "\154\141\x62\145\154" => "\114\102\114\x5f\116\101\x4d\x45", "\x64\145\146\141\x75\154\164" => true, "\145\x6e\141\142\154\x65\x64" => true, "\x6c\x69\156\x6b" => true), array("\156\141\x6d\145" => "\164\x65\141\x6d\137\156\141\x6d\x65", "\x6c\141\142\145\154" => "\x4c\x42\x4c\x5f\124\105\101\x4d", "\x64\x65\x66\x61\x75\154\x74" => true, "\145\156\x61\142\154\145\144" => true), array("\156\141\155\145" => "\141\163\x73\151\x67\x6e\x65\144\137\x75\163\145\162\137\156\141\155\x65", "\154\x61\x62\145\154" => "\114\102\x4c\137\101\x53\x53\111\107\x4e\105\x44\137\124\x4f\137\x4e\101\115\x45", "\144\x65\x66\141\165\154\x74" => true, "\x65\x6e\x61\x62\154\145\x64" => true, "\154\151\x6e\x6b" => true), array("\154\141\x62\145\x6c" => "\114\x42\114\137\x44\x41\124\105\x5f\115\117\104\x49\106\111\105\x44", "\x65\x6e\141\x62\x6c\145\144" => true, "\x64\145\146\141\165\x6c\x74" => true, "\x6e\x61\155\145" => "\144\141\164\145\137\155\x6f\144\x69\x66\x69\145\x64", "\x72\x65\141\x64\157\156\x6c\171" => true)))), "\157\162\x64\x65\162\x42\171" => array("\146\x69\x65\x6c\x64" => "\144\141\x74\145\137\x6d\x6f\x64\151\x66\x69\145\144", "\144\151\x72\145\x63\x74\151\x6f\x6e" => "\144\145\x73\x63"));
