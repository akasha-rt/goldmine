<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\70\x5f\x44\x75\160\154\x69\143\x61\x74\x65\x43\x68\145\x63\x6b"; $viewdefs[$module_name]["\142\141\163\145"]["\x76\x69\x65\167"]["\x6d\x61\163\x73\165\x70\x64\141\x74\x65"] = array("\x62\165\164\x74\x6f\x6e\163" => array(array("\164\171\160\145" => "\x62\x75\x74\164\x6f\x6e", "\166\x61\154\165\145" => "\x63\x61\x6e\x63\x65\x6c", "\x63\163\x73\x5f\143\x6c\x61\163\163" => "\x62\164\x6e\x2d\154\x69\x6e\153\40\142\164\156\55\x69\156\x76\151\163\x69\142\x6c\145\x20\x63\141\156\x63\145\154\x5f\x62\x75\164\x74\x6f\x6e", "\154\141\142\145\154" => "\114\102\x4c\x5f\103\101\116\x43\x45\x4c\137\x42\125\x54\124\x4f\116\137\x4c\101\x42\105\x4c", "\160\162\x69\155\141\162\x79" => false), array("\x6e\x61\155\x65" => "\165\x70\144\x61\x74\x65\x5f\142\x75\164\x74\x6f\x6e", "\164\171\160\145" => "\x62\x75\164\164\x6f\x6e", "\x6c\141\x62\145\x6c" => "\x4c\102\114\137\x55\120\x44\x41\124\x45", "\x61\143\154\x5f\141\x63\164\151\x6f\x6e" => "\155\141\x73\x73\x75\x70\144\x61\x74\x65", "\x63\163\x73\137\x63\154\141\163\163" => "\x62\164\156\55\160\x72\151\x6d\141\162\x79", "\160\162\151\155\141\x72\171" => true)), "\160\141\x6e\145\154\x73" => array(array("\146\151\x65\x6c\x64\163" => array())));
