<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\105\63\x38\x5f\104\165\x70\x6c\151\143\x61\164\x65\103\150\145\x63\x6b"]["\x62\141\x73\x65"]["\x76\x69\145\167"]["\x73\165\x62\160\x61\156\x65\x6c\55\x66\157\162\55\x65\x33\70\x5f\146\157\x75\x6e\144\144\x75\160\154\151\x63\141\164\145\x73"] = array("\x70\141\156\145\x6c\x73" => array(0 => array("\156\141\x6d\145" => "\160\141\x6e\x65\154\137\x68\x65\141\x64\x65\162", "\x6c\x61\142\x65\x6c" => "\x4c\102\114\137\x50\x41\x4e\x45\x4c\x5f\x31", "\x66\x69\145\154\x64\163" => array(0 => array("\x6c\x61\x62\x65\x6c" => "\114\102\x4c\137\116\x41\x4d\105", "\145\156\141\142\154\145\144" => true, "\144\x65\x66\x61\165\154\x74" => true, "\x6e\141\x6d\145" => "\156\x61\x6d\145", "\x6c\x69\156\x6b" => true), 1 => array("\154\x61\142\145\154" => "\114\102\x4c\137\115\x4f\104\x55\x4c\x45\137\x4e\x41\115\105", "\x65\156\x61\x62\154\145\144" => true, "\x64\x65\x66\141\165\x6c\164" => true, "\156\x61\x6d\x65" => "\146\x6f\162\x5f\155\x6f\x64\x75\x6c\x65"), 2 => array("\154\141\142\145\154" => "\114\102\x4c\x5f\x52\x45\103\x4f\x52\104\137\111\104", "\x65\156\141\x62\x6c\x65\x64" => true, "\x64\x65\x66\x61\x75\x6c\x74" => true, "\x6e\x61\x6d\145" => "\162\145\x63\157\x72\144\137\151\x64"), 3 => array("\x6c\x61\x62\x65\x6c" => "\x4c\x42\x4c\x5f\x43\x48\105\103\113\x5f\x46\x4f\122\x5f\x44\x55\120\114\111\103\101\124\105\123", "\x65\156\x61\142\154\x65\144" => true, "\x64\145\x66\141\x75\154\164" => true, "\x6e\141\x6d\145" => "\143\x68\145\x63\153\137\146\x6f\x72\137\x64\x75\160\154\x69\143\141\x74\x65\163")))), "\x6f\162\144\145\x72\x42\171" => array("\x66\x69\x65\x6c\144" => "\x64\x61\164\145\x5f\155\x6f\144\151\x66\x69\145\144", "\x64\x69\162\145\143\164\x69\x6f\x6e" => "\144\145\163\143"), "\164\171\160\x65" => "\163\x75\142\x70\x61\x6e\145\x6c\55\154\x69\163\x74");
