<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\x38\137\104\165\x70\x6c\x69\x63\x61\164\x65\x43\150\145\x63\153"; $viewdefs[$module_name]["\x62\141\163\145"]["\166\151\145\x77"]["\x64\x75\160\x65\x63\150\145\x63\x6b\55\x6c\151\163\164"] = array("\x70\x61\x6e\145\x6c\163" => array(array("\x6c\x61\142\145\154" => "\x4c\102\114\x5f\x50\x41\x4e\105\x4c\x5f\61", "\146\x69\145\154\x64\x73" => array(array("\x6e\x61\155\145" => "\156\141\x6d\x65", "\154\x61\x62\145\x6c" => "\114\x42\114\137\x4e\x41\115\x45", "\x64\145\x66\141\x75\x6c\x74" => true, "\145\156\x61\142\x6c\145\144" => true, "\x6c\x69\156\x6b" => true), array("\x6e\x61\x6d\145" => "\164\x65\141\x6d\137\156\141\x6d\x65", "\154\x61\142\145\x6c" => "\114\x42\114\x5f\x54\105\101\115", "\x64\x65\146\x61\165\154\x74" => true, "\x65\x6e\x61\142\x6c\145\x64" => true), array("\156\x61\x6d\145" => "\141\163\x73\x69\147\x6e\145\x64\137\x75\x73\x65\x72\137\156\x61\x6d\x65", "\154\x61\x62\x65\154" => "\114\x42\114\137\101\123\x53\111\x47\116\x45\104\137\124\x4f\x5f\x4e\x41\x4d\x45", "\144\145\x66\x61\x75\154\x74" => true, "\x65\x6e\141\x62\154\145\x64" => true, "\x6c\x69\156\153" => true), array("\154\141\142\145\154" => "\114\x42\x4c\x5f\x44\x41\x54\105\x5f\x4d\x4f\x44\111\x46\x49\x45\104", "\x65\156\141\x62\154\x65\144" => true, "\144\145\x66\x61\x75\x6c\x74" => true, "\x6e\x61\x6d\x65" => "\x64\141\164\x65\137\x6d\157\144\151\146\151\145\144", "\162\145\x61\144\157\156\x6c\x79" => true)))));
