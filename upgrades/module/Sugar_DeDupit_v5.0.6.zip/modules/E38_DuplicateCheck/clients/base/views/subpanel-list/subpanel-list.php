<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\x5f\x44\165\x70\x6c\x69\x63\x61\164\x65\103\150\145\x63\x6b"; $viewdefs[$module_name]["\x62\x61\163\x65"]["\166\x69\145\167"]["\163\165\x62\x70\141\x6e\145\154\x2d\x6c\151\163\x74"] = array("\160\141\156\x65\154\x73" => array(array("\x6e\x61\155\145" => "\160\x61\x6e\x65\154\137\x68\145\x61\x64\145\x72", "\154\141\x62\145\x6c" => "\x4c\102\x4c\137\x50\101\116\x45\114\137\61", "\146\151\x65\154\x64\x73" => array(array("\x6c\141\142\145\154" => "\114\102\x4c\137\116\x41\x4d\x45", "\x65\156\141\142\154\x65\x64" => true, "\x64\145\x66\x61\165\154\x74" => true, "\x6e\141\x6d\x65" => "\156\141\155\x65", "\154\151\156\x6b" => true), array("\154\x61\142\x65\x6c" => "\x4c\102\x4c\x5f\x44\101\124\105\137\x4d\117\x44\x49\x46\111\105\x44", "\145\x6e\141\x62\154\145\x64" => true, "\x64\145\146\x61\165\154\164" => true, "\x6e\141\x6d\145" => "\x64\x61\164\145\137\155\157\x64\151\x66\x69\x65\x64")))), "\x6f\162\x64\145\162\x42\x79" => array("\146\151\x65\154\144" => "\x64\x61\x74\145\x5f\155\157\144\151\x66\x69\x65\x64", "\144\x69\162\x65\143\164\151\157\156" => "\x64\145\x73\143"));
