<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\70\x5f\x44\165\160\154\x69\x63\x61\164\145\x43\150\145\x63\x6b"; $viewdefs[$module_name]["\x62\141\163\145"]["\146\151\x6c\x74\145\x72"]["\144\145\x66\x61\165\x6c\164"] = array("\144\x65\146\141\x75\x6c\164\137\x66\151\154\x74\145\162" => "\x61\x6c\154\x5f\x72\x65\x63\157\x72\x64\x73", "\146\x69\145\x6c\x64\x73" => array("\156\x61\x6d\145" => array(), "\164\x61\147" => array(), "\141\x73\163\x69\x67\x6e\x65\x64\x5f\165\163\x65\162\x5f\156\141\x6d\145" => array(), "\44\x6f\x77\156\x65\x72" => array("\160\162\145\x64\145\x66\x69\x6e\x65\144\x5f\146\x69\x6c\x74\145\162" => true, "\x76\x6e\141\x6d\145" => "\x4c\102\x4c\x5f\x43\125\122\122\x45\116\x54\137\x55\x53\x45\122\137\106\111\x4c\x54\x45\122"), "\x24\x66\x61\166\157\x72\151\x74\x65" => array("\x70\x72\145\x64\x65\146\x69\x6e\x65\144\137\146\151\x6c\x74\145\x72" => true, "\x76\156\x61\155\145" => "\114\x42\x4c\x5f\x46\101\126\x4f\122\111\x54\x45\123\137\x46\111\x4c\124\x45\122")));
