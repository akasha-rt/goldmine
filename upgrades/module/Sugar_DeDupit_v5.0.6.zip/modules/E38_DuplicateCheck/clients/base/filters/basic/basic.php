<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\x67\141\162\x45\156\x74\162\x79") || !sugarEntry)) { goto NB566; } die("\x4e\157\164\40\101\x20\x56\141\x6c\151\x64\40\x45\x6e\x74\162\x79\40\x50\157\151\x6e\x74"); NB566: $viewdefs["\105\63\x38\137\104\165\x70\154\x69\x63\x61\164\x65\103\x68\x65\x63\153"]["\x62\x61\x73\x65"]["\146\151\154\164\145\162"]["\x62\x61\163\151\143"] = array("\143\162\145\141\164\x65" => true, "\x71\x75\x69\x63\153\163\145\141\x72\x63\150\137\146\x69\145\x6c\144" => array("\x6e\x61\x6d\x65"), "\161\x75\x69\143\x6b\x73\145\x61\162\x63\x68\x5f\x70\x72\151\x6f\162\x69\164\171" => 1, "\x71\165\x69\143\153\x73\145\141\162\x63\x68\x5f\x73\x70\x6c\x69\164\x5f\x74\x65\162\155\x73" => false, "\146\151\154\x74\x65\x72\x73" => array(array("\151\144" => "\x61\x6c\x6c\x5f\x72\145\x63\x6f\162\144\x73", "\x6e\x61\155\145" => "\x4c\x42\114\x5f\x4c\x49\x53\124\x56\111\x45\x57\137\106\x49\114\x54\x45\x52\137\101\114\114", "\146\x69\x6c\164\145\x72\x5f\x64\145\146\x69\x6e\x69\164\151\157\156" => array(), "\x65\144\151\x74\141\x62\x6c\145" => false), array("\151\144" => "\141\x73\x73\x69\147\x6e\145\144\137\x74\157\137\155\145", "\x6e\141\x6d\145" => "\x4c\102\x4c\137\101\123\x53\x49\107\116\105\104\137\x54\x4f\x5f\115\105", "\146\x69\154\164\x65\x72\x5f\144\145\x66\151\156\x69\x74\x69\157\x6e" => array("\x24\x6f\167\156\x65\x72" => ''), "\145\144\151\164\x61\x62\154\145" => false), array("\151\x64" => "\146\141\166\x6f\162\x69\x74\145\x73", "\156\x61\155\x65" => "\x4c\x42\114\x5f\x46\101\x56\117\122\111\x54\x45\x53", "\146\151\154\164\145\x72\x5f\144\x65\146\x69\156\x69\164\151\157\x6e" => array("\44\x66\x61\x76\157\x72\151\164\x65" => ''), "\145\x64\x69\x74\x61\142\x6c\145" => false), array("\x69\x64" => "\x72\145\x63\145\156\164\154\171\x5f\166\x69\x65\167\x65\x64", "\156\x61\x6d\145" => "\x4c\102\x4c\137\x52\x45\x43\x45\116\x54\114\131\137\126\x49\x45\127\x45\x44", "\x66\151\154\164\145\x72\137\144\x65\146\x69\156\x69\164\151\x6f\156" => array("\44\x74\162\x61\x63\153\145\162" => "\55\x37\x20\x44\x41\131"), "\145\144\x69\164\141\x62\154\x65" => false), array("\151\x64" => "\162\145\143\x65\x6e\164\154\x79\x5f\x63\x72\145\x61\x74\145\x64", "\x6e\x61\x6d\x65" => "\114\x42\114\x5f\x4e\105\x57\137\x52\105\103\117\122\x44\x53", "\146\x69\x6c\164\x65\162\x5f\x64\145\146\x69\156\151\164\x69\157\x6e" => array("\144\x61\164\x65\x5f\x65\x6e\x74\145\162\x65\144" => array("\x24\x64\141\x74\x65\x52\x61\156\147\x65" => "\154\x61\163\164\x5f\x37\137\x64\141\x79\x73")), "\145\144\x69\x74\141\x62\154\x65" => false)));
