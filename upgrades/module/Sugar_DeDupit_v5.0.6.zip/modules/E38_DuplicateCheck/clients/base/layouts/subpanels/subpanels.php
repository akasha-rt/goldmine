<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\x67\141\x72\x45\156\164\162\x79") || !sugarEntry)) { goto TgGfz; } die("\x4e\x6f\x74\x20\x41\40\x56\141\154\151\x64\40\105\x6e\164\162\x79\x20\x50\157\x69\156\164"); TgGfz: $viewdefs["\x45\63\x38\x5f\104\165\x70\154\x69\143\x61\x74\145\x43\150\145\x63\x6b"]["\x62\x61\x73\x65"]["\x6c\x61\x79\157\165\x74"]["\163\x75\142\x70\141\156\x65\x6c\x73"] = array("\x63\x6f\x6d\x70\157\x6e\x65\x6e\x74\163" => array(array("\x6c\141\171\157\165\164" => "\x73\x75\142\160\141\x6e\145\x6c", "\x6c\x61\142\145\x6c" => "\114\x42\x4c\137\x46\117\x55\x4e\x44\137\x44\x55\x50\114\111\x43\x41\124\105\x53\x5f\123\x55\x42\x50\101\116\105\114\137\x54\x49\x54\114\x45", "\157\166\x65\162\x72\151\x64\x65\137\x73\165\x62\x70\141\x6e\145\x6c\137\x6c\151\x73\164\137\x76\151\145\167" => "\163\165\142\160\x61\x6e\x65\154\55\x66\x6f\x72\x2d\x65\63\70\x5f\x64\x75\160\x6c\x69\143\x61\164\145\143\x68\145\x63\x6b", "\x63\157\x6e\164\145\x78\x74" => array("\x6c\x69\156\153" => "\145\63\x38\137\146\x6f\x75\156\x64\x64\x75\x70\x6c\x69\143\x61\164\145\163"))), "\x74\171\160\x65" => "\163\x75\x62\160\x61\156\145\x6c\x73", "\163\x70\x61\x6e" => 12);
