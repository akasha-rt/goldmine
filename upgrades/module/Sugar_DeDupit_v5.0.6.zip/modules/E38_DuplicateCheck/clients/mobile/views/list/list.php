<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\x67\x61\162\x45\x6e\164\x72\x79") || !sugarEntry)) { goto f4UG1; } die("\x4e\157\x74\x20\x41\40\126\x61\x6c\151\x64\x20\105\x6e\164\162\171\40\120\157\151\x6e\x74"); f4UG1: $module_name = "\105\x33\70\x5f\x44\165\x70\x6c\x69\x63\x61\164\145\x43\150\x65\x63\x6b"; $viewdefs[$module_name]["\155\157\x62\151\x6c\145"]["\166\151\x65\167"]["\x6c\x69\x73\x74"] = array("\160\141\x6e\x65\x6c\x73" => array(array("\x6c\141\142\145\x6c" => "\114\102\114\x5f\120\x41\x4e\x45\x4c\137\104\x45\106\101\125\x4c\124", "\146\151\x65\x6c\144\x73" => array(array("\156\141\155\x65" => "\x6e\141\155\x65", "\154\x61\x62\x65\154" => "\114\102\114\x5f\116\101\x4d\x45", "\x64\145\x66\x61\165\x6c\164" => true, "\x65\x6e\x61\142\x6c\145\144" => true, "\x6c\151\156\153" => true), array("\x6e\141\155\x65" => "\x74\x65\x61\x6d\x5f\156\x61\155\145", "\154\x61\142\145\x6c" => "\114\102\x4c\x5f\x54\x45\x41\x4d", "\144\145\x66\x61\x75\154\x74" => true, "\145\x6e\141\x62\154\145\144" => true), array("\156\141\x6d\145" => "\141\163\x73\x69\147\156\x65\144\137\165\163\x65\162\x5f\156\x61\x6d\x65", "\154\141\x62\x65\x6c" => "\x4c\102\x4c\x5f\101\123\x53\x49\x47\x4e\x45\104\137\124\117\137\116\101\x4d\x45", "\144\145\x66\x61\165\x6c\x74" => true, "\145\x6e\141\x62\x6c\x65\x64" => true, "\154\151\x6e\x6b" => true)))));
