<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\x38\137\104\x75\160\x6c\x69\x63\x61\164\x65\103\x68\x65\143\153"; $viewdefs[$module_name]["\155\x6f\x62\x69\x6c\x65"]["\166\151\x65\167"]["\x65\144\x69\x74"] = array("\164\145\155\160\x6c\141\x74\x65\x4d\145\x74\141" => array("\x6d\x61\170\x43\157\154\x75\155\x6e\x73" => "\x31", "\167\x69\x64\164\x68\x73" => array(array("\x6c\141\142\145\154" => "\x31\x30", "\x66\x69\x65\154\x64" => "\x33\60"), array("\154\141\142\x65\x6c" => "\x31\60", "\x66\x69\x65\x6c\144" => "\x33\x30"))), "\x70\141\156\145\154\163" => array(array("\154\x61\x62\x65\x6c" => "\x4c\102\114\137\120\101\116\x45\114\137\x44\x45\106\x41\x55\114\x54", "\x66\151\x65\154\x64\163" => array("\156\141\155\145", "\141\x73\163\151\147\x6e\x65\144\x5f\x75\x73\x65\162\x5f\156\x61\155\145", "\164\145\141\x6d\x5f\156\x61\155\x65"))));
