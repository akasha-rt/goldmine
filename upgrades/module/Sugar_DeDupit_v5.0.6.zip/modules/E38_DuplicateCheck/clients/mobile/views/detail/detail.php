<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\70\137\104\165\160\x6c\x69\x63\x61\164\145\x43\x68\145\x63\x6b"; $viewdefs[$module_name]["\x6d\x6f\142\151\154\x65"]["\x76\x69\x65\x77"]["\x64\x65\x74\141\x69\154"] = array("\x74\x65\x6d\x70\x6c\141\x74\145\115\145\164\141" => array("\146\157\162\x6d" => array("\x62\x75\x74\x74\x6f\x6e\x73" => array("\105\104\x49\124", "\104\x55\x50\x4c\111\x43\101\124\x45", "\x44\x45\114\105\124\105")), "\x6d\x61\170\103\x6f\x6c\x75\x6d\x6e\163" => "\x31", "\167\151\x64\x74\150\x73" => array(array("\x6c\141\142\x65\154" => "\x31\60", "\146\x69\x65\x6c\x64" => "\x33\60"), array("\x6c\x61\142\145\154" => "\61\x30", "\146\151\x65\x6c\x64" => "\x33\x30"))), "\x70\141\156\145\154\163" => array(array("\154\141\x62\x65\154" => "\x4c\102\114\x5f\x50\x41\116\x45\x4c\x5f\x44\x45\106\x41\125\114\x54", "\x66\x69\145\x6c\144\163" => array("\x6e\x61\x6d\x65", "\x61\163\163\151\147\x6e\145\144\x5f\165\163\145\162\137\x6e\141\x6d\x65", "\x74\x65\x61\155\137\x6e\141\x6d\x65"))));
