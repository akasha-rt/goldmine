<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\x67\x61\x72\105\x6e\x74\162\171") || !sugarEntry)) { goto jUnqh; } die("\x4e\157\x74\x20\x41\x20\x56\x61\x6c\x69\144\x20\105\x6e\164\x72\171\x20\x50\157\x69\x6e\164"); jUnqh: $module_name = "\105\63\x38\x5f\x44\165\160\154\x69\x63\141\164\x65\x43\x68\145\143\x6b"; $object_name = "\105\63\70\137\104\165\160\154\151\x63\x61\164\145\103\150\x65\143\x6b"; $_module_name = "\x45\x33\x38\137\x44\x75\160\154\151\x63\141\x74\x65\103\x68\x65\143\x6b"; $popupMeta = array("\x6d\x6f\x64\165\154\145\115\x61\x69\x6e" => $module_name, "\166\x61\x72\116\141\155\x65" => $object_name, "\157\162\x64\145\162\102\171" => $_module_name . "\x2e\x6e\141\155\x65", "\x77\x68\145\x72\x65\x43\154\x61\165\163\145\x73" => array("\156\141\x6d\x65" => $_module_name . "\x2e\x6e\141\155\145"), "\163\x65\141\x72\x63\150\111\156\160\x75\164\x73" => array($_module_name . "\137\156\x75\x6d\142\x65\x72", "\156\x61\155\145", "\x70\162\x69\x6f\x72\x69\x74\171", "\163\x74\141\164\x75\163"));
