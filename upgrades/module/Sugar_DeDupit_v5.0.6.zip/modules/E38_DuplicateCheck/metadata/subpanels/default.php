<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\147\x61\162\105\x6e\164\x72\171") || !sugarEntry)) { goto Vh49I; } die("\x4e\157\164\40\x41\x20\126\141\154\151\144\x20\105\156\164\162\x79\40\120\x6f\151\156\164"); Vh49I: $module_name = "\105\x33\70\x5f\104\165\160\154\151\x63\141\164\x65\103\150\x65\143\153"; $subpanel_layout = array("\164\x6f\160\137\142\165\164\x74\157\x6e\163" => array(array("\x77\x69\x64\x67\145\164\x5f\143\154\x61\x73\163" => "\123\165\x62\120\x61\x6e\145\x6c\124\157\160\x43\162\x65\x61\164\145\102\165\164\164\157\x6e"), array("\167\x69\x64\147\145\x74\137\x63\x6c\141\x73\x73" => "\x53\x75\142\x50\x61\156\x65\x6c\x54\x6f\160\123\x65\154\x65\x63\164\102\x75\x74\164\x6f\x6e", "\160\157\x70\165\x70\137\155\157\144\x75\x6c\x65" => $module_name)), "\167\150\145\162\145" => '', "\x6c\151\x73\x74\137\146\x69\x65\x6c\144\x73" => array("\156\x61\155\x65" => array("\x76\156\141\155\145" => "\x4c\102\114\137\116\x41\115\105", "\167\x69\x64\147\145\164\137\143\x6c\x61\x73\163" => "\123\x75\x62\x50\x61\156\145\154\104\x65\164\141\x69\x6c\126\151\x65\167\x4c\x69\156\x6b", "\x77\151\x64\x74\x68" => "\x34\65\x25"), "\144\141\164\145\137\x6d\x6f\144\151\x66\151\x65\x64" => array("\x76\156\x61\x6d\145" => "\x4c\102\x4c\x5f\x44\x41\124\x45\x5f\x4d\x4f\104\111\x46\x49\105\104", "\167\151\x64\164\150" => "\64\65\45"), "\x65\x64\x69\x74\137\x62\165\164\164\157\156" => array("\x76\x6e\x61\x6d\x65" => "\114\x42\x4c\x5f\x45\x44\x49\124\x5f\102\125\124\x54\x4f\x4e", "\x77\x69\144\x67\145\x74\137\x63\x6c\141\x73\163" => "\123\x75\x62\x50\x61\156\145\x6c\105\x64\x69\164\102\x75\164\x74\x6f\x6e", "\x6d\x6f\144\165\x6c\145" => $module_name, "\167\151\x64\164\150" => "\64\x25"), "\x72\145\155\157\166\145\137\142\165\164\x74\157\156" => array("\x76\x6e\141\x6d\145" => "\x4c\102\x4c\x5f\122\105\x4d\x4f\126\x45", "\167\x69\x64\x67\145\164\137\143\154\141\163\163" => "\x53\x75\142\120\x61\x6e\x65\154\122\x65\155\157\166\x65\x42\165\164\x74\157\156", "\x6d\157\144\165\x6c\145" => $module_name, "\167\151\x64\164\150" => "\65\x25")));
