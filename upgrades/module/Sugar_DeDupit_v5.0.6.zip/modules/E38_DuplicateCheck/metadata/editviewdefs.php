<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\70\137\x44\x75\160\x6c\x69\x63\x61\x74\145\103\150\x65\x63\x6b"; $viewdefs[$module_name]["\x45\144\x69\164\x56\151\x65\x77"] = array("\x74\x65\155\160\x6c\x61\164\145\x4d\145\164\x61" => array("\155\x61\x78\103\157\x6c\165\155\x6e\163" => "\62", "\167\x69\x64\x74\150\163" => array(array("\x6c\x61\x62\145\x6c" => "\x31\x30", "\146\151\145\154\144" => "\x33\x30"), array("\x6c\x61\142\145\x6c" => "\x31\x30", "\146\x69\x65\x6c\144" => "\x33\x30"))), "\x70\141\x6e\145\154\x73" => array("\144\145\x66\141\x75\x6c\x74" => array(array("\156\141\155\x65", "\x61\x73\x73\151\147\156\x65\144\137\165\x73\x65\x72\137\156\141\155\x65"), array(array("\156\141\155\145" => "\164\145\x61\155\x5f\x6e\x61\x6d\145", "\144\x69\163\160\154\x61\x79\x50\141\x72\141\155\x73" => array("\x64\151\x73\x70\154\141\171" => true)), ''), array("\x64\145\x73\143\162\x69\x70\164\x69\157\x6e"))));
