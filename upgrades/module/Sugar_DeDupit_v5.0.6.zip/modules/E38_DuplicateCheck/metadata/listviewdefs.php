<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\x75\147\141\162\105\156\x74\162\x79") || !sugarEntry)) { goto pP53A; } die("\x4e\157\x74\x20\x41\x20\x56\141\154\x69\x64\40\105\156\164\162\171\40\120\157\x69\156\x74"); pP53A: $module_name = "\x45\63\70\x5f\104\x75\160\x6c\151\143\x61\x74\x65\103\150\x65\143\x6b"; $listViewDefs[$module_name] = array("\x4e\101\115\105" => array("\x77\151\x64\164\150" => "\63\62", "\x6c\141\142\x65\154" => "\114\102\x4c\137\116\x41\x4d\x45", "\x64\145\x66\141\x75\154\x74" => true, "\154\x69\156\x6b" => true), "\124\105\101\x4d\x5f\x4e\x41\x4d\x45" => array("\167\151\x64\164\150" => "\71", "\154\x61\142\x65\154" => "\114\x42\114\x5f\124\105\101\x4d", "\x64\145\146\141\165\154\164" => false), "\x41\123\123\111\107\116\105\x44\137\x55\123\105\x52\137\116\101\115\x45" => array("\167\151\144\x74\x68" => "\x39", "\x6c\x61\142\x65\154" => "\114\x42\x4c\x5f\101\123\x53\111\x47\116\x45\104\x5f\124\x4f\137\116\x41\x4d\105", "\155\157\144\x75\154\145" => "\105\155\x70\154\157\171\145\x65\163", "\x69\144" => "\101\123\123\x49\x47\x4e\105\104\137\x55\x53\x45\x52\x5f\x49\x44", "\144\145\146\141\165\154\x74" => true));
