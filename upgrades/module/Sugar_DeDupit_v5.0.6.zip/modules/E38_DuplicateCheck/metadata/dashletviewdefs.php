<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\147\x61\162\x45\x6e\x74\x72\171") || !sugarEntry)) { goto h3KSm; } die("\x4e\157\164\40\x41\x20\126\x61\x6c\x69\144\40\105\x6e\x74\x72\171\40\120\157\151\x6e\x74"); h3KSm: global $current_user; $dashletData["\x45\63\x38\137\104\165\160\x6c\x69\143\141\164\x65\x43\150\145\x63\153\104\141\163\150\x6c\145\164"]["\163\145\141\162\143\x68\x46\x69\x65\154\144\163"] = array("\144\141\164\145\137\145\x6e\164\145\162\145\144" => array("\x64\x65\146\x61\x75\154\x74" => ''), "\x64\141\164\145\x5f\155\x6f\144\x69\x66\151\x65\x64" => array("\x64\x65\x66\x61\165\x6c\164" => ''), "\x74\145\x61\155\x5f\x69\x64" => array("\144\x65\146\x61\x75\x6c\x74" => ''), "\x61\163\x73\x69\147\x6e\145\x64\137\x75\163\x65\x72\137\x69\144" => array("\164\171\x70\x65" => "\x61\163\163\x69\147\156\x65\x64\x5f\165\x73\145\162\x5f\156\141\155\x65", "\x64\145\x66\141\165\x6c\164" => $current_user->name)); $dashletData["\105\x33\70\x5f\104\x75\160\154\x69\143\x61\x74\x65\x43\x68\145\143\x6b\104\141\163\x68\x6c\x65\164"]["\143\x6f\154\x75\x6d\156\163"] = array("\156\141\155\x65" => array("\x77\x69\x64\x74\x68" => "\64\60", "\x6c\x61\x62\145\154" => "\114\x42\x4c\137\x4c\x49\123\124\x5f\x4e\x41\115\x45", "\x6c\x69\x6e\x6b" => true, "\144\145\146\x61\165\154\164" => true), "\x64\141\164\x65\x5f\x65\x6e\x74\x65\162\x65\144" => array("\x77\151\x64\x74\x68" => "\61\x35", "\154\x61\142\x65\x6c" => "\114\102\114\x5f\x44\101\124\105\x5f\x45\116\124\x45\122\105\104", "\x64\x65\146\x61\x75\x6c\x74" => true), "\144\x61\x74\x65\x5f\155\157\x64\x69\146\151\145\144" => array("\167\151\x64\164\x68" => "\61\x35", "\154\x61\142\145\154" => "\114\102\x4c\137\x44\101\124\x45\x5f\115\117\x44\x49\106\111\x45\104"), "\x63\x72\x65\141\x74\x65\x64\137\142\x79" => array("\167\151\144\164\150" => "\70", "\154\141\x62\x65\154" => "\114\102\x4c\x5f\x43\122\x45\x41\x54\105\x44"), "\141\x73\163\151\147\x6e\145\144\137\x75\x73\x65\x72\137\156\141\155\145" => array("\x77\x69\x64\x74\150" => "\x38", "\154\x61\x62\145\154" => "\114\102\x4c\x5f\x4c\x49\x53\124\137\x41\x53\x53\111\x47\116\105\104\137\125\x53\x45\122"), "\x74\x65\x61\155\x5f\156\x61\155\145" => array("\x77\x69\144\164\150" => "\x31\x35", "\x6c\x61\142\x65\x6c" => "\x4c\102\114\137\114\111\x53\124\x5f\x54\105\101\115"));
