<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\x38\137\104\165\160\x6c\151\x63\141\x74\145\103\x68\145\x63\153"; $viewdefs[$module_name]["\x44\x65\164\x61\151\x6c\126\151\145\167"] = array("\x74\x65\x6d\160\x6c\141\164\145\x4d\145\164\x61" => array("\146\x6f\x72\x6d" => array("\142\x75\164\x74\157\156\x73" => array("\105\x44\111\x54", "\104\x55\120\x4c\x49\103\101\x54\105", "\104\x45\x4c\105\x54\x45", "\x46\x49\x4e\x44\x5f\104\125\120\x4c\111\103\x41\x54\105\x53")), "\x6d\x61\170\x43\157\154\x75\155\156\x73" => "\x32", "\x77\x69\144\164\150\163" => array(array("\x6c\x61\142\145\154" => "\61\x30", "\x66\x69\x65\154\144" => "\63\x30"), array("\x6c\141\142\145\x6c" => "\x31\60", "\x66\151\x65\154\x64" => "\63\x30"))), "\160\x61\x6e\x65\154\x73" => array(array("\x6e\141\155\145", "\141\x73\x73\x69\x67\x6e\x65\x64\x5f\165\x73\x65\x72\x5f\x6e\141\155\x65"), array("\x74\145\x61\155\x5f\156\141\155\x65", ''), array(array("\x6e\141\x6d\145" => "\x64\x61\x74\145\x5f\x65\x6e\164\145\x72\145\x64", "\x63\x75\163\x74\x6f\155\103\157\x64\x65" => "\x7b\x24\x66\x69\145\154\144\x73\x2e\144\x61\164\145\x5f\145\156\164\145\x72\x65\x64\x2e\x76\x61\x6c\x75\x65\x7d\x20\173\44\101\120\120\x2e\114\102\x4c\x5f\x42\131\x7d\40\x7b\x24\x66\151\x65\154\x64\163\x2e\x63\162\x65\141\164\145\144\x5f\142\x79\x5f\x6e\x61\155\145\56\166\141\154\165\x65\175", "\x6c\x61\x62\145\154" => "\114\x42\114\137\x44\x41\124\x45\x5f\x45\x4e\124\105\x52\105\104"), array("\156\x61\155\x65" => "\x64\x61\x74\x65\x5f\155\x6f\x64\x69\146\151\x65\144", "\x63\x75\163\x74\x6f\155\103\157\144\145" => "\x7b\x24\146\151\145\x6c\144\x73\56\144\x61\164\145\x5f\x6d\x6f\144\151\146\151\145\144\x2e\x76\141\x6c\165\145\x7d\x20\x7b\44\x41\x50\120\x2e\x4c\x42\x4c\x5f\x42\x59\175\x20\173\x24\x66\151\145\154\144\163\x2e\155\157\144\x69\x66\x69\x65\x64\x5f\x62\x79\x5f\x6e\x61\155\x65\56\x76\141\x6c\165\145\x7d", "\x6c\141\142\145\154" => "\114\102\114\x5f\x44\x41\x54\105\x5f\x4d\117\x44\111\x46\111\x45\104")), array("\x64\145\163\x63\x72\x69\x70\164\151\157\x6e")));
