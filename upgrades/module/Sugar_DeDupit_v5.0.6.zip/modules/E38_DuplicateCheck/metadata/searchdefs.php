<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\x38\x5f\104\x75\x70\154\151\143\141\x74\145\x43\150\x65\x63\153"; $searchdefs[$module_name] = array("\x74\145\155\x70\x6c\141\164\x65\x4d\145\x74\141" => array("\x6d\x61\170\103\x6f\x6c\x75\155\156\x73" => "\63", "\155\x61\x78\103\x6f\x6c\165\155\156\x73\x42\141\x73\151\x63" => "\x34", "\x77\151\x64\x74\x68\163" => array("\154\x61\142\x65\154" => "\x31\60", "\x66\x69\145\x6c\144" => "\x33\60")), "\x6c\141\171\x6f\165\x74" => array("\x62\x61\x73\151\x63\x5f\163\145\141\x72\x63\150" => array("\x6e\141\155\x65", array("\x6e\141\x6d\x65" => "\x63\x75\162\162\145\x6e\164\137\x75\x73\145\x72\x5f\157\x6e\154\x79", "\154\141\142\x65\154" => "\114\102\x4c\137\103\x55\122\122\x45\116\x54\x5f\125\123\105\x52\x5f\x46\111\x4c\124\x45\122", "\164\171\x70\145" => "\x62\x6f\157\154"), array("\x6e\141\155\x65" => "\x66\141\166\x6f\162\151\x74\145\x73\x5f\x6f\x6e\154\171", "\154\141\142\x65\x6c" => "\114\102\x4c\137\106\101\x56\x4f\122\111\124\x45\123\x5f\x46\111\114\x54\x45\122", "\164\171\x70\x65" => "\x62\157\157\154")), "\x61\144\166\141\x6e\x63\145\x64\137\163\145\x61\x72\x63\x68" => array("\x6e\x61\155\145", array("\x6e\141\155\x65" => "\x61\x73\x73\151\x67\x6e\x65\x64\x5f\165\163\145\162\137\x69\x64", "\154\x61\x62\145\154" => "\114\x42\x4c\137\x41\x53\123\111\x47\x4e\105\x44\x5f\x54\x4f", "\x74\x79\160\x65" => "\x65\x6e\x75\x6d", "\146\165\x6e\143\x74\x69\x6f\x6e" => array("\156\x61\x6d\145" => "\147\145\164\x5f\x75\163\x65\162\x5f\x61\x72\x72\141\x79", "\160\x61\x72\x61\155\163" => array(false))), array("\156\141\x6d\145" => "\146\x61\x76\x6f\162\151\164\145\163\x5f\157\156\154\171", "\x6c\x61\x62\x65\x6c" => "\114\x42\x4c\x5f\106\101\126\117\122\111\x54\x45\123\x5f\x46\x49\114\x54\x45\x52", "\x74\171\160\145" => "\x62\157\x6f\x6c"))));
