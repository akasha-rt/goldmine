<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\147\x61\162\x45\156\164\x72\171") || !sugarEntry)) { goto OIH6m; } die("\x4e\x6f\x74\x20\101\x20\x56\141\154\151\x64\40\x45\x6e\x74\162\171\x20\x50\157\x69\156\x74"); OIH6m: global $app_strings; $dashletMeta["\x45\x33\70\137\x44\165\160\x6c\151\x63\141\164\145\x43\150\145\x63\153\104\141\163\150\154\145\x74"] = array("\x6d\x6f\144\165\x6c\x65" => "\x45\x33\70\137\104\165\160\154\x69\143\x61\x74\145\x43\150\x65\143\x6b", "\164\x69\164\x6c\x65" => translate("\114\102\114\137\110\x4f\x4d\105\120\101\x47\105\x5f\x54\111\124\x4c\105", "\x45\63\70\137\104\x75\160\x6c\151\143\141\x74\145\x43\150\x65\143\153"), "\144\145\x73\143\162\x69\160\164\151\157\156" => "\x41\40\x63\165\163\x74\157\x6d\151\x7a\141\142\x6c\x65\x20\166\x69\145\167\40\151\156\164\x6f\x20\x45\x33\70\137\x44\165\160\154\151\x63\141\164\x65\103\x68\x65\143\x6b", "\151\x63\157\x6e" => "\151\x63\x6f\x6e\137\105\63\70\137\x44\165\160\x6c\x69\x63\x61\164\x65\x43\x68\x65\143\x6b\x5f\x33\x32\x2e\147\151\x66", "\143\141\164\145\147\x6f\162\171" => "\x4d\157\x64\x75\x6c\x65\x20\x56\x69\x65\167\163");
