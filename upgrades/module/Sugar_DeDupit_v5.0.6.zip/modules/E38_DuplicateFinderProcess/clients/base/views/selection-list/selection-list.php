<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\x5f\104\165\x70\x6c\151\x63\x61\164\145\x46\151\x6e\144\145\162\x50\162\157\x63\145\163\163"; $viewdefs[$module_name]["\x62\141\x73\145"]["\166\151\x65\167"]["\x73\x65\x6c\145\x63\164\x69\157\x6e\x2d\x6c\x69\x73\x74"] = array("\x70\x61\x6e\145\154\x73" => array(array("\154\x61\142\145\154" => "\x4c\102\x4c\x5f\x50\x41\x4e\105\114\137\x31", "\x66\x69\145\x6c\x64\x73" => array(array("\156\141\155\x65" => "\156\x61\x6d\145", "\154\x61\x62\x65\x6c" => "\114\x42\x4c\137\x4e\x41\x4d\105", "\144\145\146\141\165\154\x74" => true, "\145\156\141\142\x6c\145\x64" => true, "\154\x69\x6e\x6b" => true), array("\156\x61\x6d\x65" => "\x74\145\141\x6d\137\x6e\141\155\x65", "\154\x61\142\x65\x6c" => "\114\102\x4c\137\x54\x45\101\115", "\x64\x65\146\141\x75\x6c\x74" => true, "\x65\156\141\142\x6c\x65\144" => true), array("\156\141\x6d\x65" => "\141\x73\163\151\147\x6e\x65\x64\137\165\x73\x65\162\x5f\156\141\155\145", "\x6c\141\142\x65\154" => "\114\x42\114\137\x41\123\123\111\x47\x4e\x45\x44\x5f\x54\x4f\137\x4e\101\115\x45", "\x64\145\x66\141\x75\x6c\164" => true, "\145\x6e\x61\x62\154\x65\144" => true, "\154\151\x6e\153" => true), array("\154\141\x62\x65\x6c" => "\114\102\114\137\104\x41\x54\105\137\x4d\x4f\104\111\106\111\105\104", "\x65\x6e\141\x62\154\x65\x64" => true, "\x64\x65\x66\141\165\x6c\164" => true, "\156\x61\155\145" => "\x64\x61\x74\x65\137\155\x6f\144\151\x66\151\145\144", "\x72\x65\141\x64\x6f\x6e\154\x79" => true)))), "\x6f\162\144\x65\162\102\171" => array("\146\x69\145\154\x64" => "\144\141\164\x65\x5f\155\157\x64\x69\x66\x69\145\x64", "\x64\x69\162\x65\x63\164\151\157\156" => "\144\145\163\x63"));
