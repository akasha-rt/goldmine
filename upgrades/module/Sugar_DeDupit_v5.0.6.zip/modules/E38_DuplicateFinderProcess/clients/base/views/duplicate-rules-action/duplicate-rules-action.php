<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\70\137\x44\165\x70\154\151\x63\x61\x74\145\x46\x69\x6e\144\x65\162\120\x72\x6f\143\145\x73\163"; $viewdefs[$module_name]["\x62\141\163\x65"]["\x76\x69\145\x77"]["\144\165\160\x6c\x69\143\141\x74\145\x2d\162\x75\154\145\x73\x2d\x61\143\164\x69\x6f\x6e"] = array("\x62\x75\164\164\157\156\163" => array(array("\x74\x79\160\145" => "\142\165\x74\x74\157\156", "\156\141\155\x65" => "\x63\141\156\143\145\154\137\142\165\x74\x74\x6f\x6e", "\x6c\x61\142\x65\x6c" => "\x4c\102\x4c\x5f\103\x41\x4e\103\x45\114\137\x42\125\124\x54\117\116\137\114\x41\x42\x45\114", "\x63\x73\x73\x5f\143\154\141\x73\x73" => "\142\x74\x6e", "\145\x76\145\156\x74\163" => array("\143\154\x69\x63\x6b" => "\142\165\x74\164\157\x6e\x3a\143\x61\x6e\x63\x65\x6c\137\142\165\x74\x74\x6f\156\x3a\x63\154\151\143\153")), array("\x74\171\160\x65" => "\142\x75\164\x74\x6f\156", "\x65\x76\145\156\164" => "\x62\x75\x74\x74\157\156\x3a\x73\x61\x76\x65\x5f\142\x75\x74\x74\157\156\x3a\x63\154\151\x63\153", "\156\x61\x6d\145" => "\163\141\x76\145\x5f\142\165\164\x74\x6f\156", "\154\x61\142\x65\x6c" => "\x4c\x42\114\137\x53\101\126\x45\x5f\x43\117\x4e\106\111\x47\137\x42\125\x54\124\x4f\x4e\137\114\101\102\x45\x4c", "\x63\163\x73\x5f\x63\154\141\163\x73" => "\142\164\156\40\142\164\x6e\x2d\x70\162\x69\x6d\x61\x72\171", "\141\x63\x6c\x5f\x61\x63\x74\151\x6f\x6e" => "\x65\144\x69\164")));
