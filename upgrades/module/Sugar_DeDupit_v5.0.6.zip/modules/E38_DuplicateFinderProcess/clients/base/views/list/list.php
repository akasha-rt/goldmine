<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\70\x5f\104\165\x70\x6c\x69\x63\141\x74\145\x46\x69\156\144\x65\162\x50\162\157\143\145\x73\x73"; $viewdefs[$module_name] = array("\142\x61\x73\x65" => array("\x76\151\x65\x77" => array("\154\x69\163\164" => array("\x70\141\x6e\145\x6c\x73" => array(0 => array("\x6c\x61\142\x65\154" => "\x4c\x42\x4c\x5f\x50\101\116\105\114\x5f\61", "\x66\151\145\154\x64\x73" => array(0 => array("\x6e\x61\155\145" => "\x6e\141\x6d\x65", "\154\x61\142\145\154" => "\114\x42\114\137\116\x41\115\105", "\144\145\x66\x61\165\154\x74" => true, "\145\156\x61\x62\154\x65\x64" => true, "\154\151\156\153" => true), 1 => array("\x6e\x61\x6d\145" => "\146\157\162\x5f\155\x6f\x64\x75\x6c\x65", "\x6c\141\x62\x65\x6c" => "\114\102\114\137\x45\x33\70\x5f\x4d\x4f\104\x55\x4c\x45\x5f\x4e\x41\x4d\x45", "\x65\x6e\141\x62\x6c\x65\144" => true, "\x64\145\x66\141\165\154\164" => true, "\162\145\x61\x64\x6f\x6e\x6c\171" => true), 2 => array("\x6e\x61\x6d\145" => "\141\143\x74\x69\x76\145", "\154\141\x62\145\154" => "\x4c\x42\114\x5f\x41\x43\x54\x49\126\x45", "\145\156\x61\142\x6c\x65\144" => true, "\x72\145\x61\x64\x6f\x6e\154\x79" => true, "\x64\x65\146\x61\165\154\x74" => true), 3 => array("\x6e\141\155\x65" => "\141\x75\164\x6f\155\145\162\147\145", "\x6c\x61\x62\x65\154" => "\x4c\x42\114\137\101\125\x54\117\x4d\x45\122\107\105", "\x65\156\x61\142\x6c\x65\144" => true, "\162\145\141\x64\157\x6e\x6c\x79" => true, "\144\x65\x66\x61\x75\154\164" => true), 4 => array("\x6e\141\155\145" => "\x73\143\x61\x6e\x5f\x70\162\157\147\x72\x65\x73\163", "\154\x61\x62\x65\x6c" => "\114\102\x4c\x5f\x53\x43\101\x4e\x5f\120\x52\x4f\x47\x52\x45\123\123", "\145\156\x61\x62\x6c\145\x64" => true, "\x72\x65\x61\144\x6f\x6e\154\171" => true, "\144\145\x66\x61\x75\x6c\x74" => true), 5 => array("\156\141\155\x65" => "\144\141\164\145\137\145\156\x74\145\162\145\144", "\x65\156\141\x62\154\145\144" => true, "\x64\x65\146\x61\165\154\164" => true), 6 => array("\x6e\x61\155\x65" => "\x64\x61\164\145\x5f\x6d\157\144\x69\x66\x69\x65\144", "\145\x6e\x61\142\154\x65\144" => true, "\144\145\x66\141\x75\x6c\x74" => true), 7 => array("\156\141\x6d\145" => "\x61\x73\163\151\x67\156\145\144\137\165\163\145\x72\x5f\x6e\141\155\x65", "\x6c\x61\142\145\154" => "\x4c\x42\x4c\137\x41\x53\x53\111\x47\x4e\x45\x44\137\124\x4f\x5f\x4e\x41\x4d\x45", "\x64\x65\x66\x61\x75\x6c\164" => false, "\145\156\x61\x62\154\x65\144" => true, "\x6c\x69\x6e\x6b" => true)))), "\157\x72\144\x65\162\x42\x79" => array("\x66\151\145\x6c\x64" => "\x64\141\164\x65\137\155\157\x64\x69\x66\x69\145\144", "\x64\x69\x72\x65\x63\164\151\157\156" => "\x64\x65\163\143")))));
