<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\x38\137\104\165\x70\154\x69\x63\x61\x74\145\106\x69\x6e\x64\x65\162\x50\x72\x6f\143\145\163\x73"; $viewdefs[$module_name]["\142\x61\x73\x65"]["\x76\x69\x65\167"]["\x6d\x61\163\x73\165\x70\144\x61\x74\x65"] = array("\x62\165\x74\164\x6f\x6e\163" => array(array("\164\171\x70\x65" => "\142\165\x74\164\157\x6e", "\166\x61\154\165\x65" => "\x63\141\x6e\x63\145\x6c", "\x63\x73\x73\137\143\x6c\x61\163\x73" => "\142\x74\x6e\55\x6c\x69\156\153\40\x62\164\x6e\55\x69\x6e\x76\151\x73\151\x62\154\145\40\143\x61\x6e\x63\x65\x6c\x5f\142\x75\164\164\x6f\x6e", "\x6c\141\x62\x65\154" => "\x4c\102\114\137\103\x41\x4e\103\x45\x4c\137\102\x55\124\124\x4f\x4e\137\x4c\x41\x42\x45\x4c", "\x70\x72\x69\155\x61\x72\171" => false), array("\156\141\x6d\145" => "\x75\160\144\x61\164\145\x5f\x62\165\164\164\x6f\156", "\x74\171\x70\145" => "\142\x75\x74\164\157\x6e", "\x6c\x61\x62\x65\x6c" => "\114\102\114\137\x55\x50\x44\101\x54\x45", "\x61\x63\x6c\x5f\x61\x63\x74\151\157\156" => "\x6d\x61\x73\x73\x75\x70\144\141\x74\x65", "\143\x73\163\x5f\143\x6c\141\163\x73" => "\142\164\156\x2d\x70\x72\x69\155\141\x72\171", "\x70\162\151\155\141\162\171" => true)), "\160\141\156\145\154\163" => array(array("\x66\x69\145\x6c\144\x73" => array())));
