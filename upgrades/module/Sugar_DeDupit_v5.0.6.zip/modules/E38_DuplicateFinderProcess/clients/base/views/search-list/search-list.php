<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\70\x5f\104\x75\160\154\x69\x63\141\x74\145\106\151\156\x64\145\x72\120\162\157\x63\x65\x73\163"; $viewdefs[$module_name]["\142\141\x73\x65"]["\x76\151\x65\167"]["\x73\x65\x61\162\143\150\x2d\154\x69\x73\x74"] = array("\160\141\156\145\x6c\163" => array(array("\x6e\141\x6d\x65" => "\160\x72\151\155\141\x72\x79", "\x66\151\x65\x6c\144\163" => array(array("\x6e\x61\155\x65" => "\x70\151\143\x74\165\x72\x65", "\164\171\x70\145" => "\141\166\141\164\141\162", "\x73\151\172\x65" => "\155\x65\144\151\x75\155", "\x72\145\141\144\x6f\x6e\154\171" => true, "\x63\163\x73\137\143\x6c\141\163\163" => "\160\x75\x6c\x6c\55\154\145\146\164"), array("\x6e\141\x6d\x65" => "\x6e\141\155\145", "\x74\x79\160\x65" => "\156\x61\x6d\145", "\154\x69\156\153" => true, "\x6c\x61\142\145\154" => "\x4c\x42\114\137\x53\125\x42\x4a\105\103\x54")))));
