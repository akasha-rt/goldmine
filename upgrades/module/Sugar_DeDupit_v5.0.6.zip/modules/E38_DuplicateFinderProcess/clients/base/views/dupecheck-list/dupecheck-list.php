<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\70\137\x44\x75\x70\154\151\x63\141\x74\x65\106\x69\x6e\144\145\162\x50\162\157\x63\x65\x73\x73"; $viewdefs[$module_name]["\x62\141\x73\145"]["\166\151\x65\x77"]["\x64\165\160\145\143\x68\x65\143\x6b\x2d\x6c\x69\x73\164"] = array("\160\x61\x6e\145\154\163" => array(array("\x6c\x61\142\145\x6c" => "\x4c\102\114\137\x50\x41\116\x45\x4c\137\61", "\146\x69\x65\154\144\x73" => array(array("\156\141\x6d\145" => "\156\x61\155\x65", "\x6c\141\142\145\154" => "\x4c\102\114\x5f\x4e\x41\115\105", "\x64\x65\146\141\165\154\164" => true, "\145\156\141\x62\154\x65\144" => true, "\x6c\151\x6e\x6b" => true), array("\156\x61\x6d\145" => "\164\145\141\x6d\137\156\141\155\145", "\x6c\141\x62\x65\154" => "\114\x42\x4c\137\x54\x45\x41\115", "\144\x65\146\141\x75\154\164" => true, "\x65\156\x61\142\x6c\145\x64" => true), array("\x6e\141\x6d\145" => "\141\163\163\151\147\x6e\x65\144\x5f\x75\x73\x65\x72\137\156\x61\x6d\145", "\x6c\x61\x62\x65\154" => "\x4c\x42\x4c\x5f\x41\x53\x53\111\107\x4e\x45\104\x5f\x54\x4f\137\116\x41\115\105", "\144\145\146\141\165\x6c\164" => true, "\145\156\x61\142\154\x65\x64" => true, "\154\x69\156\x6b" => true), array("\x6c\141\142\x65\154" => "\x4c\102\x4c\137\x44\101\x54\x45\137\x4d\117\x44\x49\106\x49\105\104", "\x65\x6e\141\142\154\x65\x64" => true, "\144\x65\x66\141\165\x6c\x74" => true, "\156\141\x6d\x65" => "\144\x61\x74\x65\x5f\x6d\157\144\151\146\x69\145\x64", "\162\x65\x61\x64\157\x6e\x6c\171" => true)))));
