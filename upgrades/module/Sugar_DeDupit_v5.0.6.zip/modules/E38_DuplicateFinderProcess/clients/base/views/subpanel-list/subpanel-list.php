<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\137\x44\x75\160\154\151\x63\141\164\x65\106\x69\156\x64\145\x72\120\x72\157\143\145\163\x73"; $viewdefs[$module_name]["\x62\x61\x73\x65"]["\x76\x69\x65\167"]["\163\165\x62\x70\x61\x6e\x65\154\x2d\154\x69\163\x74"] = array("\160\x61\156\x65\154\x73" => array(array("\156\x61\155\145" => "\x70\141\x6e\x65\x6c\x5f\150\145\141\144\x65\162", "\154\x61\142\145\154" => "\x4c\x42\x4c\137\x50\x41\116\x45\x4c\x5f\61", "\x66\x69\145\154\144\x73" => array(array("\x6c\141\x62\x65\x6c" => "\x4c\102\x4c\x5f\x4e\101\x4d\105", "\145\x6e\x61\142\x6c\x65\144" => true, "\144\x65\x66\x61\x75\154\x74" => true, "\156\x61\155\145" => "\x6e\x61\x6d\145", "\x6c\x69\156\153" => true), array("\154\141\x62\145\x6c" => "\114\x42\x4c\137\x44\x41\124\105\x5f\115\117\x44\111\106\x49\x45\104", "\x65\x6e\141\142\x6c\x65\144" => true, "\144\145\x66\x61\x75\x6c\164" => true, "\x6e\141\x6d\145" => "\x64\x61\164\145\x5f\155\157\x64\x69\x66\151\x65\144")))), "\x6f\162\x64\x65\x72\102\x79" => array("\x66\x69\x65\154\x64" => "\x64\x61\164\x65\x5f\155\x6f\x64\x69\x66\151\x65\144", "\x64\151\162\x65\x63\x74\x69\157\x6e" => "\x64\145\x73\143"));
