<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\x67\x61\162\105\156\164\162\x79") || !sugarEntry)) { goto URunu; } die("\x4e\x6f\x74\x20\101\x20\x56\x61\154\151\x64\40\105\156\x74\x72\171\x20\120\x6f\x69\x6e\164"); URunu: $viewdefs["\105\63\70\137\x44\x75\160\154\151\143\141\164\x65\x46\x69\x6e\x64\145\x72\x50\x72\x6f\143\145\163\x73"]["\x62\x61\163\145"]["\146\151\154\x74\145\162"]["\142\x61\163\151\143"] = array("\x63\x72\x65\141\x74\145" => true, "\x71\x75\151\x63\153\163\x65\141\x72\143\150\x5f\146\x69\145\x6c\x64" => array("\x6e\x61\155\145"), "\161\165\151\143\x6b\x73\x65\x61\162\x63\150\137\160\162\x69\157\162\151\164\x79" => 1, "\161\x75\x69\x63\153\163\145\x61\162\x63\150\x5f\163\x70\x6c\151\164\137\x74\x65\x72\155\x73" => false, "\146\151\x6c\164\x65\x72\163" => array(array("\x69\144" => "\x61\154\x6c\137\x72\145\143\x6f\x72\144\163", "\x6e\141\x6d\x65" => "\x4c\x42\114\137\x4c\111\x53\x54\x56\111\x45\127\137\106\111\114\124\x45\x52\x5f\x41\114\x4c", "\x66\x69\x6c\x74\x65\x72\x5f\144\145\146\x69\156\151\x74\151\157\x6e" => array(), "\x65\144\x69\164\141\x62\154\x65" => false), array("\x69\144" => "\141\x73\163\x69\147\156\145\x64\137\164\157\137\155\x65", "\x6e\x61\x6d\145" => "\x4c\102\114\137\x41\x53\x53\x49\107\x4e\105\x44\137\124\117\x5f\115\x45", "\146\151\x6c\x74\x65\162\137\144\x65\146\x69\x6e\151\164\x69\x6f\x6e" => array("\44\157\x77\x6e\x65\x72" => ''), "\145\x64\x69\164\x61\142\x6c\145" => false), array("\x69\144" => "\x66\141\166\157\x72\151\x74\145\163", "\x6e\x61\x6d\x65" => "\114\102\114\137\106\101\126\117\x52\x49\124\105\123", "\x66\151\x6c\x74\x65\x72\137\x64\145\x66\151\156\x69\x74\x69\157\156" => array("\44\x66\141\x76\157\x72\x69\x74\x65" => ''), "\145\144\x69\x74\x61\x62\154\x65" => false), array("\x69\144" => "\162\145\x63\x65\156\x74\x6c\x79\137\166\151\x65\x77\145\144", "\156\141\155\x65" => "\x4c\102\x4c\137\x52\x45\x43\105\x4e\124\x4c\x59\137\126\111\105\x57\x45\x44", "\146\x69\154\164\x65\x72\x5f\144\145\146\x69\x6e\151\x74\x69\157\156" => array("\x24\x74\x72\141\x63\x6b\145\162" => "\x2d\67\40\104\x41\131"), "\145\x64\151\164\x61\x62\154\145" => false), array("\151\144" => "\162\145\143\145\156\164\154\x79\137\x63\x72\145\x61\x74\145\x64", "\156\x61\155\x65" => "\x4c\102\x4c\137\x4e\x45\x57\x5f\122\x45\103\117\122\104\123", "\146\x69\154\164\x65\162\x5f\144\145\x66\x69\156\151\x74\151\x6f\x6e" => array("\x64\x61\x74\x65\x5f\x65\156\164\145\x72\145\x64" => array("\x24\144\x61\164\145\122\141\156\x67\145" => "\154\x61\x73\164\x5f\x37\x5f\x64\x61\171\x73")), "\145\x64\151\164\141\142\x6c\145" => false)));
