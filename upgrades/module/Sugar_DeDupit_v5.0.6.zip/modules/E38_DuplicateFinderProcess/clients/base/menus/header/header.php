<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $moduleName = "\x45\63\70\x5f\104\165\160\154\x69\x63\141\x74\145\x46\x69\x6e\144\145\x72\120\x72\x6f\143\x65\163\x73"; $viewdefs[$moduleName]["\x62\141\163\x65"]["\155\145\156\x75"]["\x68\145\141\x64\x65\x72"] = array(array("\162\x6f\165\164\145" => "\x23{$moduleName}\57\x63\x72\145\x61\164\x65", "\x6c\x61\142\x65\154" => "\114\116\113\x5f\116\x45\x57\x5f\122\x45\103\x4f\x52\x44", "\x61\x63\154\137\141\143\x74\x69\x6f\x6e" => "\x63\162\145\141\164\145", "\x61\143\154\x5f\155\157\144\165\x6c\145" => $moduleName, "\x69\143\157\156" => "\146\x61\55\160\x6c\165\x73"), array("\162\x6f\165\x74\145" => "\x23{$moduleName}", "\x6c\141\x62\x65\x6c" => "\x4c\116\x4b\137\114\x49\123\x54", "\141\x63\154\x5f\141\143\x74\x69\157\156" => "\x6c\151\163\x74", "\x61\x63\x6c\137\x6d\x6f\x64\165\x6c\x65" => $moduleName, "\x69\143\157\x6e" => "\x66\141\55\x62\141\x72\163"));
