<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\x5f\x44\165\x70\154\x69\143\141\x74\145\x46\x69\156\x64\x65\162\x50\162\157\143\145\163\163"; $viewdefs[$module_name]["\x6d\157\x62\x69\154\145"]["\x76\151\145\167"]["\145\144\x69\164"] = array("\x74\x65\x6d\160\154\x61\164\145\x4d\145\x74\141" => array("\155\x61\170\x43\157\154\x75\155\156\163" => "\x31", "\167\x69\x64\x74\x68\163" => array(array("\154\x61\x62\x65\154" => "\x31\x30", "\146\151\x65\x6c\144" => "\63\x30"), array("\x6c\x61\x62\x65\154" => "\x31\x30", "\x66\x69\145\x6c\x64" => "\63\60"))), "\x70\x61\156\145\154\163" => array(array("\154\x61\x62\x65\x6c" => "\x4c\x42\114\137\x50\x41\x4e\105\114\137\x44\105\x46\101\x55\114\x54", "\146\151\145\154\x64\163" => array("\x6e\141\155\145", "\141\x73\x73\x69\147\x6e\x65\x64\137\x75\163\145\x72\137\156\x61\155\145", "\164\x65\141\155\137\x6e\x61\x6d\145"))));
