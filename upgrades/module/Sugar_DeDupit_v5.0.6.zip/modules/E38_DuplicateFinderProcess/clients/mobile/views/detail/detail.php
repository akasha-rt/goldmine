<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\x33\x38\x5f\104\165\x70\x6c\151\143\141\x74\145\106\x69\x6e\144\145\162\x50\x72\x6f\143\145\x73\x73"; $viewdefs[$module_name]["\x6d\x6f\x62\151\154\x65"]["\166\x69\x65\x77"]["\144\x65\164\141\x69\x6c"] = array("\164\145\155\x70\154\x61\164\145\115\145\x74\141" => array("\146\x6f\162\155" => array("\x62\x75\x74\164\157\156\163" => array("\105\x44\111\124", "\104\125\120\114\x49\x43\101\x54\105", "\x44\105\x4c\x45\x54\x45")), "\155\x61\170\103\157\x6c\x75\155\156\x73" => "\61", "\167\151\x64\x74\x68\x73" => array(array("\154\x61\x62\x65\x6c" => "\61\x30", "\x66\x69\145\x6c\144" => "\63\60"), array("\x6c\x61\142\x65\x6c" => "\x31\x30", "\x66\151\145\x6c\144" => "\63\x30"))), "\x70\141\x6e\145\154\x73" => array(array("\154\141\142\x65\x6c" => "\114\102\114\x5f\120\x41\x4e\105\x4c\137\x44\x45\106\101\x55\x4c\124", "\x66\x69\145\154\144\x73" => array("\x6e\x61\x6d\x65", "\141\163\163\x69\x67\x6e\x65\x64\137\165\x73\x65\162\x5f\x6e\x61\x6d\145", "\x74\x65\x61\x6d\x5f\x6e\x61\155\x65"))));
