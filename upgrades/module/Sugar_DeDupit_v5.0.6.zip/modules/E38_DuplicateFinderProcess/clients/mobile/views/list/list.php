<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\165\147\141\x72\x45\x6e\x74\x72\171") || !sugarEntry)) { goto I_MFH; } die("\116\x6f\x74\40\x41\x20\x56\x61\154\x69\144\40\x45\156\x74\x72\x79\40\120\x6f\151\156\164"); I_MFH: $module_name = "\x45\63\70\x5f\x44\165\160\x6c\151\143\141\164\145\x46\151\x6e\144\145\x72\120\x72\157\x63\x65\x73\x73"; $viewdefs[$module_name]["\155\x6f\142\151\x6c\x65"]["\166\151\145\x77"]["\x6c\x69\163\x74"] = array("\160\141\x6e\x65\154\163" => array(array("\154\141\142\145\154" => "\x4c\102\x4c\137\x50\x41\x4e\x45\x4c\x5f\x44\105\x46\101\x55\114\x54", "\x66\151\x65\154\x64\163" => array(array("\156\141\x6d\x65" => "\156\x61\155\145", "\154\141\142\x65\x6c" => "\x4c\102\114\x5f\x4e\x41\115\105", "\144\x65\146\141\x75\x6c\x74" => true, "\145\156\141\142\x6c\145\x64" => true, "\x6c\151\x6e\x6b" => true), array("\x6e\141\155\145" => "\x74\145\141\x6d\137\x6e\x61\155\145", "\154\x61\x62\145\x6c" => "\x4c\102\114\x5f\x54\x45\101\115", "\144\145\146\141\165\x6c\164" => true, "\145\x6e\x61\142\154\x65\x64" => true), array("\156\x61\155\145" => "\x61\x73\x73\151\147\156\x65\x64\x5f\x75\163\145\x72\x5f\x6e\x61\x6d\145", "\x6c\x61\x62\x65\x6c" => "\x4c\102\114\137\x41\123\x53\111\107\x4e\x45\x44\x5f\124\x4f\137\x4e\101\x4d\105", "\144\x65\x66\x61\165\x6c\x74" => true, "\145\x6e\x61\x62\154\145\144" => true, "\154\x69\156\153" => true)))));
