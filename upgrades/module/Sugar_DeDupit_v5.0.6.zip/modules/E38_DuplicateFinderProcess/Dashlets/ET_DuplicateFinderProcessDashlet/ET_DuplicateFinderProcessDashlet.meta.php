<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\x75\x67\x61\x72\105\156\x74\162\171") || !sugarEntry)) { goto EuCqo; } die("\x4e\x6f\164\x20\101\40\126\141\154\151\x64\40\x45\x6e\x74\x72\171\40\x50\157\x69\156\164"); EuCqo: global $app_strings; $dashletMeta["\x45\63\x38\137\104\165\x70\154\151\143\x61\164\x65\x46\x69\156\x64\x65\162\120\162\157\x63\x65\x73\163\x44\x61\163\x68\154\145\x74"] = array("\155\x6f\x64\x75\x6c\x65" => "\x45\x33\x38\x5f\x44\165\160\154\151\143\141\x74\145\106\x69\x6e\144\145\162\120\162\157\143\145\x73\163", "\164\151\x74\x6c\x65" => translate("\x4c\102\x4c\137\x48\117\115\x45\120\101\x47\105\x5f\124\111\x54\114\105", "\x45\63\x38\137\x44\x75\160\154\151\143\x61\x74\x65\x46\x69\x6e\x64\145\162\x50\x72\157\x63\x65\x73\163"), "\144\x65\163\x63\162\151\160\164\151\157\x6e" => "\101\x20\x63\165\x73\164\157\x6d\151\x7a\x61\x62\x6c\145\x20\x76\x69\x65\x77\40\151\x6e\164\x6f\x20\105\63\70\137\x44\x75\160\x6c\x69\x63\x61\x74\x65\x46\151\x6e\x64\145\162\120\x72\x6f\x63\x65\163\163", "\151\x63\157\156" => "\x69\x63\x6f\x6e\x5f\x45\x33\x38\x5f\x44\x75\160\154\151\x63\x61\164\145\x46\x69\156\144\145\162\x50\x72\x6f\143\x65\x73\x73\137\63\x32\x2e\147\x69\146", "\x63\141\x74\x65\147\157\x72\171" => "\x4d\x6f\x64\165\x6c\145\40\x56\151\x65\167\163");
