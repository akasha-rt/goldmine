<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\x67\141\162\105\156\x74\162\x79") || !sugarEntry)) { goto ieRbG; } die("\x4e\x6f\164\40\101\x20\126\141\x6c\x69\144\x20\105\x6e\x74\x72\171\40\120\x6f\151\x6e\x74"); ieRbG: $module_name = "\105\x33\x38\x5f\x44\165\160\154\x69\x63\x61\x74\x65\106\x69\156\x64\145\x72\x50\x72\x6f\x63\x65\x73\x73"; $subpanel_layout = array("\x74\x6f\x70\x5f\x62\165\164\164\x6f\156\163" => array(array("\167\151\144\x67\x65\164\137\x63\x6c\x61\x73\x73" => "\123\x75\x62\x50\x61\156\145\154\x54\x6f\x70\x43\x72\x65\141\x74\x65\x42\x75\x74\164\157\x6e"), array("\167\151\x64\147\145\x74\x5f\143\x6c\141\x73\x73" => "\123\x75\142\x50\x61\x6e\x65\x6c\x54\x6f\160\x53\145\154\x65\x63\x74\x42\x75\164\x74\x6f\156", "\x70\157\x70\x75\x70\x5f\x6d\x6f\x64\165\x6c\x65" => $module_name)), "\x77\x68\145\x72\145" => '', "\x6c\151\163\x74\137\146\151\x65\154\x64\163" => array("\156\141\x6d\145" => array("\x76\156\141\x6d\145" => "\x4c\102\114\137\x4e\x41\x4d\105", "\167\151\144\x67\145\x74\137\x63\154\x61\x73\x73" => "\123\x75\x62\x50\x61\x6e\145\154\104\145\164\141\x69\154\x56\151\145\x77\x4c\151\x6e\153", "\x77\x69\144\164\x68" => "\64\x35\x25"), "\144\141\164\145\137\155\157\x64\x69\146\x69\x65\144" => array("\166\156\x61\155\145" => "\x4c\102\x4c\137\104\x41\x54\105\x5f\115\x4f\x44\111\106\x49\105\104", "\x77\151\144\x74\150" => "\x34\x35\x25"), "\x65\144\151\x74\x5f\x62\165\x74\164\x6f\156" => array("\x76\156\x61\155\x65" => "\x4c\x42\x4c\137\x45\104\x49\124\137\x42\125\124\124\x4f\x4e", "\167\x69\144\x67\145\164\x5f\143\x6c\141\x73\163" => "\123\x75\142\120\x61\156\x65\x6c\105\x64\x69\164\102\x75\164\164\x6f\156", "\x6d\x6f\144\165\154\x65" => $module_name, "\x77\151\x64\x74\150" => "\x34\45"), "\162\x65\155\157\166\x65\137\142\165\164\x74\x6f\156" => array("\x76\x6e\141\155\145" => "\114\x42\x4c\x5f\122\x45\x4d\x4f\126\105", "\167\151\x64\x67\145\x74\137\143\x6c\141\x73\163" => "\123\165\142\x50\141\x6e\x65\154\x52\x65\155\x6f\x76\145\x42\x75\164\x74\x6f\156", "\x6d\x6f\144\x75\154\x65" => $module_name, "\167\151\144\164\x68" => "\x35\45")));
