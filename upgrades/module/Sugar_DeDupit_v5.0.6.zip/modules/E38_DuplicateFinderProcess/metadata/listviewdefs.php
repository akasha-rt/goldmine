<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\x67\x61\162\105\x6e\164\x72\x79") || !sugarEntry)) { goto rBzsA; } die("\x4e\x6f\164\x20\101\40\126\x61\154\151\x64\40\x45\156\x74\162\171\x20\120\x6f\151\156\x74"); rBzsA: $module_name = "\x45\x33\70\137\104\x75\160\154\151\143\141\164\145\106\151\156\144\145\x72\x50\162\157\143\x65\163\x73"; $listViewDefs[$module_name] = array("\116\101\115\x45" => array("\x77\x69\144\164\150" => "\x33\x32", "\154\x61\x62\145\x6c" => "\114\102\114\137\116\101\x4d\105", "\144\145\146\141\165\154\164" => true, "\154\x69\156\x6b" => true), "\124\105\x41\x4d\x5f\x4e\x41\115\105" => array("\x77\x69\x64\164\x68" => "\x39", "\x6c\141\x62\145\x6c" => "\114\102\x4c\x5f\x54\105\101\115", "\144\x65\x66\141\165\x6c\x74" => false), "\x41\x53\123\x49\107\x4e\105\104\x5f\125\x53\105\122\x5f\x4e\x41\x4d\105" => array("\167\151\144\x74\150" => "\71", "\x6c\141\x62\145\x6c" => "\x4c\102\114\137\x41\x53\x53\x49\107\x4e\x45\x44\x5f\x54\x4f\x5f\116\101\115\x45", "\x6d\157\144\x75\154\x65" => "\x45\x6d\160\154\x6f\171\x65\145\163", "\x69\144" => "\x41\123\123\111\107\x4e\105\104\137\125\x53\x45\x52\x5f\111\x44", "\x64\x65\x66\x61\165\x6c\164" => true));
