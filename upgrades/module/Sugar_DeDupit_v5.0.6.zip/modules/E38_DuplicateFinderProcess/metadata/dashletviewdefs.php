<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\163\x75\x67\x61\x72\105\x6e\164\162\171") || !sugarEntry)) { goto iysG1; } die("\x4e\x6f\164\x20\x41\x20\126\x61\x6c\151\x64\x20\105\x6e\x74\x72\x79\40\x50\x6f\x69\x6e\x74"); iysG1: global $current_user; $dashletData["\105\63\70\137\x44\165\x70\154\x69\143\x61\x74\x65\106\x69\156\x64\145\x72\x50\162\157\x63\145\x73\163\104\x61\163\150\154\x65\x74"]["\163\x65\141\162\143\x68\106\x69\145\154\x64\163"] = array("\144\141\x74\145\137\x65\156\x74\145\162\145\x64" => array("\x64\x65\146\x61\x75\154\x74" => ''), "\144\x61\x74\x65\x5f\155\x6f\x64\151\x66\x69\145\144" => array("\x64\145\x66\x61\165\154\164" => ''), "\164\145\141\155\137\151\x64" => array("\144\145\146\141\x75\154\164" => ''), "\141\x73\163\x69\x67\156\145\144\137\165\163\145\x72\137\x69\x64" => array("\164\171\x70\145" => "\x61\x73\x73\x69\x67\x6e\145\x64\137\x75\163\145\x72\137\x6e\x61\x6d\x65", "\x64\145\146\x61\165\x6c\164" => $current_user->name)); $dashletData["\x45\x33\70\x5f\x44\165\160\x6c\x69\143\141\x74\x65\106\x69\x6e\x64\x65\162\120\x72\x6f\143\x65\163\163\104\141\163\x68\x6c\145\164"]["\x63\x6f\x6c\x75\x6d\156\163"] = array("\156\141\155\x65" => array("\x77\x69\x64\164\150" => "\x34\60", "\154\141\142\x65\154" => "\114\102\114\x5f\114\111\123\x54\137\x4e\101\x4d\105", "\x6c\x69\x6e\x6b" => true, "\x64\145\x66\x61\165\154\x74" => true), "\x64\141\164\145\137\145\x6e\164\145\x72\145\144" => array("\167\151\x64\x74\x68" => "\61\x35", "\154\x61\142\145\154" => "\114\102\x4c\x5f\104\x41\124\x45\x5f\x45\x4e\124\x45\x52\105\x44", "\x64\145\x66\x61\x75\x6c\164" => true), "\x64\x61\x74\x65\x5f\x6d\x6f\x64\151\x66\151\145\x64" => array("\x77\151\144\x74\x68" => "\x31\x35", "\154\141\x62\145\154" => "\114\x42\x4c\x5f\x44\101\124\x45\137\x4d\x4f\x44\111\x46\111\x45\104"), "\x63\x72\145\x61\x74\145\144\137\142\x79" => array("\167\151\144\x74\150" => "\x38", "\x6c\x61\142\145\x6c" => "\114\x42\114\137\103\122\105\101\x54\105\x44"), "\x61\x73\163\151\147\x6e\145\x64\x5f\165\163\145\162\137\x6e\141\x6d\x65" => array("\x77\151\x64\164\150" => "\x38", "\154\141\142\x65\154" => "\114\x42\114\137\114\x49\123\124\x5f\x41\123\123\111\x47\116\105\104\137\125\x53\105\122"), "\164\145\x61\155\x5f\x6e\x61\155\x65" => array("\x77\151\x64\x74\x68" => "\61\65", "\x6c\141\x62\x65\154" => "\x4c\102\114\137\114\111\123\x54\x5f\x54\x45\x41\x4d"));
