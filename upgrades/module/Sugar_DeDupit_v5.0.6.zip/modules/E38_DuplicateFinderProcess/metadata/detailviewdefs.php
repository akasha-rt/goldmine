<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\x45\63\70\137\x44\165\x70\154\x69\x63\141\164\x65\x46\x69\156\x64\145\162\x50\162\157\x63\145\163\163"; $viewdefs[$module_name]["\104\145\164\141\x69\154\x56\151\x65\x77"] = array("\164\145\x6d\160\x6c\x61\x74\145\115\145\x74\x61" => array("\x66\157\162\155" => array("\142\165\164\x74\157\156\x73" => array("\105\x44\x49\x54", "\104\125\x50\114\x49\103\x41\x54\x45", "\104\x45\114\105\124\x45", "\106\111\x4e\x44\x5f\x44\125\120\114\x49\103\x41\124\105\x53")), "\x6d\141\x78\x43\157\154\165\155\x6e\x73" => "\x32", "\167\151\144\164\150\163" => array(array("\154\141\142\x65\x6c" => "\61\60", "\146\x69\145\x6c\144" => "\x33\60"), array("\x6c\x61\142\145\154" => "\61\x30", "\146\x69\x65\x6c\x64" => "\63\x30"))), "\160\x61\156\x65\x6c\163" => array(array("\x6e\141\x6d\145", "\141\x73\x73\x69\147\156\145\144\x5f\x75\163\145\162\137\x6e\141\155\x65"), array("\164\x65\x61\155\137\156\x61\x6d\145", ''), array(array("\x6e\141\155\x65" => "\x64\141\164\145\x5f\x65\x6e\164\145\x72\145\144", "\x63\165\163\164\157\155\x43\x6f\144\145" => "\173\x24\x66\x69\x65\x6c\144\163\56\144\x61\164\145\137\x65\156\x74\x65\x72\x65\144\56\166\141\154\165\x65\x7d\x20\x7b\44\x41\120\x50\x2e\x4c\x42\114\137\x42\x59\175\40\x7b\x24\x66\x69\x65\x6c\x64\163\56\143\162\145\141\x74\x65\144\x5f\x62\x79\137\x6e\x61\x6d\145\x2e\166\141\154\x75\x65\x7d", "\154\x61\x62\x65\x6c" => "\x4c\102\114\x5f\104\101\124\105\x5f\105\116\x54\105\x52\105\104"), array("\x6e\141\x6d\x65" => "\144\x61\164\x65\x5f\155\157\x64\151\146\x69\145\x64", "\143\165\163\x74\x6f\155\x43\x6f\144\145" => "\173\44\x66\151\x65\x6c\144\163\56\x64\x61\164\x65\137\155\x6f\x64\x69\146\x69\145\x64\56\x76\141\x6c\x75\x65\175\40\173\44\x41\120\120\x2e\x4c\102\114\137\x42\131\x7d\x20\173\44\x66\151\145\154\x64\163\56\155\157\144\x69\x66\151\x65\x64\x5f\x62\171\x5f\156\141\x6d\145\56\166\141\154\165\x65\x7d", "\154\x61\x62\x65\154" => "\x4c\102\114\137\x44\101\x54\105\137\x4d\x4f\x44\x49\x46\111\105\104")), array("\144\x65\x73\143\162\151\160\x74\x69\157\156")));
