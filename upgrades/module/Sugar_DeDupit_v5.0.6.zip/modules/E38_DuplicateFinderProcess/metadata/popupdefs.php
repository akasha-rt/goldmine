<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  if (!(!defined("\x73\165\147\x61\162\105\156\x74\x72\171") || !sugarEntry)) { goto hghK3; } die("\x4e\157\164\40\101\x20\126\x61\154\151\x64\x20\105\156\x74\162\171\40\x50\x6f\x69\x6e\x74"); hghK3: $module_name = "\x45\63\x38\x5f\104\x75\160\154\151\x63\141\164\145\x46\151\x6e\144\145\x72\x50\162\x6f\x63\x65\x73\163"; $object_name = "\x45\x33\x38\137\104\165\160\154\x69\x63\141\x74\x65\106\x69\156\x64\x65\162\120\162\157\143\x65\x73\x73"; $_module_name = "\145\x33\x38\137\144\165\160\154\x69\143\141\x74\x65\146\x69\156\x64\145\x72\160\162\x6f\x63\145\163\163"; $popupMeta = array("\155\x6f\144\165\154\x65\x4d\x61\151\156" => $module_name, "\166\x61\x72\x4e\x61\155\145" => $object_name, "\157\x72\144\x65\x72\x42\171" => $_module_name . "\56\x6e\x61\x6d\x65", "\x77\x68\145\x72\x65\103\x6c\x61\165\163\x65\163" => array("\156\141\155\x65" => $_module_name . "\56\156\x61\155\145"), "\x73\x65\141\162\143\x68\111\x6e\160\165\164\x73" => array($_module_name . "\x5f\156\165\155\142\x65\162", "\156\x61\155\x65", "\160\162\151\x6f\162\151\x74\x79", "\x73\x74\x61\x74\x75\163"));
