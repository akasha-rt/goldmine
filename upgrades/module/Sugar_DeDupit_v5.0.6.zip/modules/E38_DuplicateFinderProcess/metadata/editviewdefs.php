<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\x33\x38\137\x44\x75\160\x6c\x69\x63\141\x74\145\x46\x69\156\x64\x65\x72\x50\x72\x6f\x63\145\163\163"; $viewdefs[$module_name]["\x45\144\151\164\x56\151\145\x77"] = array("\164\145\x6d\x70\x6c\x61\x74\145\x4d\145\164\141" => array("\155\x61\170\103\157\x6c\x75\x6d\x6e\163" => "\x32", "\167\151\144\164\150\163" => array(array("\154\141\142\x65\154" => "\x31\60", "\x66\x69\145\154\144" => "\63\60"), array("\x6c\x61\142\145\x6c" => "\61\x30", "\x66\x69\x65\x6c\144" => "\x33\x30"))), "\x70\141\156\145\x6c\x73" => array("\144\x65\146\x61\165\154\x74" => array(array("\x6e\x61\x6d\145", "\141\163\163\x69\147\156\145\x64\137\x75\163\145\162\x5f\156\141\155\145"), array(array("\156\x61\x6d\x65" => "\164\145\x61\155\x5f\156\x61\x6d\x65", "\x64\x69\163\160\154\141\171\120\141\x72\141\155\163" => array("\x64\151\x73\x70\x6c\x61\171" => true)), ''), array("\144\x65\163\143\162\x69\x70\x74\151\157\156"))));
