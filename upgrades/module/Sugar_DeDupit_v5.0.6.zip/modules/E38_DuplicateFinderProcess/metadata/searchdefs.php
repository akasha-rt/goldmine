<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $module_name = "\105\63\x38\x5f\x44\x75\160\154\x69\143\x61\164\x65\106\x69\x6e\x64\145\162\x50\x72\157\x63\x65\x73\163"; $searchdefs[$module_name] = array("\x74\145\x6d\x70\154\141\164\145\x4d\145\164\x61" => array("\155\141\170\103\157\154\x75\x6d\156\163" => "\63", "\155\141\170\x43\157\x6c\x75\x6d\x6e\x73\102\x61\x73\x69\143" => "\x34", "\167\x69\x64\x74\x68\163" => array("\154\x61\142\145\x6c" => "\x31\60", "\146\151\x65\154\144" => "\63\60")), "\154\141\171\x6f\x75\x74" => array("\142\x61\x73\x69\143\137\163\x65\x61\162\143\150" => array("\x6e\141\155\145", array("\156\x61\x6d\x65" => "\x63\165\162\x72\145\x6e\164\137\x75\x73\145\x72\x5f\x6f\x6e\x6c\171", "\154\141\142\145\154" => "\114\x42\114\x5f\x43\125\x52\122\x45\x4e\124\137\125\x53\x45\x52\x5f\106\111\114\x54\x45\x52", "\164\x79\160\145" => "\142\157\x6f\x6c"), array("\x6e\141\155\145" => "\146\x61\x76\x6f\x72\151\x74\145\163\x5f\157\156\x6c\x79", "\154\141\x62\145\x6c" => "\x4c\x42\x4c\137\x46\101\x56\117\122\x49\124\x45\123\137\106\x49\114\x54\105\x52", "\x74\x79\x70\x65" => "\x62\157\x6f\x6c")), "\x61\144\x76\x61\x6e\x63\x65\144\x5f\x73\145\141\x72\143\150" => array("\156\x61\155\145", array("\156\x61\x6d\x65" => "\141\x73\163\151\x67\x6e\145\x64\x5f\x75\163\x65\162\137\x69\144", "\x6c\x61\142\x65\x6c" => "\x4c\x42\114\137\101\x53\123\111\107\116\x45\104\x5f\x54\x4f", "\x74\x79\x70\x65" => "\145\x6e\165\x6d", "\146\x75\156\x63\x74\x69\x6f\x6e" => array("\x6e\141\155\145" => "\147\x65\164\137\x75\x73\x65\162\x5f\141\x72\162\x61\171", "\x70\x61\x72\141\x6d\x73" => array(false))), array("\156\x61\155\145" => "\x66\x61\166\157\162\151\x74\x65\x73\137\157\156\154\171", "\154\x61\x62\145\154" => "\114\x42\x4c\137\106\x41\126\x4f\x52\x49\x54\x45\x53\137\x46\x49\x4c\x54\105\122", "\x74\171\160\145" => "\x62\157\157\154"))));
