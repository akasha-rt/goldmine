<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $hook_array["\x61\146\164\145\x72\137\144\145\x6c\145\164\x65"][] = array(22, "\x44\x65\154\x65\164\145\x73\x20\x65\x76\145\162\171\164\x68\x69\x6e\147\40\x72\x65\154\141\x74\145\x64\x20\164\x6f\40\104\145\x44\x75\x70\x69\164\54\40\151\x66\40\144\x65\x6c\145\164\145\x64\x20\142\x65\141\x6e\x20\x77\x61\163\40\151\x6e\x20\x44\145\x44\165\160\151\164\x20\x73\x79\163\x74\x65\x6d", "\x6d\157\x64\165\154\x65\x73\57\x45\x33\x38\137\104\x75\160\x6c\151\x63\141\164\x65\x46\151\x6e\x64\x65\x72\120\162\x6f\x63\x65\163\x73\57\x44\145\104\165\x70\151\x74\101\146\x74\x65\x72\x44\145\x6c\x65\x74\145\x2e\160\150\x70", "\x44\x65\x44\165\x70\x69\x74\x41\x66\x74\145\162\x44\x65\x6c\145\x74\145", "\x64\145\154\x65\x74\x65\x52\145\x6c\x61\164\x65\144\104\x65\104\165\160\151\x74\x52\145\x63\x6f\x72\144\x73"); $hook_array["\x61\x66\164\145\x72\x5f\x73\x61\x76\145"][] = array(23, "\104\145\x74\145\x63\164\163\x20\144\x75\160\x6c\151\x63\141\x74\x65\163\40\146\x6f\162\40\x73\141\x76\145\144\x20\142\x65\141\x6e", "\155\157\144\x75\154\145\x73\57\105\63\70\x5f\104\x75\160\154\151\143\x61\164\145\x46\x69\x6e\144\x65\x72\120\x72\x6f\143\145\163\163\x2f\x44\145\104\165\x70\x69\164\x41\146\x74\x65\162\x53\141\166\x65\56\160\150\x70", "\x44\145\104\165\x70\151\164\101\x66\164\145\x72\123\141\x76\145", "\x63\x68\x65\x63\153\x46\157\x72\104\165\160\154\151\x63\x61\164\x65\x73");
