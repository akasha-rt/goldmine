<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $hook_array["\141\146\x74\x65\x72\x5f\163\x61\166\x65"][] = array(1, "\103\150\x65\143\153\x20\151\146\x20\160\x61\151\x72\40\167\141\x73\x20\x69\147\156\157\x72\x65\x64\x20\x61\x6e\x64\40\x69\147\x6e\157\x72\x65\x20\x61\x6c\x6c\40\x6f\x74\x68\x65\x72\40\160\141\151\162\x20\x69\x6e\163\x74\141\156\143\145\163\40\x66\x6f\x72\40\157\164\x68\x65\x72\40\x70\162\157\143\x65\163\x73\145\x73", "\x6d\157\144\165\154\x65\x73\57\x45\x33\x38\x5f\106\x6f\165\156\x64\x44\x75\x70\x6c\151\143\141\164\x65\163\x2f\104\x65\x44\x75\160\x69\164\110\x6f\157\153\114\x6f\x67\151\143\56\x70\x68\x70", "\x44\x65\104\x75\x70\x69\x74\x48\x6f\x6f\153\114\x6f\x67\151\143", "\x69\x67\x6e\157\x72\x65\117\164\x68\145\162\120\x61\x69\162\x73");
