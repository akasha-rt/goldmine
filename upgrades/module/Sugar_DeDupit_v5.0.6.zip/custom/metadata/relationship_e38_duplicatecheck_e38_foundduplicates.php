<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $dictionary["\145\63\70\x5f\144\165\160\154\151\x63\141\x74\x65\143\150\145\x63\153\x5f\145\x33\70\137\x66\157\165\x6e\x64\x64\x75\x70\154\151\143\x61\164\145\163"] = array("\164\x61\x62\154\x65" => "\145\63\x38\x5f\x64\165\160\154\151\143\x61\164\x65\x63\150\145\x63\x6b\137\145\63\x38\x5f\146\157\165\156\x64\144\165\x70\x6c\x69\x63\x61\164\x65\x73", "\146\x69\145\x6c\x64\x73" => array("\x69\144" => array("\156\141\x6d\x65" => "\x69\x64", "\164\171\x70\145" => "\166\141\x72\143\150\141\162", "\154\x65\x6e" => "\x33\66"), "\x65\63\70\137\144\165\x70\154\x69\143\x61\x74\145\143\150\145\x63\153\137\x69\144" => array("\x6e\x61\x6d\x65" => "\x65\63\70\137\144\x75\x70\154\x69\143\141\164\145\143\150\145\143\153\x5f\x69\x64", "\x74\171\160\145" => "\x76\x61\162\x63\x68\141\x72", "\x6c\x65\156" => "\x33\x36"), "\145\x33\70\137\x66\x6f\165\156\x64\144\x75\x70\154\x69\x63\x61\164\x65\x73\137\x69\144" => array("\x6e\x61\155\x65" => "\x65\x33\70\137\146\x6f\x75\156\x64\144\x75\160\x6c\151\x63\141\x74\145\163\137\x69\144", "\x74\171\160\x65" => "\x76\x61\x72\143\x68\x61\162", "\154\145\x6e" => "\63\66"), "\144\x61\164\145\137\x6d\x6f\x64\x69\x66\151\x65\144" => array("\x6e\141\155\145" => "\x64\x61\x74\145\x5f\x6d\x6f\144\151\146\x69\x65\144", "\164\171\x70\145" => "\144\141\x74\145\164\151\x6d\145"), "\x64\x65\154\x65\x74\x65\144" => array("\x6e\141\155\x65" => "\144\x65\x6c\145\x74\x65\x64", "\164\171\160\145" => "\142\157\157\x6c", "\154\145\156" => "\61", "\162\145\x71\x75\151\x72\x65\144" => false, "\144\145\x66\141\x75\154\x74" => "\60")), "\x69\x6e\x64\x69\143\x65\163" => array(array("\156\x61\x6d\x65" => "\x65\63\x38\x5f\x64\x75\160\x6c\151\143\141\164\145\x63\150\x65\143\x6b\x5f\x65\63\x38\137\x66\x6f\165\156\x64\144\x75\x70\x6c\151\x63\141\164\145\x73\163\x70\153", "\164\171\x70\145" => "\160\x72\151\155\x61\x72\171", "\x66\x69\145\154\144\163" => array("\x69\x64")), array("\x6e\141\155\x65" => "\x69\144\170\x5f\x65\x33\x38\x5f\x64\x75\160\x6c\151\x63\x61\x74\145\143\x68\x65\x63\153\137\145\63\70\x5f\x66\157\165\x6e\x64\x64\x75\x70\154\151\x63\x61\x74\x65\x73", "\x74\171\160\x65" => "\141\x6c\164\145\162\x6e\141\x74\x65\137\153\x65\171", "\x66\x69\145\x6c\144\163" => array("\145\63\70\137\144\165\160\x6c\151\143\141\x74\x65\143\x68\x65\143\x6b\137\151\x64", "\145\x33\x38\137\146\x6f\x75\x6e\144\x64\165\x70\154\151\x63\141\x74\145\x73\x5f\x69\144")), array("\156\x61\x6d\x65" => "\x69\x64\170\x5f\144\165\160\143\150\x63\x6b\x69\x64\137\x64\x65\154\x5f\146\x6e\144\x64\x75\160\151\144", "\164\x79\x70\145" => "\x69\x6e\x64\145\x78", "\146\x69\145\x6c\x64\163" => array("\145\63\70\137\x64\x75\160\x6c\151\x63\x61\x74\x65\143\150\145\143\x6b\x5f\x69\x64", "\144\x65\x6c\145\164\x65\144", "\145\63\x38\x5f\146\157\x75\x6e\144\x64\165\160\x6c\x69\143\141\x74\145\163\x5f\151\x64"))), "\162\x65\x6c\141\x74\x69\157\x6e\x73\150\151\x70\x73" => array("\x65\x33\70\x5f\144\x75\x70\x6c\x69\143\141\164\x65\x63\x68\145\x63\x6b\x5f\145\63\x38\137\x66\157\x75\x6e\144\144\x75\160\x6c\151\143\141\164\145\163" => array("\x6c\x68\163\137\155\x6f\x64\x75\x6c\x65" => "\105\x33\x38\x5f\x44\x75\160\x6c\151\x63\141\164\145\x43\x68\x65\143\153", "\x6c\150\x73\x5f\164\x61\x62\x6c\145" => "\145\63\x38\x5f\x64\x75\x70\x6c\151\143\x61\x74\x65\143\x68\145\x63\x6b", "\154\x68\163\x5f\153\145\x79" => "\x69\x64", "\162\150\163\137\x6d\x6f\x64\x75\154\x65" => "\x45\63\70\137\x46\x6f\165\x6e\x64\104\165\160\x6c\x69\143\x61\164\145\163", "\x72\150\163\137\164\x61\142\154\x65" => "\x65\x33\x38\x5f\x66\157\165\x6e\x64\144\x75\x70\154\151\143\x61\x74\145\163", "\x72\150\163\x5f\x6b\x65\x79" => "\x69\144", "\x72\145\154\x61\164\151\157\156\163\150\151\160\x5f\x74\171\x70\x65" => "\155\141\156\171\55\164\157\55\x6d\141\x6e\171", "\152\157\151\156\137\164\141\142\x6c\145" => "\x65\63\70\x5f\144\165\x70\x6c\x69\143\141\164\145\x63\150\x65\x63\153\137\145\x33\70\137\x66\157\x75\x6e\x64\144\165\160\x6c\x69\143\x61\164\145\163", "\152\x6f\151\x6e\137\x6b\x65\171\x5f\x6c\150\163" => "\145\63\70\137\x64\x75\160\154\151\x63\141\164\x65\143\x68\x65\143\153\x5f\x69\144", "\x6a\157\151\156\x5f\153\145\171\x5f\x72\x68\163" => "\145\x33\x38\x5f\146\157\165\x6e\144\144\x75\x70\x6c\151\x63\141\x74\145\163\137\151\144")));
