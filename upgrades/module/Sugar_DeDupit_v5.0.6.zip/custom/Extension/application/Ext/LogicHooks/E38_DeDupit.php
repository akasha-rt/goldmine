<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $hook_array["\141\146\164\x65\162\x5f\x64\x65\154\145\x74\x65"][] = array(22, "\x44\145\154\145\164\145\163\40\x65\166\145\162\171\x74\x68\x69\x6e\x67\40\162\145\154\x61\164\145\x64\40\164\x6f\40\104\x65\104\x75\x70\151\164\x2c\x20\151\146\40\144\x65\154\x65\164\x65\144\40\x62\145\x61\156\40\x77\141\x73\40\x69\156\40\104\145\x44\165\x70\151\164\x20\163\x79\163\164\x65\155", "\x6d\157\x64\165\154\x65\x73\x2f\x45\63\70\x5f\104\x75\x70\154\151\x63\141\164\145\x46\x69\x6e\x64\x65\162\120\x72\x6f\x63\x65\163\x73\x2f\104\145\104\x75\160\x69\x74\x41\x66\164\x65\162\104\145\154\x65\164\x65\56\160\x68\160", "\104\x65\x44\165\x70\151\x74\101\146\x74\x65\162\x44\145\x6c\x65\164\145", "\x64\x65\154\145\x74\145\122\x65\154\x61\164\145\144\x44\x65\x44\x75\x70\x69\164\x52\x65\x63\x6f\x72\144\163"); $hook_array["\141\146\164\x65\162\137\163\141\166\x65"][] = array(23, "\104\x65\164\145\x63\164\x73\x20\x64\165\x70\154\x69\143\141\x74\x65\163\x20\x66\x6f\x72\40\163\x61\166\145\x64\x20\142\145\141\156", "\x6d\157\x64\x75\154\145\163\57\x45\x33\70\x5f\104\165\x70\154\151\x63\x61\x74\x65\106\x69\x6e\144\145\162\120\162\157\143\x65\x73\x73\x2f\104\x65\x44\165\x70\x69\x74\x41\x66\x74\145\162\123\x61\x76\x65\x2e\x70\x68\160", "\x44\145\x44\x75\160\151\x74\101\146\164\145\x72\123\x61\166\145", "\143\x68\x65\143\x6b\106\x6f\162\x44\165\160\x6c\x69\143\x61\x74\145\x73");
