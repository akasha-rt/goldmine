<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $admin_option_defs = array(); $admin_option_defs["\x41\x64\x6d\151\x6e\151\163\164\162\x61\164\151\x6f\156"]["\166\x61\154\x69\x64\x61\x74\145\x5f\154\x69\x63\145\156\x73\x65\x5f\x65\x33\70\137\144\145\144\x75\160\x69\164"] = array("\x43\x6f\156\164\x72\141\143\164\x73", "\114\x42\114\137\x56\x41\x4c\111\x44\101\x54\105\x5f\x4c\111\103\x45\x4e\x53\x45\x5f\x45\63\70\x5f\x44\x45\x44\125\120\111\x54\137\114\x49\x4e\113\x5f\x4e\101\x4d\105", "\x4c\102\114\x5f\126\x41\x4c\x49\104\x41\x54\105\137\x4c\111\103\105\x4e\x53\x45\137\x45\x33\x38\137\x44\105\x44\125\120\x49\x54\137\114\x49\116\113\137\104\x45\123\103\122\x49\120\124\111\x4f\116", "\152\x61\166\141\x73\x63\x72\151\x70\x74\x3a\160\x61\x72\145\156\x74\56\123\x55\107\x41\122\56\101\160\160\56\x72\157\165\164\145\162\x2e\x6e\141\x76\151\147\x61\164\145\x28\42\x23\105\63\x38\137\x44\x75\x70\x6c\151\x63\141\x74\x65\106\x69\156\x64\x65\162\x50\x72\157\143\145\163\163\57\x6c\x61\x79\x6f\x75\164\x2f\154\151\143\x65\156\163\x65\55\143\x6f\x6e\146\x69\147\x75\162\x61\x74\151\157\156\42\x2c\40\173\x74\162\x69\147\147\x65\162\x3a\40\164\162\x75\x65\x7d\51\x3b"); $admin_option_defs["\101\x64\x6d\151\x6e\151\x73\164\x72\x61\x74\151\157\156"]["\x73\165\160\x70\157\x72\x74\137\x65\x33\x38\137\x64\145\x64\x75\160\x69\x74"] = array("\x41\144\155\151\156\x69\x73\x74\162\141\164\151\x6f\x6e", "\x4c\102\114\x5f\105\63\x38\137\x44\105\x44\x55\120\111\124\x5f\123\x55\x50\x50\117\x52\x54", "\x4c\102\x4c\137\105\x33\70\137\x44\x45\x44\125\x50\x49\x54\137\123\x55\x50\x50\117\122\124\137\x44\x45\x53\x43\x52\111\x50\x54\x49\117\116", "\x6a\141\x76\x61\163\143\x72\151\160\164\x3a\x76\x6f\151\x64\x20\x77\x69\156\144\157\167\56\157\160\x65\156\50\42\150\164\x74\160\x73\72\57\57\x33\70\145\154\x65\x6d\145\156\x74\x73\56\141\164\154\141\163\163\x69\x61\156\56\x6e\145\x74\57\163\x65\162\x76\151\143\145\144\145\x73\153\57\x63\x75\163\x74\x6f\x6d\145\162\57\160\x6f\x72\x74\x61\x6c\x2f\61\x22\x2c\x22\x5f\x62\x6c\x61\x6e\x6b\42\x29\73"); $admin_group_header[] = array("\x4c\102\114\137\x45\63\70\x5f\104\x45\x44\125\120\x49\x54\x5f\123\105\103\124\x49\117\116\137\110\105\x41\x44\x45\x52", '', false, $admin_option_defs, "\114\x42\114\x5f\x45\63\x38\x5f\x44\105\104\125\120\x49\x54\137\123\x45\103\x54\x49\x4f\116\137\x44\105\123\103\122\x49\x50\x54\x49\x4f\x4e");
