<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $mod_strings["\x4c\102\114\137\105\x33\70\137\104\x55\x50\x4c\111\103\101\124\x45\x43\x48\105\103\x4b"] = "\x44\x65\104\165\x70\x69\x74\x20\55\40\103\150\x65\x63\x6b\40\x66\x6f\x72\40\x64\165\160\x6c\151\x63\141\164\145\163"; $mod_strings["\x4c\102\114\x5f\x45\x33\x38\x5f\x41\125\x54\x4f\x4d\105\122\x47\x45\x44\125\x50\114\111\x43\101\x54\x45\123"] = "\104\145\104\165\x70\151\x74\40\55\40\101\165\x74\157\x20\x6d\145\x72\x67\x65\x20\144\x75\160\154\151\143\x61\164\145\163"; $mod_strings["\114\x42\x4c\137\x45\63\x38\137\x52\x55\116\116\111\x4e\107\112\x4f\102\x53\111\116\123\120\x45\x43\x54\111\117\x4e"] = "\x44\x65\104\165\160\151\x74\x20\x2d\40\x4a\x6f\142\x73\40\x69\156\x73\x70\145\x63\x74\151\157\156";
