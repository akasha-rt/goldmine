<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\142\x61\x73\x65"]["\166\151\145\x77"]["\x65\x33\x38\55\144\145\x64\x75\160\151\x74\55\162\145\x63\157\162\144\55\x64\x61\x73\150\x6c\145\x74"] = array("\x64\141\x73\150\x6c\145\x74\x73" => array(array("\x6c\141\x62\145\x6c" => "\x4c\102\114\x5f\105\x33\70\x5f\x44\x45\104\x55\120\111\x54\x5f\x52\105\103\x4f\x52\x44\137\x44\x41\123\x48\x4c\x45\x54", "\144\x65\x73\x63\162\151\160\x74\x69\157\156" => "\x4c\x42\114\137\x45\63\70\x5f\x44\x45\104\125\120\111\124\x5f\x52\105\103\x4f\122\104\x5f\x44\101\123\110\x4c\105\124\x5f\x44\x45\123\103\x52\111\120\124\x49\117\116", "\143\x6f\x6e\x66\x69\147" => array(), "\x66\x69\x6c\x74\x65\x72" => array("\166\x69\x65\x77" => "\162\x65\143\x6f\162\144"))));
