<?php

/**
 * @author 38 Elements DOO
 *
 * 38 Elements DOO ("COMPANY") CONFIDENTIAL
 *
 * Copyright (c) 2020 38 Elements DOO, Belgrade, Serbia - All Rights Reserved
 *
 * NOTICE:  All information contained herein is, and remains the property
 * of COMPANY. The intellectual and technical concepts contained herein are
 * proprietary to COMPANY and may be covered by Serbia and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material is strictly
 * forbidden unless prior written permission is obtained from COMPANY.
 * Access to the source code contained herein is hereby forbidden to anyone except
 * current COMPANY employees, managers or contractors who have executed
 * Confidentiality and Non-disclosure agreements explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication
 * or disclosure  of  this source code, which includes information that is
 * confidential and/or proprietary, and is a trade secret, of  COMPANY.
 * ANY REPRODUCTION, MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE,OR PUBLIC
 * DISPLAY OF OR THROUGH USE  OF THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN
 * CONSENT OF COMPANY IS STRICTLY PROHIBITED, AND IN VIOLATION OF APPLICABLE LAWS
 * AND INTERNATIONAL TREATIES. THE RECEIPT OR POSSESSION OF  THIS SOURCE CODE
 * AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS TO REPRODUCE,
 * DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL ANYTHING
 * THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.
 *
 * Please contact 38 Elements DOO for further details at office@38elements.com
 */
 
  $viewdefs["\x62\141\163\145"]["\x76\x69\145\x77"]["\145\63\x38\x2d\x64\x65\144\165\160\x69\164\55\x68\151\x73\x74\x6f\x72\x79\x2d\x64\x61\163\150\154\145\x74"] = array("\144\141\163\150\x6c\145\164\163" => array(array("\x6c\141\x62\x65\154" => "\114\x42\114\137\x45\x33\70\x5f\104\105\104\125\x50\x49\x54\x5f\110\111\x53\x54\117\x52\131\137\x44\101\x53\110\114\x45\124", "\x64\x65\x73\143\x72\x69\x70\x74\x69\x6f\156" => "\114\102\114\x5f\x45\x33\70\137\104\105\x44\125\x50\111\x54\137\x48\111\x53\x54\117\122\131\137\104\x41\x53\110\x4c\x45\x54\137\104\105\123\x43\x52\x49\120\x54\111\117\116", "\x63\157\x6e\x66\151\x67" => array(), "\x66\151\154\164\145\x72" => array("\166\151\145\x77" => "\x72\x65\x63\x6f\x72\x64"))));
