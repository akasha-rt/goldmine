<?php

$viewdefs['fbsg_Licensing']['base']['view']['license-content'] = array(
    'panels' => array(
        array(
            'fields' => array(
                array(
                    'name' => 'description',
                    'type' => 'textarea',
                    'template' => 'edit',
                    'required' => true,
                    'placeholder' => 'LBL_FEEDBACK_TEXT_PLACEHOLDER',
                ),
            ),
        ),
    ),
);
