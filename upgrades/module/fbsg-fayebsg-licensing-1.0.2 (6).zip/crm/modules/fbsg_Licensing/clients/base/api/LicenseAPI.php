<?php

use Sugarcrm\Sugarcrm\custom\fbsg\licensing\LicenseFactory;

class LicenseAPI extends SugarApi
{

    public function registerApiRest()
    {
        return array(
            array(
                'reqType' => 'GET',
                'path' => array('fbsg', 'licensing', 'license'),
                'pathVars' => array('', '', ''),
                'method' => 'getLicense',
                'shortHelp' => 'Gets the License and validates that the provided license is valid',
            ),
            array(
                'reqType' => 'POST',
                'path' => array('fbsg', 'licensing', 'license'),
                'pathVars' => array('', '', ''),
                'method' => 'setLicense',
                'shortHelp' => 'Sets the Slack License and validates that the provided license is valid',
            ),
        );
    }

    function setLicense(ServiceBase $api, array $args)
    {
        $this->requireArgs($args, array('license_code', 'product_key'));

        LicenseFactory::getInstance()->setLicense($args['product_key'], $args['license_code']);

        return $this->getLicense($api, $args);

    }

    /**
     * @param ServiceBase $api
     * @param array $args
     * @return array
     * @throws SugarApiException
     */
    public function getLicense(ServiceBase $api, array $args = array())
    {
        global $sugar_config;

        $this->requireArgs($args, ['product_key']);

        $product_key = $args['product_key'];

        if (LicenseFactory::getInstance()->isValidLicense($product_key)) {
            return array(
                'ok' => true,
                'license_code' => $sugar_config['fbsg'][$product_key]['license_code'],
                'license' => $sugar_config['fbsg'][$product_key]
            );
        }

        throw new \Sugarcrm\Sugarcrm\custom\fbsg\licensing\LicenseException("This license provided for {$product_key} is not valid!");
    }
}
