({
    extendsFrom: 'HeaderpaneView',

    events: {
        'click [name=save_button]:not(".disabled")': 'initiateSave',
        'click a[name=cancel_button]': 'cancel'
    },

    productKey: null,

    initialize: function (options) {
        this._super('initialize', [options]);

        var key = window.location.hash.match(/product-key=(\w*)/i);
        this.productKey = key["1"];

        this.title = app.lang.get('LBL_' + this.productKey.toUpperCase() + '_LICENSE_CONFIGURATION', this.module);
        // console.log(this.productKey + ':license:toggle');
        this.context.on(this.productKey + ':license:toggle', this.toggleSendButton, this);
    },

    /**
     * Cancel and close the drawer
     */
    cancel: function () {
        app.router.navigate("#Administration", {trigger: true});
    },

    /**
     * Enable/disable the Save button
     *
     * @param enable true to enable, false to disable
     */
    toggleSendButton: function (enable) {
        this.$('[name=save_button]').toggleClass('disabled', !enable);
    },

    initiateSave: function () {
        this.context.trigger(this.productKey + ':license:save');
    }
})
