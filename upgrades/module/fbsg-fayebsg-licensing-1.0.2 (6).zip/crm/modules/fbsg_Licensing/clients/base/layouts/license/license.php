<?php
//$viewdefs['fbsg_Slack']['base']['layout']['fbsg-slack-config'] = array(
////    'type' => 'simple',
//    'type' => 'configuration',
//    'name' => 'base',
//    'span' => 12,
//    'components' => array(
//        array ('view' => 'fbsg_config_headerpane'),
//        array(
//            'view' => 'fbsg_config_content',
//        ),
//    ),
//);

$viewdefs['fbsg_Licensing']['base']['layout']['license'] = array(
    'components' => array(
        array(
            'layout' => array(
                'components' => array(
                    array(
                        'view' => 'license-headerpane',
                    ),
                    array(
                        'view' => 'license-content',
                    ),
                ),
                'type' => 'simple',
                'name' => 'main-pane',
                'span' => 12,
            ),
        ),
        array(
            'layout' => array(
                'components' => array(),
                'type' => 'simple',
                'name' => 'dashboard-pane',
                'span' => 0,
            ),
        ),
    ),
    'type' => 'simple',
    'name' => 'base',
    'span' => 12,
);