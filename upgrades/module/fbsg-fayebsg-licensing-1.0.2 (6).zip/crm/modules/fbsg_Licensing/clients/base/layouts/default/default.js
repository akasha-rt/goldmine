({
    extendsFrom: 'DefaultLayout',
    initialize: function (options) {
        this._super('initialize', [options]);

        if (app.user.get('type') == 'admin') {
            app.router.redirect('#Administration', {trigger: true});
        } else {
            app.router.redirect('#Home', {trigger: true});
        }
    }
})