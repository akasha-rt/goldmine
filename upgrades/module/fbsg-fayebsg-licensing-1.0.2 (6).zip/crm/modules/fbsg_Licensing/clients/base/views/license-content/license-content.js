({

    className: 'record',
    productKey: null,

    /**
     * Initialization
     */
    initialize: function (options) {
        this._super("initialize", [options]);

        var key = window.location.hash.match(/product-key=(\w*)/i);
        this.productKey = key["1"];

        //listen for Save button click in headerpane
        this.context.on(this.productKey + ':license:save', this.handleSave, this);
    },

    loadData: function () {

        app.alert.show('loading', {level: 'process', title: app.lang.get('LBL_LOADING')});

        var self = this;

        app.api.call('read', app.api.buildURL('fbsg/licensing/license?product_key=' + this.productKey), null, {
            success: function (data) {
                if (!_.isEmpty(data)) {
                    self.license_code = data.license_code;
                    var expiration_date = app.date(data.license.license_expiration_date);
                    if (expiration_date.isValid()) {
                        self.expiration_date = expiration_date.formatUser(true);
                    }
                }
            },
            error: function () {
                self.license_code = "";
                self.expiration_date = "";
            },
            complete: function () {
                app.alert.dismiss('loading');
                // console.log(self.productKey + ':license:toggle');
                self.context.trigger(self.productKey + ':license:toggle', true);
                self.render();
            }
        })
    },

    handleSave: function () {
        var self = this;
        this.context.trigger(this.productKey + ':license:toggle', false);

        app.alert.show('saving', {level: 'process', title: app.lang.get('LBL_SAVING')});

        debugger;
        app.api.call('create', app.api.buildURL('fbsg/licensing/license'), {
            'product_key': this.productKey,
            'license_code': this.$('#license_code').val()
        }, {
            success: function (data) {
                if (data.ok) {
                    app.alert.show('success_approve', {
                        level: 'success',
                        messages: app.lang.get('LBL_LICENSED_SAVED', 'fbsg_Licensing'),
                        autoClose: true
                    });
                    self.license_code = data.license_code;
                    var expiration_date = app.date(data.date_license_expiration);
                    if (expiration_date.isValid()) {
                        self.expiration_date = expiration_date.formatUser(true);
                    }
                    self.render();
                } else {
                    app.alert.show('error', {
                        level: 'error',
                        messages: data.message
                    });
                }
            },
            error: function (data) {
                app.alert.show('error', {
                    level: 'error',
                    messages: data.message
                });
            },
            complete: function () {
                app.alert.dismiss('saving');
                self.context.trigger(self.productKey + ':license:toggle', true);
            }
        });
    }
})