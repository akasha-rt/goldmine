<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * https://fayebsg.com/end-user-license-agreement-for-fayebsg-software/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) Faye Business Systems Group, Inc. All rights reserved.
 */

namespace Sugarcrm\Sugarcrm\custom\fbsg\licensing;

use Exception;

/**
 * License factory
 * @api
 * Instantiates and configures appropriate access to the FBSG License Server
 */
class LicenseFactory
{

    /**
     * @var $instance
     */
    protected static $instance;

    /**
     * Returns a reference to the License object
     *
     * @return License instance
     */
    public static function getInstance(string $type = 'fbsg'): LicenseInterface
    {
        if (static::$instance === null) {
            try {

                static::$instance[$type] = new License();
                if (static::$instance[$type] == false) {
                    static::$instance[$type] = new License();
                }
            } catch (Exception $e) {
                static::$instance[$type] = new License();
            }
        }

        return static::$instance[$type];
    }
}