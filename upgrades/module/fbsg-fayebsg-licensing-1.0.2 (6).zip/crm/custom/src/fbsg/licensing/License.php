<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * https://fayebsg.com/end-user-license-agreement-for-fayebsg-software/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) Faye Business Systems Group, Inc. All rights reserved.
 */

namespace Sugarcrm\Sugarcrm\custom\fbsg\licensing;

use Administration;
use BeanFactory;
use Configurator;
use DateInterval;
use DateTime;
use DateTimeZone;
use Exception;
use SugarApiException;
use SugarQuery;
use UpgradeHistory;
use User;

/**
 * FBSG Licensing implementation.
 *
 * This class handles the base Licensing functionality for FBSG Software.
 *
 * All the functions in this class will work with FBSG Software
 *
 * @api
 */
class License implements LicenseInterface
{

    /**
     * With a @product_key, check to see if the license is valid. The license checks data for the $product_key stored
     * in $sugar_config['fbsg'][$product_key]
     *
     * The function needs the $sugar_config['fbsg'][$product_key]['license_code'] to previously have been set.
     *
     * This function will download the license once per day or each time after the license has expired.
     *
     * @param string $product_key (e.g, slack, util_monitor, messaging)
     * @param string $key //not used in Faye Licensing
     * @param bool $forceUpdate
     * @return bool
     * @throws LicenseException
     * @example isValidLicense('messaging');
     *
     */
    public function isValidLicense(string $product_key, string $key = null, bool $forceUpdate = false): bool
    {
        global $sugar_config;

        if (!isset($sugar_config['fbsg'][$product_key]['license_code']) || !isset($sugar_config['fbsg'][$product_key]['license_expiration_date'])) {
            throw new LicenseException("Please contact your Sugar administrator to configure the FBSG {$product_key} integration.");
        }

        $license_check = $sugar_config['fbsg'][$product_key]['license_validation_check_date'];
        $maintenance_expiration_date = $sugar_config['fbsg'][$product_key]['license_expiration_date'];

        $now = new DateTime('now', new DateTimeZone('UTC'));
        $now->setTime(0, 0, 0);
        $expirationDate = new DateTime($maintenance_expiration_date, new DateTimeZone('UTC'));
        $expirationDate->setTime(0, 0, 0);

        if ($license_check < time() || $expirationDate < $now || $forceUpdate) {
            $license = $this->downloadLicense($sugar_config['fbsg'][$product_key]['license_code'], $product_key);
            if ($license['code'] != 200) {
                return false;
            }
            $data = json_decode($license['response']);

            try {

                $configurator = new Configurator();
                $dirty = false;

                foreach (get_object_vars($data) as $field => $value) {
                    //remove the _c from the end of the field
                    if (strpos($field, '_c') !== false) {
                        $field = substr($field, 0, -2);
                    }
                    if ($field == '_acl') {
                        continue;
                    }
                    switch ($field) {
                        case 'fbsg_product_key':
                            $field = 'license_code';
                            break;
                        case 'maintenance_expiration_date':
                            $field = 'license_expiration_date';
                            $expirationDate = new DateTime($value, new DateTimeZone('UTC'));
                            $expirationDate->setTime(0, 0, 0);
                            break;
                    }
                    if (!isset($configurator->config['fbsg'][$product_key][$field]) || ($configurator->config['fbsg'][$product_key][$field] != $value)) {
                        $dirty = true;
                        $configurator->config['fbsg'][$product_key][$field] = $value;
                    }
                }

                if ($dirty) {
                    unset($sugar_config['fbsg'][$product_key]['license_code']);
                    $configurator->config['fbsg'][$product_key]['license_validation_check_date'] = time() + (24 * 60 * 60); //add an extra day so we don't check until tomorrow
                    $configurator->config['fbsg'][$product_key]['license_code'] = $data->fbsg_product_key_c;
                    $configurator->handleOverride();
                }

            } catch (Exception $e) {
                throw new LicenseException($e->getMessage());
            }
        }

        if ($expirationDate >= $now) {
            return true;
        }

        throw new LicenseException("License expired on " . $expirationDate->format(DateTime::W3C));
    }

    /**
     * Sets the License information, $license_code, for a $product_key
     *
     * @param string $product_key
     * @param string $license_code
     * @return bool
     * @throws LicenseException
     * @example setLicense('messaging', 'development-license');
     *
     */
    public function setLicense(string $product_key, string $license_code): bool
    {
        global $sugar_config;

        unset($sugar_config['fbsg'][$product_key]['license_code']);
        unset($sugar_config['fbsg'][$product_key]['license_expiration_date']);
        unset($sugar_config['fbsg'][$product_key]['license_validation_check_date']);

        $configurator = new Configurator();

        $dt = new DateTime('now', new DateTimeZone('UTC'));
        $dt->sub(new DateInterval('P1D'));

        $configurator->config['fbsg'][$product_key]['license_code'] = trim($license_code);
        $configurator->config['fbsg'][$product_key]['license_expiration_date'] = $dt->format('Y-m-d');
        $configurator->config['fbsg'][$product_key]['license_validation_check_date'] = 0;
        $configurator->handleOverride();

        return $this->isValidLicense($product_key, null, true);
    }

    /**
     * Connects to the internal FBSG licensing Server and downloads information pertaining to the $license_code.
     *
     * @param $license_code
     * @param $product_key - when passed to the licensing server
     * @return array
     * @throws \SugarQueryException
     */
    private function downloadLicense($license_code, $product_key): array
    {
        /** @var $current_user User */
        global $sugar_config, $sugar_flavor, $sugar_version, $sugar_mar_version, $current_user, $sugar_build;

        $admin = new Administration();
        $admin->retrieveSettings();

        $args = array(
            'extra' => $product_key,
            'site' => $sugar_config['site_url'],
            'host_name' => $sugar_config['host_name'],
            'licenses' => $admin->settings['license_users'],
            'flavor' => $sugar_flavor,
            'version' => $sugar_version,
            'mar_version' => $sugar_mar_version,
            'build' => $sugar_build,
            'description' => "SugarCRM Version $sugar_version (Build $sugar_build $sugar_flavor[0]) ($sugar_mar_version)",
            'license_key' => $license_code,
            'modules' => $this->getInstalledModules(),
        );

        if (!empty($current_user)) {
            $args['current_user'] = array(
                'salutation' => $current_user->salutation,
                'first_name' => $current_user->first_name,
                'last_name' => $current_user->last_name,
                'email' => $current_user->emailAddress->getPrimaryAddress($current_user),
                'phone_work' => $current_user->phone_work,
                'phone_mobile' => $current_user->phone_mobile,
                'phone_home' => $current_user->phone_home,
                'phone_other' => $current_user->phone_other,
                'phone_fax' => $current_user->phone_fax
            );
        }

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://sugar.fayebsg.com/rest/v11/fbsg/product/license/{$license_code}",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => json_encode($args),
            CURLOPT_HTTPHEADER => array(
                "Content-Type: application/json",
                "Cache-Control: no-cache",
            ),
        ));


        $response = curl_exec($curl);
        $err = curl_error($curl);
        $code = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        curl_close($curl);

        return array(
            'response' => $response,
            'err' => $err,
            'code' => $code
        );
    }

    /**
     * Returns all of the modules installed in Sugar. The data is stored in the UpgradeHistory Module
     *
     * @return array
     * @throws \SugarQueryException
     */
    private function getInstalledModules(): array
    {
        /** @var  $seed UpgradeHistory */
        $seed = BeanFactory::newBean('UpgradeHistory');
        $query = new SugarQuery();
        $query->from($seed);
        $query->where()
            ->equals('status', 'installed')
            ->equals('type', 'module');
        $query->select(['id', 'name', 'id_name', 'version', 'date_entered']);
        $query->orderBy('date_entered', 'asc');

        return $query->execute();
    }
}
