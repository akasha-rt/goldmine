<?php

$mod_strings['LBL_FBSG_LICENSING_SECTION_HEADER'] = 'Faye Licensing';
$mod_strings['LBL_FBSG_LICENSING_SECTION_DESCRIPTION'] = 'Configuration of Licenses for Faye Products';