<?php

/**
 * @author jeff.bickart@fayebsg.com
 *
 * This is an example of how to add a File to the Faye License section of the Administation panel
 * This is commented out and provided for Faye Developers
 */

/*
$license_options['Administration']['slack-license'] = array (
    'Administration',
    'LBL_FBSG_SLACK_CONFIGURE_MODULES_LINK_NAME',
    'LBL_FBSG_SLACK_CONFIGURE_MODULES_LINK_DESC',
    'javascript:parent.SUGAR.App.router.navigate("#fbsg_Licensing/layout/license?product-key=slack", {trigger: true});',
);

foreach ($admin_group_header as $key=>$values) {
    if ($values[0] == 'LBL_FBSG_LICENSING_SECTION_HEADER') {
        $admin_group_header[$key][3] = $license_options;
    }
}
*/