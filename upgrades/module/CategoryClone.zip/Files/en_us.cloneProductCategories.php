<?php

	$mod_strings['LBL_CLONEPRODUCTCATEGORIES'] = 'Copy Product Category data to Clone Module';
?>