<?php
$viewdefs['ProductCategories']['base']['layout']['subpanels'] = array(
    'components' => array(),
);