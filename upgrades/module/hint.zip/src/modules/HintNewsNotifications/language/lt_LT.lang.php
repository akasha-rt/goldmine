<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_USER_ID'] = '„Hint“ naujienų pranešimų naudotojo ID';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_USER_NAME'] = '„Hint“ naujienų pranešimų naudotojo vardas';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_CATEGORY'] = '„Hint“ naujienų pranešimų kategorija';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_TITLE'] = '„Hint“ naujienų pranešimų antraštė';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_ARTICLE_DATE'] = '„Hint“ naujienų pranešimų straipsnio data';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_PHOTO_URL'] = '„Hint“ naujienų pranešimų nuotraukos URL';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_SOURCE_URL'] = '„Hint“ naujienų pranešimų šaltinio URL';
$mod_strings['LBL_HINT_NEWS_NOTIFICATIONS_PUBLISHER'] = '„Hint“ naujienų pranešimų leidėjas';
