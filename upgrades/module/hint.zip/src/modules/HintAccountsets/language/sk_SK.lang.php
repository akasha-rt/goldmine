<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'ID množiny účtov Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'Typ množiny účtov Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'ID používateľa množiny účtov Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'Meno používateľa množiny účtov Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'Kategória množiny účtov Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'Ciele množiny účtov Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'Ciele oznámení množiny účtov Hint';
