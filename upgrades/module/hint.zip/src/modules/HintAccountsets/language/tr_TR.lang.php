<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'Hint hesap seti kimliği';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'Hint hesap seti türü';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'Hint hesap seti kullanıcı kimliği';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'Hint hesap seti kullanıcı adı';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'Hint hesap seti kategorisi';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'Hint hesap seti hedefleri';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'Hint hesap seti bildirim hedefleri';
