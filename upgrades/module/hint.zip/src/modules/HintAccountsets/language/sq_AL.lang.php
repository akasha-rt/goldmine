<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'Id-ja e grupit të llogarive të Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'Lloji i grupit të llogarive të Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'Id-ja e përdoruesit e grupit të llogarive të Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'Emri i përdoruesit i grupit të llogarive të Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'Kategoria e grupit të llogarive të Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'Objektivat e grupit të llogarive të Hint';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'Objektivat e njoftimeve të grupit të llogarive të Hint';
