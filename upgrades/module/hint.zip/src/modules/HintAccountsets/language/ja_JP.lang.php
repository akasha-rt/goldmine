<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = 'Hintアカウントセット ID';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = 'Hint アカウントセットの種類';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = 'Hintアカウントセットのユーザー ID';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = 'Hint アカウントセットのユーザー名';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = 'Hint アカウントセットのカテゴリ';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = 'Hint アカウントセットのターゲット';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = 'Hint アカウントセット通知ターゲット';
