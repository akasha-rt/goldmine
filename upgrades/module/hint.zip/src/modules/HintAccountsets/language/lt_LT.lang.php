<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ACCOUNTSET_ID'] = '„Hint“ paskyrų rinkinio ID';
$mod_strings['LBL_HINT_ACCOUNTSET_TYPE'] = '„Hint“ paskyrų rinkinio tipas';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_ID'] = '„Hint“ paskyrų rinkinio naudotojo ID';
$mod_strings['LBL_HINT_ACCOUNTSET_USER_NAME'] = '„Hint“ paskyrų rinkinio naudotojo vardas';
$mod_strings['LBL_HINT_ACCOUNTSET_CATEGORY'] = '„Hint“ paskyrų rinkinio kategorija';
$mod_strings['LBL_HINT_ACCOUNTSET_TARGETS'] = '„Hint“ paskyrų rinkinio paskirties vietos';
$mod_strings['LBL_HINT_ACCOUNTSET_NOTIFICATION_TARGETS'] = '„Hint“ paskyrų rinkinio pranešimo paskirties vietos';
