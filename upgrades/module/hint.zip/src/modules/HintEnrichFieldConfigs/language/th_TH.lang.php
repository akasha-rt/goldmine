<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ENRICH_FIELD_USER_ID'] = 'Id ผู้ใช้การกำหนดค่าฟิลด์เอ็นริชของ Hint';
$mod_strings['LBL_HINT_ENRICH_FIELD_CONFIG_DATA'] = 'ข้อมูล config การกำหนดค่าฟิลด์เอ็นริชของ Hint';
$mod_strings['LBL_HINT_ENRICH_FIELD_CREATED'] = 'สร้างการกำหนดค่าฟิลด์เอ็นริชของ Hint แล้ว';
$mod_strings['LBL_HINT_ENRICH_FIELD_SYNCED'] = 'ซิงค์ฟิลด์ที่ได้รับการปรับปรุงโดย Hint แล้ว';
