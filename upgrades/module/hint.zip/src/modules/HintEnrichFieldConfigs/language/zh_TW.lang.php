<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ENRICH_FIELD_USER_ID'] = 'Hint 豐富字段配置用戶 id';
$mod_strings['LBL_HINT_ENRICH_FIELD_CONFIG_DATA'] = 'Hint 豐富字段配置配置數據';
$mod_strings['LBL_HINT_ENRICH_FIELD_CREATED'] = 'Hint 豐富字段配置已建立';
$mod_strings['LBL_HINT_ENRICH_FIELD_SYNCED'] = 'Hint 豐富字段已同步';
