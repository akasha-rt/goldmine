<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ENRICH_FIELD_USER_ID'] = 'Hint enrich fields config user id';
$mod_strings['LBL_HINT_ENRICH_FIELD_CONFIG_DATA'] = 'Hint enrich fields config config data';
$mod_strings['LBL_HINT_ENRICH_FIELD_CREATED'] = 'Hint enrich fields config created';
$mod_strings['LBL_HINT_ENRICH_FIELD_SYNCED'] = 'Hint Enrich Field Synced';
