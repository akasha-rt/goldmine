<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_ENRICH_FIELD_USER_ID'] = 'Id utente configurazione campi arricchimento Hint';
$mod_strings['LBL_HINT_ENRICH_FIELD_CONFIG_DATA'] = 'Dati configurazione campi arricchimento Hint';
$mod_strings['LBL_HINT_ENRICH_FIELD_CREATED'] = 'Configurazione campi arricchimento Hint creata';
$mod_strings['LBL_HINT_ENRICH_FIELD_SYNCED'] = 'Campi arricchimento Hint sincronizzati';
