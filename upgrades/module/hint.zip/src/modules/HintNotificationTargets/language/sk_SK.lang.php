<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ID'] = 'ID cieľa oznámenia Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_ID'] = 'ID používateľa cieľa oznámenia Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_NAME'] = 'Meno používateľa cieľa oznámenia Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_TYPE'] = 'Typ cieľa oznámenia Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_CREDENTIALS'] = 'Prihlasovacie údaje cieľa oznámenia Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ACCOUNTSETS'] = 'Množiny účtov cieľa oznámenia Hint';
