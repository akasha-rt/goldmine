<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ID'] = 'Ідентифікатор цілі сповіщень Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_ID'] = 'Ідентифікатор цільового користувача сповіщень Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_NAME'] = 'Ім’я цільового користувача сповіщень Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_TYPE'] = 'Тип цілі сповіщень Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_CREDENTIALS'] = 'Реєстраційні дані цільового користувача сповіщень Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ACCOUNTSETS'] = 'Групи облікових записів цільових користувачів сповіщень Hint';
