<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ID'] = 'Hint 알림 타겟 ID';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_ID'] = 'Hint 알림 타겟 사용자 ID';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_NAME'] = 'Hint 알림 타겟 사용자 이름';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_TYPE'] = 'Hint 알림 타겟 유형';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_CREDENTIALS'] = 'Hint 알림 타겟 자격증명';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ACCOUNTSETS'] = 'Hint 알림 타겟 계정 세트';
