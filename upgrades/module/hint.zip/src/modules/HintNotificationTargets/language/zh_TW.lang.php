<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ID'] = 'Hint 通知目標 id';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_ID'] = 'Hint 通知目標用戶 id';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_NAME'] = 'Hint 通知目標用戶名稱';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_TYPE'] = 'Hint 通知目標類型';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_CREDENTIALS'] = 'Hint 通知目標用戶憑證';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ACCOUNTSETS'] = 'Hint 通知目標帳戶集';
