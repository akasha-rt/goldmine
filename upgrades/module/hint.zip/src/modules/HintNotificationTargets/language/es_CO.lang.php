<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ID'] = 'ID de destino de notificación de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_ID'] = 'ID de usuario de destino de notificación de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_NAME'] = 'Nombre de usuario objetivo de notificación de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_TYPE'] = 'Tipo de destino de notificación de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_CREDENTIALS'] = 'Credenciales de destino de notificación de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ACCOUNTSETS'] = 'Accountsets de destino de notificación de Hint';
