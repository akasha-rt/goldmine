<?php
/*
* Your installation or use of this SugarCRM file is subject to the applicable
* terms available at
* http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
* If you do not agree to all of the applicable terms or do not have the
* authority to bind the entity as an authorized representative, then do not
* install or use this SugarCRM file.
*
* Copyright (C) SugarCRM Inc. All rights reserved.
*/

$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ID'] = 'Id del destinatario de notificaciones de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_ID'] = 'Id de usuario del destinatario de notificaciones de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_USER_NAME'] = 'Nombre de usuario del destinatario de notificaciones de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_TYPE'] = 'Tipo de destinatario de notificaciones de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_CREDENTIALS'] = 'Credenciales del destinatario de notificaciones de Hint';
$mod_strings['LBL_HINT_NOTIFICATION_TARGET_ACCOUNTSETS'] = 'Grupos de cuentas del destinatario de notificaciones de Hint';
