<?php
$hook_array['after_save'][] = Array(1, 'after_save', 'custom/modules/CC_Coupon_Codes/after_save.php','after_save', 'after_save');
 


?>