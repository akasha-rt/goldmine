<?php

$dictionary['Opportunity']['fields']['account_name']['required'] = false;