<?php
$mod_strings['LBL_SAVED_BY_PORTAL_USER'] = 'Saved By Portal User';
