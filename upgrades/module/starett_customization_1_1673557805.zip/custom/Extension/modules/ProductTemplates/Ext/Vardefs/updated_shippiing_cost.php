<?php
$dictionary['ProductTemplate']['fields']['shipping_cost']['type'] = 'currency';
$dictionary['ProductTemplate']['fields']['shipping_cost']['len'] = '26,6';
$dictionary['ProductTemplate']['fields']['shipping_cost']['related_fields'] = array (
    0 => 'currency_id',
    1 => 'base_rate',
  );


