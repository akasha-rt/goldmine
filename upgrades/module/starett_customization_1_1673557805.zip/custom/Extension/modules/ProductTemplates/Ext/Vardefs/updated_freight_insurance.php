<?php
$dictionary['ProductTemplate']['fields']['freight_insurance']['type'] = 'currency';
$dictionary['ProductTemplate']['fields']['freight_insurance']['len'] = '26,6';
$dictionary['ProductTemplate']['fields']['freight_insurance']['related_fields'] = array (
    0 => 'currency_id',
    1 => 'base_rate',
  );
