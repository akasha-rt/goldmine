<?php
$mod_strings['LBL_FREIGHT_INSURANCE'] = 'Freight Insurance';