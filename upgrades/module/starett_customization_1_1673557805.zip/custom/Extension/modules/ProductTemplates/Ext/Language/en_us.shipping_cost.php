<?php
$mod_strings['LBL_SHIPPING_COST'] = 'Shipping Cost';