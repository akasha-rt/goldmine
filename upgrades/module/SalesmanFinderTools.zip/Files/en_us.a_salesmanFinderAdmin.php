<?php

$mod_strings['LBL_SALESMANFINDER_EXPORT'] = 'Export Salesman Finder';
$mod_strings['LBL_SALESMANFINDER_EXPORT_DESCRIPTION'] = 'Export Salesman Finder Database, and Download as CSV';
$mod_strings['LBL_SALESMANFINDER_TRUNCATE'] = 'Delete Salesman Finder Data';
$mod_strings['LBL_SALESMANFINDER_TRUNCATE_DESCRIPTION'] = 'Export, then Delete Salesman Finder Database';
$mod_strings['LBL_SALESMANFINDER_GROUP'] = 'Salesman Finder Export, Database Deletion Tools';
$mod_strings['LBL_SALESMANFINDER_GROUP_DESCRIPTION'] = 'Export Salesman Finder Database and Download as CSV.  Optionally Delete Contents of database to import new updates.';

?>