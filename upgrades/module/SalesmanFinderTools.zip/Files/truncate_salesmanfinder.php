<?php

//custom/modules/SF1_SalesmanFinder/truncate_salesmanfinder.php
global $current_user,$db, $sugar_config;


$db->query("TRUNCATE TABLE sf1_salesmanfinder");
$db->query("TRUNCATE TABLE sf1_salesmanfinder_cstm");



?>
</br>
</br>
</br>
</br>
</br>
<H1>All Salesman Finder Records have been permanently deleted from your system successfully</H1>


