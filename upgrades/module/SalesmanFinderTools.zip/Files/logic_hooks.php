<?php
// Do not store anything in this file that is not part of the array or the hook version.  This file will	
// be automatically rebuilt in the future. 
$hook_version = 1; 
$hook_array = Array(); 
$hook_array['after_save'][] = Array(1, 'after_save_logic', 'custom/modules/SF1_SalesmanFinder/after_save_logic.php','after_save_logic', 'after_save_logic');
 


?>