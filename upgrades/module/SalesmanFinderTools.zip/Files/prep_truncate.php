</br>
</br>
<H1>WARNING!  Deleting The Salesman Finder Database is unrecoverable.  Be sure to export the data through the Export tool before Proceeding.</H1>
</br>
</br>
</br>
</br>
<button onclick = 'javascript:parent.SUGAR.App.router.navigate("#bwc/index.php?module=SF1_SalesmanFinder&action=truncate_salesmanfinder", {trigger: true})'>Delete All Salesman Finder Data</button>

<?php

?>