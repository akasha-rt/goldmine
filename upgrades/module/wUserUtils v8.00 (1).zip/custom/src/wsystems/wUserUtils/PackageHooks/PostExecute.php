<?php

use \Sugarcrm\Sugarcrm\custom\wsystems\wUserUtils\ConfiguratorManager;

$_cfgManager = new ConfiguratorManager();

$_cfgManager->initLoggerConfig();
