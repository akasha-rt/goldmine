<?php

$app_strings["EXCEPTION_MAINTENANCE"] = "SugarCRM is in maintenance mode. Only admins can login. Please contact your administrator for details.";
