<?php

$entry_point_registry["wUserUtilsEntryPoint"] = array(
    "file" => "custom/wUserUtilsEntryPoint.php",
    "auth" => true,
);
