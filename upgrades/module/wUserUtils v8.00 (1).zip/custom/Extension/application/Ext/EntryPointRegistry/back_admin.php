<?php

$entry_point_registry["BackAdmin"] = array(
    "file" => "custom/entrypoints/BackAdmin.php",
    "auth" => true,
);
