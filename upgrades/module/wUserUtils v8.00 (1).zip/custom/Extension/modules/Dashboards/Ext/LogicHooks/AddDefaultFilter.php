<?php

$hook_array["after_save"][] = array(
    1,
    "after_save dashboard actions",
    "custom/modules/Dashboards/AfterSaveDashboard.php",
    "AfterSaveDashboard",
    "afterSaveDashboardMethod",
);
