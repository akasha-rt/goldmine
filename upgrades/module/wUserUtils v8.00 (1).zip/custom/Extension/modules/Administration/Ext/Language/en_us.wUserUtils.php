<?php

$mod_strings["LBL_WUSERUTILS_SETTINGS"]                       = "User Preference Management and Cloning";
$mod_strings["LBL_WUSERUTILS_TITLE"]                          = "wUserUtils";
$mod_strings["LBL_WUSERUTILS_DESCRIPTION"]                    = "Miscellaneous User Utility Tools";
$mod_strings["LBL_WUSERUTILS_CONFIGURE_SETTINGS_DESCRIPTION"] = "Save time by cloning and managing user preferences, dashboards, filters. Control 'Login As' access and System Maintenance Mode.";
$mod_strings["LBL_WUSERUTILS_BRODCAST_TITLE"]                 = "Broadcast Message";
$mod_strings["LBL_WUSERUTILS_BRODCAST_DESCRIPTION"]           = "Configure a globally visible message header.";
$mod_strings["LBL_WUSERUTILS_RESTRICT_LOGIN_TITLE"]           = "Restrict Login Hours";
$mod_strings["LBL_WUSERUTILS_RESTRICT_LOGIN_DESCRIPTION"]     = "Specify the hours when users can log in.";
