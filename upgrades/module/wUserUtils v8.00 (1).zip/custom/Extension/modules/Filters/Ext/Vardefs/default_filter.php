<?php

$dictionary["Filters"]["fields"]["default_filter"] = array(
    "name"                     => "default_filter",
    "vname"                    => "Default Filter",
    "type"                     => "bool",
    "default"                  => "0",
    "reportable"               => false,
    "duplicate_on_record_copy" => "no",
    "merge_filter"             => "disabled",
    "comments"                 => "",
    "massupdate"               => 0,
);
