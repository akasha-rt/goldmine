<?php

$viewdefs["Filters"]["base"]["filter"]["default"]["fields"]["default_filter"] = array();
