<?php

$viewdefs["Filters"]["base"]["view"]["record"]["panels"][0]["fields"][0]["related_fields"][] = "default_filter";
