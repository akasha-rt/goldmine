<?php

$viewdefs["base"]["layout"]["control-users-login-times"] = array(
    "type"       => "simple",
    "components" => array(
        array(
            "view" => "control-users-login-times",
        ),
    ),
);
