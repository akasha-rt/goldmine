<?php
$viewdefs["base"]["layout"]["broadcast-message"] = array(
    "type"       => "simple",
    "components" => array(
        array(
            "view" => "broadcast-message-view",
        ),
    ),
);
