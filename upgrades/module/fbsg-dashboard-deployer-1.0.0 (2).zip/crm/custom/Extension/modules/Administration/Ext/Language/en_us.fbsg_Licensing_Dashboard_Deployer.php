<?php

$mod_strings['LBL_FBSG_DASHBOARD_DEPLOYER_CONFIGURE_MODULES_LINK_NAME'] = 'Dashboard Deployer';
$mod_strings['LBL_FBSG_DASHBOARD_DEPLOYER_CONFIGURE_MODULES_LINK_DESC'] = 'Configuration of Licenses for Dashboard Deployer';