<?php

/**
 * @author jeff.bickart@fayebsg.com
 *
 */

$license_options['Administration']['dashboard-deployer-license'] = array(
    'Administration',
    'LBL_FBSG_DASHBOARD_DEPLOYER_CONFIGURE_MODULES_LINK_NAME',
    'LBL_FBSG_DASHBOARD_DEPLOYER_CONFIGURE_MODULES_LINK_DESC',
    'javascript:parent.SUGAR.App.router.navigate("#fbsg_Licensing/layout/license?product-key=dashboard_deployer", {trigger: true});',
);

foreach ($admin_group_header as $key => $values) {
    if ($values[0] == 'LBL_FBSG_LICENSING_SECTION_HEADER') {
        $admin_group_header[$key][3] = $license_options;
    }
}