<?php

    $mod_strings['LBL_INTDB_NAME'] = 'FayeBSG Dashboards Deployer';
    $mod_strings['LBL_INTDB_DESCRIPTION'] = 'FayeBSG Dashboards allow you to manage user\'s dashboards';
    $mod_strings['LBL_INTDB_ADMIN_HEADER'] = 'FayeBSG Dashboards Deployer';
    $mod_strings['LBL_INTDB_ADMIN_DESCRIPTION'] = 'FayeBSG Dashboards Deployer Manager';
