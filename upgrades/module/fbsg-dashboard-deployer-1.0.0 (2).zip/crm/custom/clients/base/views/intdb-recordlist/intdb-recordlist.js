/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
/**
 * @class View.Views.Base.RecordlistView
 * @alias SUGAR.App.view.views.BaseRecordlistView
 * @extends View.Views.Base.FlexListView
 */
({
    extendsFrom: 'RecordlistView',
    
    /**
     * List of selected dashboards
     *
     * @property array
     */
    selectedDashboards: [],
    
    /**
     * Initial postfix value
     */
    postfix: null,
       
    /**
     * @inheritdoc
     */
    initialize: function(options) {
        options.meta.selection.actions[0].label = app.lang.get('LBL_DEPLOY', 'INTDB_Dashboards');
        options.meta.selection.actions[1].label = app.lang.get('LBL_DEPLOY_POSTFIX', 'INTDB_Dashboards');
        options.meta.selection.actions[2].label = app.lang.get('LBL_DEPLOY_OVERWRITE', 'INTDB_Dashboards');
        this._super('initialize', [options]);
        this.context.on('intdb_do_deploy', _.bind(this.doDeploy, this, 'deploy'));
        this.context.on('intdb_do_deploy_postfix', _.bind(this.doDeployWithPostfix, this));
        this.context.on('intdb_do_deploy_overwrite', _.bind(this.doDeploy, this, 'deploy_overwrite'));
        this.context.on('intdb_cancel', _.bind(this.cancel, this));
        this.context.on('all', _.bind(function(ev) {
            if (ev && ev.indexOf('mass_collection:')==0) this.checkButtons()
        }, this));
        this.selectedDashboards = this.context.get('selectedDashboards');
    },

    /**
     * @inheritdoc
     */
    render: function() {
        try {
            var defaultLayout = this.closestComponent('sidebar');
            if (defaultLayout && defaultLayout.isSidePaneVisible() ) {  
                defaultLayout.trigger('sidebar:toggle');  
            }
        } catch(e) {}
        this._super('render');
    },
    
    /**
     * Close drawer
     */
    cancel: function() {
        app.drawer.close();
    },
    
    /**
     * Initiate api deploy - check conditions
     * @param type String
     * @param postfix String|null
     */
    doDeploy: function(type, postfix) {
        if (typeof(postfix)=='undefined') postfix = null;
        if (this.massCollection.toJSON().length==0 || this.selectedDashboards.length==0) {
            app.alert.show('intdb', {
                level: 'error',
                messages: app.lang.get('LBL_NEED_TO_SELECT_', 'INTDB_Dashboards').replace(/%s/g, this.module.toLowerCase()),
                autoClose: true,
            });
            return;
        }
        app.alert.show('intdb', {
            level: 'confirmation',
            messages: app.lang.get('LBL_CONFIRM_DEPLOYMENT', 'INTDB_Dashboards').replace(/%s/,app.lang.get('LBL_MODULE_NAME', this.module).toLowerCase()),
            autoClose: false,
            onConfirm: _.bind(this.processDeploy, this, type, postfix),
            onCancel: function(){
                
            }
        });
    },
    
    /**
     * Open drawer for User postfix input
     * on close pass values to doDeploy function
     */
    doDeployWithPostfix: function() {
        app.drawer.open({
            layout: 'postfix',
        },
        _.bind(function(postfix) {
            if (postfix) {
                this.doDeploy('deploy_postfix', postfix);
            }
        }, this));
    },
    
    /**
     * Initiate api deploy
     * @param type String
     * @param postfix String|null
     */
    processDeploy: function(type, postfix) {
        if (typeof(postfix)=='undefined') postfix = null;
        app.alert.show('intdb', {
            level: 'process',
            title: app.lang.get('LBL_DEPLOYING', 'INTDB_Dashboards'),
            autoClose: false
        });
        app.api.call('create', app.api.buildURL('INTDB_Dashboards/deploy'), {
                    module: this.module,
                    data: this.massCollection.toJSON(),
                    dashboards: this.selectedDashboards,
                    type: type,
                    postfix: postfix,
                },
                {
                    success: function(data) {
                        app.alert.dismiss('intdb');
                        app.alert.show('intdb', {
                            level: 'success',
                            messages: app.lang.get('LBL_DEPLOY_SUCCESS', 'INTDB_Dashboards'),
                            autoClose: true
                        });
                    },
                    error: function(data) {
                        app.alert.dismiss('intdb');
                        app.alert.show('intdb', {
                            level: 'error',
                            messages: app.lang.get('LBL_DEPLOY_ERROR', 'INTDB_Dashboards'),
                            autoClose: true
                        });
                    }
                }
        );
        app.drawer.close();
    },
    
    /**
     * Show/hide Deploy-actiondropdown button group
     */
    checkButtons: function() {
        if (this.massCollection.toJSON().length) {
            $('span.fieldset.intdb-list-headerpane').show();
        } else {
            $('span.fieldset.intdb-list-headerpane').hide();
        }
    }
})
