({
    /**
     * Add event for set_postfix button click
     */
    myEvents: {
        'click [name=set_postfix]': 'checkInput',
    },
    
    /**
     * Initialization
     */
    initialize: function (options) {
        this._super("initialize", [options]);
        this.context.on('settings:save', this.closeDrawer, this);
        
        if (this.events) {
            _.extend(this.events, this.myEvents);
        } else {
            this.events = this.myEvents;
        }
    },
    
    /**
     * Apply Changes when set_postfix button is clicked
     */
    checkInput: function() {
        if ($('[name=postfix]').val() != '') {
            $('[name=deploy_with_postfix_button]').removeClass('hidden');
            if (this.postfixSaved == true) {
                $('[name=postfix]').attr('readonly', false);
                $('[name=set_postfix]').html(app.lang.get('LBL_POSTFIX_SET_BUTTON', this.module));
                $('[name=set_postfix]').addClass('btn-primary');
                $('[name=deploy_with_postfix_button]').addClass('hidden');
                this.postfixSaved = false;
            } else {
                $('[name=postfix]').attr('readonly', true);
                $('[name=set_postfix]').html(app.lang.get('LBL_POSTFIX_EDIT_BUTTON', this.module));
                $('[name=set_postfix]').removeClass('btn-primary');
                this.postfixSaved = true;
            }
        } else {
            $('[name=deploy_with_postfix_button]').addClass('hidden');
        }
    },
    
    /**
     * Close the drawer and pass postfix value
     */
    closeDrawer: function() {
        postfix = $('[name=postfix]').val();
        app.drawer.close(postfix);
    },
})
