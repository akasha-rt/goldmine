<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */

require_once('clients/base/api/ConfigModuleApi.php');


class INTDBConfigApi extends ConfigModuleApi
{

    public function registerApiRest() {
        return array(
            'checkLicense' => array(
                'reqType' => 'GET',
                'path' => array('INTDB_Dashboards', 'config', 'check'),
                'pathVars' => array('module', 'config', 'check'),
                'method' => 'checkLicense',
                'shortHelp' => translate('LBL_RETRIEVES_CONFIG_FOR_GIVEN_MODULE', 'INTDB_Dashboards'),
                'longHelp' => '',
            ),
        );
    }

    /**
     * Check license
     * @param ServiceBase $api
     * @param $args
     * @return array
     * @throws SugarApiExceptionNotAuthorized
     */
    public function checkLicense(ServiceBase $api, array $args = array())
    {
        global $sugar_config;

        $product_key = 'dashboard_deployer';

        if (Sugarcrm\Sugarcrm\custom\fbsg\licensing\LicenseFactory::getInstance()->isValidLicense($product_key)) {
            return array(
                'ok' => true,
                'license_code' => $sugar_config['fbsg'][$product_key]['license_code'],
                'license' => $sugar_config['fbsg'][$product_key]
            );
        }

        throw new \Sugarcrm\Sugarcrm\custom\fbsg\licensing\LicenseException("This license provided for {$product_key} is not valid!");
    }
}