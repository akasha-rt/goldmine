<?php
$module_name = 'INTDB_Dashboards';

$viewdefs[$module_name]['base']['view']['postfix-headerpane'] = array (
    'template' => 'headerpane',
    'buttons' => array (
        array (
            'name' => 'cancel_button',
            'type' => 'button',
            'label' => 'LBL_CANCEL_BUTTON_LABEL',
            'events' => array (
                'click' => 'settings:close',
            ),
            'css_class' => 'btn-cancel',
        ),
        array (
            'name' => 'deploy_with_postfix_button',
            'type' => 'button',
            'label' => 'LBL_DEPLOY_POSTFIX',
            'primary' => true,
            'events' => array (
                'click' => 'settings:save',
            ),
            'css_class' => 'hidden'
        ),
        array (
            'name' => 'sidebar_toggle',
            'type' => 'sidebartoggle',
        ),
    ),
);