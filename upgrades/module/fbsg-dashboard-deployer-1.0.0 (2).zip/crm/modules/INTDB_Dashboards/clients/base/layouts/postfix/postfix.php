<?php
$module_name = 'INTDB_Dashboards';
$viewdefs[$module_name]['base']['layout']['postfix'] = array (
    'components' => array (
        array (
            'view' => 'postfix-headerpane',
        ),
        array (
            'view' => 'postfix-content',
        ),
    ),
    'type' => 'simple',
    'name' => 'base',
    'span' => 12,
);