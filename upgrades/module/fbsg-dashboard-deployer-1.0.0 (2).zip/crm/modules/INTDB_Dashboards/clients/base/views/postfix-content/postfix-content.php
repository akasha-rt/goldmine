<?php
$module_name = 'INTDB_Dashboards';

$viewdefs[$module_name]['base']['view']['postfix-content'] = array (
    'fields' => array (
        array (
            'name' => 'postfix',
            'label' => 'LBL_POSTFIX_INPUT',
        ),
    ),
);