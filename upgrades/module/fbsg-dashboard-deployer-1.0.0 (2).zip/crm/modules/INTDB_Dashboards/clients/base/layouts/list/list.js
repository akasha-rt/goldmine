({
    extendsFrom: 'BaseLayout',
    
    /**
     * @inheritdoc
     */
    initialize: function(options) {
        if (!app.acl.hasAccess('edit', 'Users')) {
            app.alert.show('intdb', {
                level: 'error',
                title: 'LBL_NO_ACCESS',
                messages: '',
                autoClose: true
            });
            app.router.navigate('#Home', { trigger: true });
            return;
        }
        this._super('initialize', [options]);
        this.context.on('button:config_button:click', function() {
            App.router.navigate('#fbsg_Licensing/layout/license?product-key=dashboard_deployer', { trigger: true });
        });
        this.checkLicense();
    },
    
    /**
     * Check if license is valid and not expired
     */
    checkLicense: function () {
        app.api.call('GET', app.api.buildURL(this.module, 'config/check'), null, {
            success: _.bind(function(data) {

            },this),
            error: _.bind(function(error) {
                app.alert.show('settings:error', {
                    level: 'error',
                    messages: app.lang.get('LBL_LICENCE_INVALID_REQUEST', this.module) + error.message,
                    autoClose: false
                });
               app.router.navigate('#fbsg_Licensing/layout/license?product-key=dashboard_deployer', { trigger: true });
            }, this)
        });
    },

})