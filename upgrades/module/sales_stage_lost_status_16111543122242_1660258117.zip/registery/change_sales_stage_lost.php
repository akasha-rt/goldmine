<?php
$entry_point_registry["change_sales_stage_lost"] = array(
    "file" => "custom/include/change_sales_stage_lost.php",
    "auth" => true,
);
